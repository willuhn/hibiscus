LINUX-Treiber-Installation   (Stand 24.06.2004)

fuer KOBIL Systems Chipkartenterminals
------------------------------------------------------

Zur Kommunikation zwischen Kartenlesern und PC sind 
zwei Protokolle verbreitet, CT-API und PC/SC.

Dieses Paket enthaelt:
  - readme.txt                   Diese Datei
  - libct.so                     CT-API driver 
  - libkobil_ifd.so              PC/SC driver
  - reader.conf                  PC/SC-Treiber-Konfigurations-Datei
  /developer:
  - ct_api.h                     Header Datei fuer Programm-Entwickler.
  - libct.a                      statische CT-API-Version fuer Entwickler
  - libct.so                     CT-API driver 
  /patches:
  - ct-linux-old-usb-patch.zip   altes USB-Patch
  - ct-linux-new-usb-patch.zip   neues USB-Patch
  /tools
  - cardping                     einfaches Testprogramm zum Senden von Befehlen
  - cardping.txt                 Beschreibung der Parameter mit Source-Code
  - update                       Firmware-Update B1/KAAN Professional
  - update.txt                   Beschreibung der Parameter


Allgemeine Informationen: 

- Die CT-API und PC/SC-Treiber gelten fuer serielle und USB-Geraete.
  Im USB-Kabel sitzt ein USB-Konverter, der die Signale umsetzt.
  Fuer dieses USB-Geraet wird ein Kernel Modul benoetigt, das bei
  neueren Distributionen schon enthalten ist.

- USB Kernel Unterstuetzung ab Version 2.4.20-8 (Redhat 9.0 Suse Linux 8.2).
  Fuer Versionen ab 2.4.18 muss das aeltere USB-Patch installiert 
  und der Kernel kompiliert werden (siehe /patches).
  Mit Versionen vor 2.4.18 laeuft das USB-Patch nicht.

- Fuer SuSE 9.1 bzw. Kernel ab 2.6.4 bis 2.6.6 gibt es ein 
  neues Patch fuer die USB-Unterstuetzung, da das alte Modul
  damit nicht funktioniert. Fuer Kernel 2.6.6 kann die Datei
  kobil_sct.ko umkopiert werden, die auch mit 2.6.5-52 bzw.
  2.6.5-54 lauft. 

- Fuer 2.6.5-7 muss der Kernel aber wie in der Patch-Anleitung
  beschrieben neu kompiliert werden.

- Ab Kernel 2.6.7 ist die neue Version des USB-Treibers wieder enthalten.

- Es werden nur USB Konverter Kabel Version 1.1 build 9 unterstuetzt-
  (Auslieferung standardmaessig ab Ende 2002)
  Anzeige USB-Kabel-Version leider nur unter Windows moeglich mit
  Device Diagnose Tool (www.kobil.de Support/Downloads - Setup/Tools)
  oder mit KF-Setup (Kobil's Finest) Entwicklertool ueber 
    File/New - CTExamine -> Examine

- Fuer CT-API-Zugriffe darf kein PC/SC-Treiber installiert/aktiv sein.


Installations-Anleitung:
---------------------------------
 
1. CT-API Treiber Installieren
2. .CT_devices Eintraege ueberpruefen
3. USB: Ueberpruefen, welcher USB Port verwendet werden kann
4. ChipkartenLeser Verfuegbarkeit testen
5. PC/SC
6. Hinweise fuer Software-Entwickler
7. Anwendungen


1. CT-API Treiber installieren:
----------------------------------------

Die Installation der CT-API geschieht durch einfaches Kopieren der
Datei libct.so an eine Stelle, an der die Software den Treiber findet.
Am einfachsten ueber den Suchpfad der in LD_LIBRARY_PATH enthalten ist
und normalerweise kann daher die Datei libct.so nach /usr/lib kopiert 
werden, was besonders fuer PC/SC wichtig ist. Ansonsten kann die Datei
auch woanders hinkopiert werden, wenn im Programm der absolute Pfad 
angegeben werden kann.

   - Linux-Treiber-Datei entpacken von CD oder aus dem Internet unter www.kobil.de
     Support/Download - Treiber fuer Smart Card Terminals 
   - evlt. aktualisieren des USB-Moduls kobil_sct.ko (siehe Allgemeine Informationen)
   - Kopieren der Datei libct.so in das Verzeichnis /usr/lib/
   - Ueberpruefung/Setzen der entsprechenden Rechte, falls es Probleme gibt.
   - Erstellen der .CT_devices der Datei im jeweiligen Homeverzeichnis
     mit den Werten unter Punkt 2.
     Falls nicht vorhanden, wird sie beim ersten Zugriff ueber CT-API/libct.so 
     im Home-Verzeichnis angelegt und muss dann kontrolliert/angepasst werden.

   
2.  .CT_devices Eintraege ueberpruefen:
------------------------------------------------

  GetPortType=#0
  SetPortType=#0
  DefaultPortType=#0
  DefaultProtocollType=#0
  UseOnlyDefaultProtocoll=#0
  B1DTRLow=#50
  B1DSRRespActive=#2000
  PnPChar=#150
  B1WaitForPnPString=#1500
  KaanWaitForPnPString=#600
  Port1=COM;/dev/ttyS0;1;0;serial reader at /dev/ttyS0: B1/Kaan Pro COM1
  Port2=COM;/dev/ttyUSB0;2;0;USB reader at /dev/ttyUSB0: Kaan/SecOVID/Twin


  Port1 waere hier ein serieller B1 oder KAAN Professional und
  Port2 ein KAAN Standard Plus USB-Chipkartenterminal.

Fuer ein chipkartentemrinal genuegt ein Eintrag, z. B. Port1=...
Die anderen Werte sind Standard-Parameter und duerfen nicht geaendert werden.

Bei seriellen Geraeten ist ttyS0=COM1, ttyS1=COM2 usw., aber bei USB kommt es 
auf die vorhandenen USB-Geraete an, welche Zahl beim Eintrag man nehmen muss,
was beim Booten in der Datei /var/log/messages aufgefuehrt wird (siehe Punkt 3),
z. B. ttyUSB0, ttyUSB1 usw.

Portparameter: (= Portindex im CT-API Control Panel unter Windows)
  Port = 0 bis 255 je nach Bedarf, Standard Port1, 
  ;1;0 fuer B1/Kaan Pro               -> dient zur Kennung der Kommunikations-
  ;2;0 fuer Kaan/SecOVID/Twin-Geraete  -> Protokolle von Treiber zum Geraet
  ;2;0 fuer Smart Token (=Typ KAAN Standard Plus)
  >> Die Angabe COM dient als Geraetetypantwort bei Programmabfragen 


Zusatzparameter zur Protokollierung der Befehle und Fehlersuche:
  (= CT-API Logging 'Logfile Level F All' unter Windows)

  LogfileName=~/ctapi-logfile
  LogLevel=#15

Hinweis: Fuer den globalen Zugriff oder Dienste kann auch eine CT_devices
         im Verzeichnis /etc stehen, dann aber ohne vorangestellten Punkt.

3. USB: Ueberpruefen, welcher USB Port verwendet werden kann:
-------------------------------------------------------------------------

   - als root-Benutzer kann mit folgenden Befehl die Log-Datei aufgelistet werden:
     tail -f /var/log/messages 
     Damit werden alle neuen Eintraege angezeigt und beim Anschluss des USB-
     Chipkartenterminals werden Informationen ausgegeben.
 -->
Okt 16 12:07:18 localhost devlabel: devlabel service started/restarted
Oct 16 12:07:21 localhost kernel: hub.c: new USB device 00:1f.2-2, assigned address 11
Oct 16 12:07:21 localhost kernel: usbserial.c: KOBIL USB smart card terminal converter detected
Oct 16 12:07:21 localhost kernel: usbserial.c: KOBIL USB smart card terminal converter now 
attached to ttyUSB0 (or usb/tts/0 for devfs)
< An dieser Stellen attached to ttyUSB0 koennen Sie sehen an welchem USB Port Ihr Leser 
angeschlossen ist. Dies muss ebenfalls in die .CT_devices mit aufgenommen werden.

-->  Port1=COM;/dev/ttyUSB0;1;0;serial reader at /dev/ttyUSB0: B1/Kaan Pro
     

4. ChipkartenLeser Verfuegbarkeit testen:
-------------------------------------------------

--> In der Linux-Treiber-Datei gibt es noch ein Zusatz-Tool cardping mit dem ein
     Lesertest bei eingelegter Chipkarte durchgefuehrt werden kann.
  
Befehl fuer die oben angegebenen Port-Beispiele fuer Port1 und Port2: 
     cardping -b1 20100101
      oder 
     cardping -b2 20100101
     
       < Going to call CT_init
	 CT_init (Port 1): 0
         CT_Reset: 0
	 CT_data Aufruf mit: 20 10 01 01 
	 CT_data: 0
	 Antwort: 3B BA 96 00 81 31 86 5D 00 64 05 60 02 03 31 80 90 00 66 90 0

Es sollte nun als Ergebnis CT_data: 0 folgen. 

Falls CT_data: -1 als Resultat ausgegeben wir, muessen die Einstellungen 
in der Datei .CT_devices ueberprueft werden.

Es koennen auch mehrere Parameter hinter cardping stehen, z. B. 
       cardping -b1 20100000 - 20100101  (Reset + Reset(ATR)


5. PC/SC: (nur bei Bedarf installieren, da CT-API dann nicht funktioniert)
----------------------------------------------------------------------------------------

Der PC/SC-Treiber muss zusaetzlich installiert werden!

Mit libkobil_ifd.so stellt KOBIL einen IFDH (interface device handler)
zur Verfuegung, der ein Plug-In fuer das MUSCLE PC/SC lite framework
darstellt. Voraussetzung zur Benutzung ist somit neben dem installierten
CT-API-Treiber auch, dass das PC/SC lite framework bereits installiert
ist. Dieses Framework ist z.B. ueber http://www.linuxnet.com erhaeltlich.

  - Kopieren der Datei libkobil_ifd.so in das Verzeichnis /usr/lib/
    libkobil_ifd.so ist Plug-In fuer das MUSCLE PC/SC lite framework Paket
    und ist ein interface device handler (IFDH)
  - Kopieren der Datei reader.conf in das Verzeichnis /etc
    Hinweis: In dieser Datei muessen der absolute Pfad zur Datei libkobil_ifd.so und 
    die richtige "CHANNELID" eingestellt werden, z. B. CHANNELID 0x000001,
    die der Port-Einstellung in der ~/.CT_devices entsprechen muss.

Weiter Hinweise:

- Testtools zum Testen der Funktionalitaet. 
  Auf der Seite www.linuxnet.com findet man ein Paket pcsc-tool, dies 
  verlangt aber einige perl Skripte. Dazu wird zusaetzlich noch das 
  Paket pcsc-perl benoetigt. 
  (Hierbei sollten immer die neuesten Versionen verwendet werden)
  Bitte dazu die README Lesen zum installieren dieser Pakete.
  //Befindet im Installationsverzeichnis von pcsc-perl

- Starten des PCSC Daemon. --> pcscd -d stdout 

- Starten von pcsc_scan Kommandozeilen Tool. 
   Es kann auch ein Grafisches Tool benutzt werden das es ebenfalls
   bei muscle enthalten ist.
   Vorraussetzung ist dafuer sind die GTK Komponeten die bei Linux mit
   installiert werden muessen. Dies kann auch nachtraeglich ueber die Paket-
   Verwaltung zum System hinzugefuegt werden. 


6. Hinweise fuer Software-Entwickler:
---------------------------------------------

Zu beachten ist, dass die Libraries zusaetzlich zu den bekannten
standardisierten Funktionen CT_init, CT_data, CT_close auch die
Funktion CT_init_name zur Verfuegung stellt. Damit wird insbesondere
der Zugriff auf Leser ermoeglicht, die nicht an einer ueblichen
seriellen Schnittstelle angeschlossen sind.

Beispielsweise laesst sich nun auf Linux auch
CT_init_name(1, "/dev/ttyS0") gleichbedeutend mit CT_init(1, 1)
verwenden. Daneben ist jedoch auch CT_init_name(1, "/dev/ttyC0")
moeglich, wenn Sie z.B. ueber eine Schnittstellenkarte verfuegen,
die serielle ports /dev/ttyC0 bis /dev/ttyC15 zur Verfuegung stellt.

Darueber hinaus ist auch der Zugriff auf ein X-Terminal moeglich, indem
Sie IP-Adresse des Terminals und die Portnummer, die zur Kommunikation
mit der seriellen Schnittstelle des Terminals dient, angeben, z.B.
CT_init_name(1, "192.168.1.1:1015"). 

KOBIL Vendor ID 0x0D46
KOBIL_ADAPTER_B_PRODUCT_ID 0x2011 // B1, B1 Pro
KOBIL_ADAPTER_K_PRODUCT_ID 0x2012 // Kann Standard Plus, SecOVID Reader Plus
KOBIL_USBTWIN_PRODUCT_ID   0x0078 // Twin

7. Anwendungen
----------------------

MoneyPlex greift ueber CT-API auf das Chipkartenterminal zu.
   Bei Problemen sollte zum die aktuelle libct.so aus dem Verzeichnis 
   /usr/lib angegeben werden.

GnuCash kann sowohl CT-API als auch PC/SC verwenden.

