#ifndef CT_API_H
#define CT_API_H

#define OK		0
#define ERR_INVALID	-1
#define ERR_CT		-8
#define ERR_TRANS	-10
#define ERR_MEMORY	-11
#define ERR_HTSI	-128
#define ERR_FILEIO	-2

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef unsigned short IU16;
/*
*****************************************************************
** Initialisieren der zu benutzenden seriellen Schnittstelle
**
** �bergabeparameter:
**          Parameter   m�gliche Werte
**
**          Ctn         0 - 255 (Cardterminal Number)
**          port        1 -> COM1
**                      2 -> COM2
**                      3 -> COM3 usw.
**
** Beispiel:            CT_init(0, 1)
**
** R�ckgabewerte:       OK     -> fehlerfreie Bearbeitung
**                      ERR_CT -> Schnittstelle konnte nicht
**                                initialisiert werden
**
*****************************************************************
*/

char CT_init(unsigned short ctn, unsigned char pn);


/*
** ***************************************************************
** Schlie�en der Kommunikation �ber die serielle Schnittstelle
**
** �bergabeparameter:   Ctn     m�glich: 0-255
**
** Beispiel:        CT_close(0);
**
** R�ckgabewerte:   0 -> Fehlerfreie Ausf�hrung
**
** ***************************************************************
*/

char CT_close(unsigned short ctn);


/*
*****************************************************************
** Daten an die unteren Schichten transparent durchreichen
**
** �bergabeparameter:  ctn -> Card Terminal Number
**                    *dad -> Destination Address
**                    *sad -> Source Address
**                      lc -> Length Command
**                     cmd -> Command
**                     *lr -> Receive Buffer Size
**                    *rsp -> Response
**
** Beispiel:
**  CT_data(1, &dad, &sad, length data, "data", length response, response);
**
** R�ckgabewerte:       OK          -> Funktionsaufruf war erfolgreich
**                      < 0         -> Fehlercode
**                      ERR_INVALID -> ung�ltiger Parameter oder Wert
**                      ERR_CT      -> CT-Fehler (CT nicht betriebsbereit)
**                      ERR_TRANS   -> nicht behebbarer �bertragungsfehler
**                      ERR_MEMORY  -> Antwort l�nger als angegeben
**                      ERR_HTSI    -> HTSI-Fehler
**
** ***************************************************************
*/

char CT_data (unsigned short ctn,
	      unsigned char * dad,       unsigned char * sad,
	      unsigned short cmd_len,    unsigned char * cmd_str,
	      unsigned short * resp_len, unsigned char * APDU_respstr);

#ifdef __cplusplus
} /* extern C */
#endif /* __cplusplus */

#endif
