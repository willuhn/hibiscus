
/*  $Id: InitAndTest.java,v 1.10 2004/01/14 12:07:23 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2003  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.kapott.hbci.callback.HBCICallbackConsole;
import org.kapott.hbci.manager.HBCIHandler;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.passport.AbstractHBCIPassport;
import org.kapott.hbci.passport.HBCIPassport;
import org.kapott.hbci.status.HBCIExecStatus;

/** <p>Tool zum Initialisieren und Testen eines HBCI-Passports.  Dieses Tool dient
    einerseits als Vorlage f�r die Benutzung von <em>HBCI4Java</em> in eigenen Anwendungen und
    gleichzeitig als Tool, um ein HBCI-Passport einzurichten und zu initialisieren.</p><p>
    F�r das Einrichten und Initialisieren eines HBCI-Passports gibt es keine
    speziellen Funktionen, statt dessen wird ein Passport einfach so benutzt, als
    ob es schon vorhanden w�re. Alle fehlenden Daten holt sich <em>HBCI4Java</em> selbstst�ndig
    entweder �ber den Callback-Mechanismus vom Anwender oder durch spezielle
    HBCI-Dialoge von der Bank.</p><p>
    Aus diesem Grund kann dieses Tool sowohl zum Testen eines schon existierenden Passports
    wie auch zum Einrichten eines neuen Passports verwendet werden, ohne etwas am
    Programmcode zu �ndern. In der gleichen Weise wie dieses Tool kann auch eine
    komplexere Anwendung <em>HBCI4Java</em> benutzen, in diesem Tool fehlt nur das Hinzuf�gen
    von Gesch�ftsvorf�llen zum HBCI-Dialog.</p><p>
    Beim Start des Programmes mit
    <code>java&nbsp;org.kapott.hbci.tools.InitAndTest</code>
    werden verschiedene Parameter �ber die Standardeingabe abgefragt.
    Konkret handelt es sich dabei um alle HBCI-Parameter, die f�r die Initialisierung
    eines Passports und dessen Verwendung ben�tigt werden. Die HBCI-Parameter werden mit
    den eingegeben Werten initialisiert. Anschlie�end wird ein Passport-Objekt erzeugt
    und ein "leerer" HBCI-Dialog (d.h. einer, der keine Gesch�ftsvorf�lle enth�lt) ausgef�hrt.</p><p>
    Bei diesem Vorgang sorgt <em>HBCI4Java</em> selbst daf�r, dass alle relevanten Daten vorhanden sind
    bzw. initialisiert diese entspechend. L�uft das Programm fehlerfrei durch, so ist sichergestellt,
    dass das benutzte Passport (=Sicherheitsmedium) korrekt initialisiert und funktionsbereit
    ist.</p> */
public final class InitAndTest
{
    private static HBCIPassport passport;
    private static HBCIHandler  hbciHandle;
    
    public static void main(String[] args)
        throws IOException
    {
        try {
            HBCIUtils.init(null,null,new HBCICallbackConsole());
            readBasicParams();

            readPassportParams();
            passport=AbstractHBCIPassport.getInstance();

            readHBCIVersion();

            passport.clearBPD();
            passport.clearUPD();
            hbciHandle=new HBCIHandler(HBCIUtils.getParam("client.passport.hbciversion.default"),
                                       passport);

            HBCIExecStatus ret=hbciHandle.execute();
            System.out.println("ExecStatus");
            System.out.println(ret.toString());
            System.out.println("ExecStatusEnd");
            System.out.println("ExecStatusError");
            System.out.println(ret.getErrorString());
            System.out.println("ExecStatusErrorEnd");
            
            System.out.println();
            System.out.println("finished.");
            System.out.println();
        } finally {
            if (hbciHandle!=null) {
                hbciHandle.close();
            } else if (passport!=null) {
                passport.close();
            }
        }
    }
    
    private static void readParam(String paramName,String def,String descr)
        throws IOException
    {
        System.out.println();
        System.out.println(descr);
        System.out.println("press ENTER to accept the default; '-' to set no value for this parameter");
        System.out.print(paramName+" ["+def+"]: ");
        
        String value=new BufferedReader(new InputStreamReader(System.in)).readLine();
        
        if (value.equals("-")) {
            value=null;
        } else if (value.length()==0) {
            value=def;
        }
        
        if (value!=null) {
            System.out.println(paramName+"="+value);
            HBCIUtils.setParam(paramName,value);
        }
    }
    
    private static void readBasicParams()
        throws IOException
    {
        readParam("client.connection.localPort",null,"local tcp-port to be used for outgoing connections");
        readParam("log.loglevel.default","4","loglevel for HBCI4Java-messages (from 0(no logging) to 5(really heavy)");
        readParam("kernel.rewriter",HBCIUtils.getParam("kernel.rewriter"),"rewriter modules to be activated");
    }
    
    private static void readPassportParams()
        throws IOException
    {
        readParam("client.passport.default",null,"enter type of media you have (Anonymous, DDV, RDHNew, RDH (deprecated), PinTan, SIZRDHFile or OpenHBCI)");
        String type=HBCIUtils.getParam("client.passport.default","");
        
        if (type.equals("Anonymous")) {
            readParam("client.passport.Anonymous.filename","passport_anon.dat","filename to be used for your HBCI4Java keyfile.");
            readParam("client.passport.Anonymous.init","1","never change this value!");
        } else if (type.equals("DDV")) {
            readParam("client.passport.DDV.path","./","the path where to store a file to cash information about your HBCI account");
            readParam("client.passport.DDV.libname.ddv","/home/kleiner/projects/hbci2/chipcard/lib/libhbci4java-card-linux.so","the name of the library needed to use the CTAPI interface of your chipcard terminal");
            readParam("client.passport.DDV.libname.ctapi","/usr/lib/libctapi-cyberjack.so","the name of the library containing the CTAPI interface to your chipcard terminal");
            readParam("client.passport.DDV.port","1","the port to which your chipcard terminal is connected (in most cases 1, 0 or 2)");
            readParam("client.passport.DDV.ctnumber","0","the logical number for your chipcard terminal, can be 0 in most cases");
            readParam("client.passport.DDV.usebio","0","use the biometric interface of Reiner-SCT chipcard terminals (0 or 1)");
            readParam("client.passport.DDV.softpin","0","use the keypad of your chipcard terminal (0) or your PC-keyboard (1) to enter the PIN for your HBCI chipcard");
            readParam("client.passport.DDV.entryidx","1","enter the index, which HBCI account stored on the card should be used");
        } else if (type.equals("RDH")) {
            readParam("client.passport.RDH.filename","my_passport.dat","filename to be used for your HBCI4Java keyfile. DONT LOOSE THIS FILE!");
            readParam("client.passport.RDH.init","1","never change this value!");
        } else if (type.equals("RDHNew")) {
            readParam("client.passport.RDHNew.filename","my_passport.dat","filename to be used for your HBCI4Java keyfile. DONT LOOSE THIS FILE!");
            readParam("client.passport.RDHNew.init","1","never change this value!");
        } else if (type.equals("PinTan")) {
            readParam("client.passport.PinTan.filename","my_passport_pintan.dat","filename to be used for your PIN/TAN keyfile");
            readParam("client.passport.PinTan.certfile","certificate.dat","filename with a SSL-certificate for HTTPS-communication");
            readParam("client.passport.PinTan.init","1","never change this value!");
        } else if (type.equals("SIZRDHFile")) {
            readParam("client.passport.SIZRDHFile.filename","secret.key","filename of SIZ-RDH-keyfile to be used. MAKE A BACKUP OF THIS FILE BEFORE USE!");
            readParam("client.passport.SIZRDHFile.libname","/usr/lib/libhbci4java-sizrdh.so","filename of native library for accessing SIZ RDH files");
            readParam("client.passport.SIZRDHFile.init","1","never change this value!");
        } else if (type.equals("OpenHBCI")) {
            readParam("client.passport.OpenHBCI.mediafile","passport_openhbci.dat","filename of OpenHBCI-keyfile to be used. MAKE A BACKUP OF THIS FILE BEFORE USE!");
            readParam("client.passport.OpenHBCI.datafile","/home/kleiner/.openhbci","filename of file with OpenHBCI institute and account information");
            readParam("client.passport.OpenHBCI.init","1","never change this value!");
        }
    }
    
    private static void readHBCIVersion()
        throws IOException
    {
        String pversion=passport.getHBCIVersion();
        readParam("client.passport.hbciversion.default",((pversion.length()!=0)?pversion:"210"),"the hbci-version to be used; may be '201', '210', '220' or 'plus'");
    }
}
