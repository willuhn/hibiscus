
/*  $Id: XMLCreator.java 62 2008-10-22 17:03:26Z kleiner $

    This file is part of HBCI4Java
    Copyright (C) 2001-2008  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.xml;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.kapott.hbci.manager.HBCIUtilsInternal;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/* TODO: Diese Klasse setzt im Moment nicht die Komplette XML-Schema-Spezifikation
 * um, sondern nur die Teile, die f�r die XML-Schemata der pain-Nachrichten
 * ben�tigt werden. */
public class XMLCreator 
{
	public static String uriSchema="http://www.w3.org/2001/XMLSchema";
	
	private DocumentBuilderFactory fac;
	private Element                schemaroot;
	private Map                    types;
	
	public XMLCreator(InputStream schemaStream) 
	{
		try {
			// schema-beschreibung einlesen
			this.fac=DocumentBuilderFactory.newInstance();
			this.fac.setIgnoringComments(true);
			this.fac.setIgnoringElementContentWhitespace(true);
			this.fac.setNamespaceAware(true);
			this.fac.setValidating(false);

			DocumentBuilder builder=fac.newDocumentBuilder();
			Document        schemadoc=builder.parse(schemaStream);
			
			this.schemaroot=schemadoc.getDocumentElement();

			// erst mal alle Typ-Definitionen in einer Hashtabelle abspeichern
			loadTypes("simpleType");
			loadTypes("complexType");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	private void loadTypes(String elemName)
	{
		if (types==null) {
			types=new Hashtable();
		}
		
		NodeList elements=schemaroot.getElementsByTagNameNS(uriSchema,elemName);
		int      l=elements.getLength();
		for (int i=0; i<l; i++) {
			Element elem=(Element)elements.item(i);
			String  typeName=elem.getAttribute("name");
			if (types.get(typeName)!=null) {
				throw new RuntimeException("duplicate definition of type "+typeName);
			}
			types.put(typeName, elem);
		}
		System.out.println("loaded "+l+" types of type "+elemName);
	}
	
	private void warnUnimplemented(Element elem, String[] implAttrs, String[] implChilds)
	{
		String elemName=elem.getNodeName();
		List   _implAttrs=Arrays.asList(implAttrs);
		List   _implChilds=Arrays.asList(implChilds);
		
		NamedNodeMap attrs=elem.getAttributes();
		int          l=attrs.getLength();
		for (int i=0; i<l; i++) {
			Attr   attr=(Attr)attrs.item(i);
			String attrName=attr.getName();
			if (!_implAttrs.contains(attrName)) {
				String attrValue=attr.getValue();
				System.out.println("warning: attribute "+attrName+"="+attrValue+" of element "+elemName+" not yet implemented");
			}
		}

		NodeList childs=elem.getChildNodes();
		         l=childs.getLength();
		for (int i=0; i<l; i++) {
			Node node=childs.item(i);
			if (node.getNodeType()==Node.ELEMENT_NODE) {
				Element child=(Element)node;
				String  childName=child.getLocalName();
				if (!_implChilds.contains(childName)) {
					String  childFullName=child.getNodeName();
					System.out.println("warning: child "+childFullName+" of element "+elemName+" not yet implemented");
				}
			}
		}
	}
	
	private void handleMinLength(Element schemaElem, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaElem, 
				new String[] {"value"}, 
				new String[] {"annotation"});

		int    minLength=Integer.parseInt(schemaElem.getAttribute("value"));

		Map myRestrictions=(Map)restrictions.get(targetPath);
		if (myRestrictions==null) {
			myRestrictions=new Hashtable();
			restrictions.put(targetPath,myRestrictions);
		}

		myRestrictions.put("minlen", new Integer(minLength));
	}

	private void handleMaxLength(Element schemaElem, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaElem, 
				new String[] {"value"}, 
				new String[] {"annotation"});

		int    maxLength=Integer.parseInt(schemaElem.getAttribute("value"));

		Map myRestrictions=(Map)restrictions.get(targetPath);
		if (myRestrictions==null) {
			myRestrictions=new Hashtable();
			restrictions.put(targetPath,myRestrictions);
		}

		myRestrictions.put("maxlen", new Integer(maxLength));
	}
	
	private void handlePattern(Element schemaElem, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaElem, 
				new String[] {"value"}, 
				new String[] {"annotation"});

		String pattern=schemaElem.getAttribute("pattern");

		Map myRestrictions=(Map)restrictions.get(targetPath);
		if (myRestrictions==null) {
			myRestrictions=new Hashtable();
			restrictions.put(targetPath,myRestrictions);
		}

		List patterns=(List)myRestrictions.get("pattern");
		if (patterns==null) {
			patterns=new ArrayList();
			myRestrictions.put("pattern",patterns);
		}

		patterns.add(pattern);
	}
	
	private void handleEnumeration(Element schemaElem, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaElem, 
				new String[] {"value"}, 
				new String[] {"annotation"});

		String enumvalue=schemaElem.getAttribute("value");

		Map myRestrictions=(Map)restrictions.get(targetPath);
		if (myRestrictions==null) {
			myRestrictions=new Hashtable();
			restrictions.put(targetPath,myRestrictions);
		}

		List valids=(List)myRestrictions.get("valids");
		if (valids==null) {
			valids=new ArrayList();
			myRestrictions.put("valids",valids);
		}

		valids.add(enumvalue);
	}
	
	private void handleRestriction(Element schemaRest, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaRest, 
				new String[] {"base"}, 
				new String[] {"annotation", "enumeration", "maxLength", "minLength", "pattern"});
		
		String baseType=schemaRest.getAttribute("base");
		handleType(baseType,rootdoc,target,targetPath,restrictions);
		
		NodeList childs=schemaRest.getChildNodes();
		int      l=childs.getLength();
		for (int i=0; i<l; i++) {
			Node node=childs.item(i);
			if (node.getNodeType()==Node.ELEMENT_NODE) {
				Element child=(Element)node;
				String  childName=child.getLocalName();
				if (childName.equals("minLength")) {
					handleMinLength(child,rootdoc,target,targetPath,restrictions);
				} else if (childName.equals("maxLength")) {
					handleMaxLength(child,rootdoc,target,targetPath,restrictions);
				} else if (childName.equals("pattern")) {
					handlePattern(child,rootdoc,target,targetPath,restrictions);
				} else if (childName.equals("enumeration")) {
					handleEnumeration(child,rootdoc,target,targetPath,restrictions);
				}
			}
		}
	}
	
	private void handleAttribute(Element schemaAttr, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaAttr, 
				new String[] {"name","type"}, 
				new String[] {});
		
		String name=schemaAttr.getAttribute("name");
		Attr attr=rootdoc.createAttribute(name);
		
		String type=schemaAttr.getAttribute("type");
		String newTargetPath=targetPath+":"+name;
		handleType(type,rootdoc,attr,newTargetPath,restrictions);

		((Element)target).setAttributeNode(attr);
		// mapping path -> element zu restrictions hinzuf�gen
		Map myRestrictions=(Map)restrictions.get(newTargetPath);
		if (myRestrictions==null) {
			myRestrictions=new Hashtable();
			restrictions.put(newTargetPath,myRestrictions);
		}
		myRestrictions.put("attribute",attr);

		// TODO: use = optional/required/prohibited auswerten
	}
	
	private void handleExtension(Element schemaRest, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaRest, 
				new String[] {"base"}, 
				new String[] {"annotation", "attribute"});

		String baseType=schemaRest.getAttribute("base");
		handleType(baseType,rootdoc,target,targetPath,restrictions);

		NodeList childs=schemaRest.getChildNodes();
		int      l=childs.getLength();
		for (int i=0; i<l; i++) {
			Node node=childs.item(i);
			if (node.getNodeType()==Node.ELEMENT_NODE) {
				Element child=(Element)node;
				String  childName=child.getLocalName();
				if (childName.equals("attribute")) {
					handleAttribute(child,rootdoc,target,targetPath,restrictions);
				}
			}
		}

	}
	
	private void handleSimpleType(Element schemaType, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaType, 
				new String[] {"name"}, 
				new String[] {"annotation", "restriction"});

		NodeList simpleChilds=schemaType.getChildNodes();
		int      l=simpleChilds.getLength();
		for (int i=0; i<l; i++) {
			Node node=simpleChilds.item(i);
			if (node.getNodeType()==Node.ELEMENT_NODE) {
				Element simpleChild=(Element)node;
				String  simpleChildType=simpleChild.getLocalName();
				
				if (simpleChildType.equals("restriction")) {
					handleRestriction(simpleChild,rootdoc,target,targetPath,restrictions);
				}
			}
		}
	}
	
	private void handleChoice(Element schemaChoice, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaChoice, 
				new String[] {}, 
				new String[] {"annotation","element"});
		
		NodeList childs=schemaChoice.getChildNodes();
		int      l=childs.getLength();
		
		// TODO: dieser teil kann im produkt-betrieb raus, hier werden
        // nur die anzahl der choices gez�hlt
		int nofChoices=0;
		for (int i=0; i<l; i++) {
			Node node=childs.item(i);
			if (node.getNodeType()==Node.ELEMENT_NODE) {
				nofChoices++;
			}
		}
		
		for (int i=0, counter=1; i<l; i++) {
			Node node=childs.item(i);
			if (node.getNodeType()==Node.ELEMENT_NODE) {
				Node comment=rootdoc.createComment(" choice #"+(counter++)+" of "+nofChoices+": ");
				target.appendChild(comment);
				
				Element child=(Element)node;
				String  childType=child.getLocalName();
				
				if (childType.equals("element")) {
					createAndHandleElement(child,rootdoc,target,targetPath,restrictions);
				}
			}
		}
	}
	
	private void handleSequence(Element schemaSeq, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaSeq, 
				new String[] {"name"}, 
				new String[] {"choice", "element"});
		
		NodeList seqChilds=schemaSeq.getChildNodes();
		int      l=seqChilds.getLength();
		for (int i=0; i<l; i++) {
			Node node=seqChilds.item(i);
			if (node.getNodeType()==Node.ELEMENT_NODE) {
				Element seqChild=(Element)node;
				String  seqChildType=seqChild.getLocalName();
				
				if (seqChildType.equals("element")) {
					createAndHandleElement(seqChild,rootdoc,target,targetPath,restrictions);
				} else if (seqChildType.equals("choice")) {
					handleChoice(seqChild,rootdoc,target,targetPath,restrictions);
				}
			}
		}
	}
	
	private void handleSimpleContent(Element schemaSC, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		warnUnimplemented(schemaSC, 
				new String[] {}, 
				new String[] {"annotation", "extension", "restriction"});
		
		NodeList simpleChilds=schemaSC.getChildNodes();
		int      l=simpleChilds.getLength();
		for (int i=0; i<l; i++) {
			Node node=simpleChilds.item(i);
			if (node.getNodeType()==Node.ELEMENT_NODE) {
				Element simpleChild=(Element)node;
				String  simpleChildType=simpleChild.getLocalName();
				
				if (simpleChildType.equals("restriction")) {
					handleRestriction(simpleChild,rootdoc,target,targetPath,restrictions);
				} else if (simpleChildType.equals("extension")) {
					handleExtension(simpleChild,rootdoc,target,targetPath,restrictions);
				}
			}
		}
	}
	
	private void handleComplexType(Element schemaType, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		// TODO: wenn dieses Element ein complexType ist, diesen analysieren
		// TODO: minOccurs/maxOccurs werden beim Erzeugen der Kind-Element
		// gepr�ft - an dieser Stelle ist es also zu sp�t, um schema.minOccurs
		// auszuwerten, denn das Element "target" ist ja schon da.
		
		/* jedes sub-element von typeDescr durchlaufen. kann sein:
		 *   - simpleContent (enth�lt eine restriction oder eine extension)
		 *   - complexContent (kommt nicht vor)
		 *   - choice
		 *   - sequence
		 *   - attribute
		 */
		
		// hier warnungen f�r alle attribute und inhalte von typeDesc
		// ausgeben, die wir hier nicht betrachten
		warnUnimplemented(schemaType, 
				new String[] {"name"}, 
				new String[] {"sequence", "simpleContent"});
		
		NodeList complexChilds=schemaType.getChildNodes();
		int      l=complexChilds.getLength();
		for (int i=0; i<l; i++) {
			Node node=complexChilds.item(i);
			if (node.getNodeType()==Node.ELEMENT_NODE) {
				Element complexChild=(Element)node;
				String  complexChildType=complexChild.getLocalName();
				
				if (complexChildType.equals("sequence")) {
					handleSequence(complexChild,rootdoc,target,targetPath,restrictions);
				} else if (complexChildType.equals("simpleContent")) {
					handleSimpleContent(complexChild,rootdoc,target,targetPath,restrictions);
				}
			}
		}
	}
	
	private void handleType(String typeName, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		if (typeName==null || typeName.length()==0) {
			throw new RuntimeException("Element description for '"+target.getLocalName()+"' has no type attribute");
		}
		
		Element typeDescr=(Element)types.get(typeName);
		if (typeDescr==null) {
			// es handelt sich um einen typen, der nicht explizit definiert wird
			// evtl. ist es ein vordefinierter typ...
			
			String[] nameParts=typeName.split(":",2);
			String   localName=nameParts[nameParts.length-1];
			if (localName.equals("string") || localName.equals("dateTime") || 
					localName.equals("date") || localName.equals("decimal")) 
			{
				// TODO: hier den richtigen wert anhand von target.getPath()
				// aus der wertemenge holen und eintragen
				if (target instanceof Attr) {
					((Attr)target).setValue(targetPath+"="+localName);
				} else if (target instanceof Element) {
					Node txt=rootdoc.createTextNode(targetPath+"="+localName);
					((Element)target).appendChild(txt);
				} else {
					throw new RuntimeException("target must be of type Attr or Element");
				}
			} else {
				throw new RuntimeException("type '"+typeName+"' used for element "+(target).getLocalName()+" not in table of types");
			}
			
		} else {
			// es handelt sich um einen datentypen, der im schema definiert wird
			String typeType=typeDescr.getLocalName();

			if (typeType.equals("simpleType")) {
				handleSimpleType(typeDescr, rootdoc, target, targetPath,restrictions);
			} else {
				handleComplexType(typeDescr, rootdoc, target, targetPath,restrictions);
			}
		}
	}
	
	private void handleElement(Element schemaElem, Document rootdoc, Node target, String targetPath,Map restrictions)
	{
		/* das schon erzeugte Element target soll um s�mtliche Informationen
		   aus Schema erweitert werden. dazu geh�ren
		     - default/fixed-Werte f�r Elemente und Attribute
		     - minOccurs/maxOccurs
		     - name (schema.name = target.elementName)
		     - referenzen auf andere elemente (werden momentan nicht benutzt)
		     - type - entweder als schema-attribut oder als content (simpleType, complexType)
		     
		   Momentan werden nur minOccurs/maxOccurs und type="..." verwendet,
		   anonyme Typ-Deklarationen kommen nicht vor.
		*/
		
		// hier warnungen ausgeben f�r alle attribute und inhalte von
		// schema, die hier noch nicht behandelt werden
		warnUnimplemented(schemaElem, 
				new String[] {"minOccurs","maxOccurs","name","type"}, 
				new String[] {"annotation","complexType","simpleType"});
		
		// den Daten-Typen des frischen Elementes "target" holen (ist entweder
		// ein simpleType oder ein complexType)
		String typeName=schemaElem.getAttribute("type");
		handleType(typeName,rootdoc,target,targetPath,restrictions);
	}
	
	private void createAndHandleElement(Element schemaElem,Document rootdoc,Node target,String targetPath,Map restrictions) 
	{
		// TODO: hier anhand von min/max  und den tats�chlich 
		// verf�gbaren werten entscheiden, wie viele childs
		// erzeugt werden m�ssen
		String min_s=schemaElem.getAttribute("minOccurs");
		int    min=1;
		if (min_s.length()!=0) {
			min=Integer.parseInt(min_s);
		}
		
		String max_s=schemaElem.getAttribute("maxOccurs");
		int    max=0;
		if (max_s.length()==0) {
			max=1;
		} else if (!max_s.equals("unbounded")) {
			max=Integer.parseInt(max_s);
		}
		
		String elemName=schemaElem.getAttribute("name");
		for (int j=0; j<Math.max(min,1); j++) {
			Element elem=rootdoc.createElement(elemName);
			if (min==0) {
				Node comment=rootdoc.createComment(" (optional) ");
				elem.appendChild(comment);
			}
			if (max!=1) {
				Node comment=rootdoc.createComment(" (max="+(max==0?"unlimited":Integer.toString(max))+") ");
				elem.appendChild(comment);
			}

			String newTargetPath=targetPath+"/"+HBCIUtilsInternal.withCounter(elemName,j);
			handleElement(schemaElem,rootdoc,elem,newTargetPath,restrictions);
			target.appendChild(elem);

			// mapping path -> element zu restrictions hinzuf�gen
			Map myRestrictions=(Map)restrictions.get(newTargetPath);
			if (myRestrictions==null) {
				myRestrictions=new Hashtable();
				restrictions.put(newTargetPath,myRestrictions);
			}
			myRestrictions.put("element",elem);
		}
	}
        
	private Text getOrCreateTextNode(Document rootdoc, Element elem)
	{
		Text     ret=null;
		NodeList childs=elem.getChildNodes();
		int      l=childs.getLength();
		for (int i=0; i<l; i++) {
			Node node=childs.item(i);
			if (node.getNodeType()==Node.TEXT_NODE) {
				ret=(Text)node;
				break;
			}
		}

		if (ret==null) {
			ret=rootdoc.createTextNode("");
			elem.appendChild(ret);
		}

		return ret;
	}
	
	public void createXMLFromSchemaAndData(Properties data, OutputStream outStream)
	{
		try {
			// dieses Element ist ein xsd:element-Knoten, der das erste target-element beschreibt
			NodeList elements=schemaroot.getElementsByTagNameNS(uriSchema,"element");
			if (elements.getLength()==0) {
				throw new RuntimeException("there is no top level 'element' declaration in the schema");
			}
			Element rootDescr=(Element)elements.item(0);

			// targetdoc ist das target-document
			DocumentBuilder builder2=this.fac.newDocumentBuilder();
			Document        targetdoc=builder2.newDocument();

			// im targetdoc muss zun�chst der root-knoten erzeugt werden, der
			// wird in elemDescr beschrieben
			String  rootName=rootDescr.getAttribute("name");
			Element targetroot=targetdoc.createElement(rootName);

			// beginnend beim wurzel-elemente alle childs erzeugen
			Map restrictions=new Hashtable();
			handleElement(rootDescr, targetdoc, targetroot, rootName, restrictions);

			// restrictions validieren

			// alle "valids" pr�fen - wenn es nur einen valid gibt, diesen
			// automatisch setzen
			for (Iterator i=restrictions.keySet().iterator(); i.hasNext(); ) {
				String path=(String)i.next();
				Map    myRestrictions=(Map)restrictions.get(path);

				List   valids=(List)myRestrictions.get("valids");
				if (valids!=null) {
					// TODO: wenn schon ein wert existiert, diesen gegen valids checken

					// wenn noch kein wert existiert und len(valids)==1,
					// dann diesen einen wert automatisch setzen;
					// das ganze f�r "element" und "attribute"
					if (valids.size()==1) {
						Element elem=(Element)myRestrictions.get("element");
						if (elem!=null) {
							// TODO: hier noch �berpr�fen, ob nicht schon
							// ein evtl. falscher Wert drin steht
							Text txt=getOrCreateTextNode(targetdoc,elem);
							txt.setData((String)valids.get(0));
						}

						Attr attr=(Attr)myRestrictions.get("attribute");
						if (attr!=null) {
							// TODO: hier noch �berpr�fen, ob nicht schon
							// ein evtl. falscher Wert drin steht
							attr.setValue((String)valids.get(0));
						}
					}
				}
			}

			// targetdocument rausschreiben
			TransformerFactory tfac=TransformerFactory.newInstance();
			Transformer        trans=tfac.newTransformer();

			trans.setOutputProperty("encoding", "UTF-8");
			trans.setOutputProperty("indent", "yes");
			trans.setOutputProperty("standalone", "yes");
			trans.setOutputProperty("{http://xml.apache.org/xalan}indent-amount", "2");

			System.out.println("transformer properties:");
			Properties p=trans.getOutputProperties();
			for (Enumeration e=p.propertyNames(); e.hasMoreElements(); ) {
				String key=(String)e.nextElement();
				String value=p.getProperty(key);
				System.out.println("  "+key+"="+value);
			}

			Source tsrc=new DOMSource(targetroot);
			Result tdst=new StreamResult(outStream);
			trans.transform(tsrc,tdst);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static void main(String[] args)
		throws Exception
	{
		FileInputStream f=new FileInputStream(args[0]);
		XMLCreator creator=new XMLCreator(f);
		creator.createXMLFromSchemaAndData(new Properties(), System.out);
	}
}
