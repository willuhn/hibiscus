
/*  $Id: HBCICardService.java,v 1.8 2007/12/21 09:08:19 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.ocf;

import java.util.Arrays;

import opencard.core.service.CardService;
import opencard.core.terminal.CHVControl;
import opencard.core.terminal.CHVEncoder;
import opencard.core.terminal.CardTerminalIOControl;
import opencard.core.terminal.ResponseAPDU;
import opencard.opt.terminal.ISOCommandAPDU;
import opencard.opt.terminal.TerminalCommand;

import org.kapott.hbci.manager.HBCIUtils;

public abstract class HBCICardService 
    extends CardService
{
    public static final int PIN_FORMAT_ASCII=0;
    public static final int PIN_FORMAT_PIN2=1;
    
    protected static final int HBCI_DDV_EF_ID=0x19;
    protected static final int HBCI_DDV_EF_BNK=0x1A;
    protected static final int HBCI_DDV_EF_MAC=0x1B;
    protected static final int HBCI_DDV_EF_SEQ=0x1C;
    
    protected static final int HBCI_RSA_EF_BNK=0xa603;
    
    protected static final byte SECCOS_CLA_EXT=(byte)0xb0;
    protected static final byte SECCOS_CLA_SM_PROPR=(byte)0x04;
    protected static final byte SECCOS_CLA_SM1=(byte)0x08;
    protected static final byte SECCOS_CLA_STD=(byte)0x00;
    
    protected static final byte SECCOS_INS_GET_CHALLENGE=(byte)0x84;
    protected static final byte SECCOS_INS_GET_KEYINFO=(byte)0xee;
    protected static final byte SECCOS_INS_INT_AUTH=(byte)0x88;
    protected static final byte SECCOS_INS_PUT_DATA=(byte)0xda;
    protected static final byte SECCOS_INS_READ_BINARY=(byte)0xb0;
    protected static final byte SECCOS_INS_READ_RECORD=(byte)0xb2;
    protected static final byte SECCOS_INS_SELECT_FILE=(byte)0xa4;
    protected static final byte SECCOS_INS_VERIFY=(byte)0x20;
    protected static final byte SECCOS_INS_UPDATE_RECORD=(byte)0xdc;
    protected static final byte SECCOS_INS_WRITE_RECORD=(byte)0xd2;
    
    protected static final byte SECCOS_SELECT_RET_NOTHING=(byte)0x0c;
    
    protected static final byte SECCOS_KEY_TYPE_DF=(byte)0x80;
    protected static final byte SECCOS_PWD_TYPE_DF=(byte)0x80;
    
    protected static final byte SECCOS_SM_CRT_CC=(byte)0xb4;
    protected static final byte SECCOS_SM_REF_INIT_DATA=(byte)0x87;
    protected static final byte SECCOS_SM_RESP_DESCR=(byte)0xba;
    protected static final byte SECCOS_SM_VALUE_LE=(byte)0x96;
    
    protected abstract String      getAID();
    
    public void verifyHardPIN_richtig(boolean useBio, int pwdId, int pinFormat)
    {
        try {
            allocateCardChannel();
            
            // TODO: useBio implementieren
            
            byte[] body;
            if (pinFormat==PIN_FORMAT_PIN2) {
                body=new byte[] {
                    (byte)0x25, (byte)0xff, (byte)0xff, (byte)0xff, 
                    (byte)0xff, (byte)0xff, (byte)0xff, (byte)0xff};
            } else {
                body=new byte[] {
                    (byte)0x20, (byte)0x20, (byte)0x20, (byte)0x20, 
                    (byte)0x20, (byte)0x20, (byte)0x20, (byte)0x20};
            }
            
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_VERIFY,
                (byte)0x00, (byte)(SECCOS_PWD_TYPE_DF|pwdId),
                body);
            
            CardTerminalIOControl ioControl=new CardTerminalIOControl(0,60,null,null);
            CHVControl            chvControl=new CHVControl(null,1,CHVEncoder.BCD_ENCODING,1,ioControl);
            // TODO: hier callback-gesteuerten Dialog einbauen
            // CHVDialog             chvDialog=new DefaultCHVDialog();
            ResponseAPDU          response=getCardChannel().sendVerifiedAPDU(command,chvControl,null);
            
            if (response.sw1()!=(byte)0x90) {
                throw new RuntimeException("verifyHardPin: "+response);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
    }
    
    /* TODO: das ist ein h�sslicher Hack, der das VERIFY-Kommando direkt an
     * das Terminal sendet, anstatt die OCF-Funktion "sendVerifiedAPDU" zu
     * benutzen, weil die OCF-Funktion im Moment nicht funktioniert.
     * Grund daf�r: es gibt scheinbar keine CardTerminal-Klassen, die das
     * VerifiedAPDUInterface implementieren. Deshalb wird immer automatisch
     * die GUI-basierte PIN-Abfrage gestartet. Die daf�r verwendete Klasse
     * opencard.core.service.CardHolderVerificationGUI unterst�tzt wiederum
     * nur das STRING_ENCODING f�r PINs, aber nicht das ben�tigte BCD_ENCODING.
     * TODO: damit das hier verwendete sendTerminalCommand() auch funktioniert,
     * muss im Quellcode der OCFPCSC1-Bibliothek das Kommando SCardControl()
     * wieder aktiviert werden (ist per default deaktiviert). */
    public void verifyHardPIN(boolean useBio, int pwdId, int pinFormat)
    {
        try {
            allocateCardChannel();
            
            byte[] command;
            if (pinFormat==PIN_FORMAT_PIN2) {
            	command=new byte[] {
            			(byte)0x20, (byte)0x18, (byte)0x01, useBio?(byte)0x01:(byte)0x00,
            			(byte)0x11,
            			(byte)0x52, (byte)0x0f,
            			(byte)0x00, (byte)0x07,
            			SECCOS_CLA_STD, SECCOS_INS_VERIFY,
            			(byte)0x00, (byte)(SECCOS_PWD_TYPE_DF|pwdId),
            			(byte)0x08,
            			(byte)0x25, (byte)0xff, (byte)0xff, (byte)0xff, 
            			(byte)0xff, (byte)0xff, (byte)0xff, (byte)0xff};
            } else {
                command=new byte[] {
            			(byte)0x20, (byte)0x18, (byte)0x01, useBio?(byte)0x01:(byte)0x00,
            			(byte)0x11,
            			(byte)0x52, (byte)0x0f,
            			(byte)0x00, (byte)0x07,
            			SECCOS_CLA_STD, SECCOS_INS_VERIFY,
            			(byte)0x08,
                		(byte)0x00, (byte)(SECCOS_PWD_TYPE_DF|pwdId),
                		(byte)0x20, (byte)0x20, (byte)0x20, (byte)0x20, 
                		(byte)0x20, (byte)0x20, (byte)0x20, (byte)0x20};
            }
            
            TerminalCommand terminal=(TerminalCommand)(getCardChannel().getCardTerminal());
            byte[] response=terminal.sendTerminalCommand(command);
            
            StringBuffer response_sb=new StringBuffer();
            if (response!=null) {
            	for (int i=0;i<response.length;i++) {
            		int x=response[i];
            		if (x<0) {
            			x+=256;
            		}
            		response_sb.append(Integer.toString(x,16)+" ");
            	}
            }
            HBCIUtils.log("response of 'PERFORM VERIFY': "+response_sb.toString(), HBCIUtils.LOG_DEBUG2);
            
            if (response==null || response.length<2 || response[response.length-2]!=(byte)0x90) {
                throw new RuntimeException("wrong PIN: "+response_sb);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
    }
    
    public void verifySoftPIN(int pwdId, byte[] softPin, int pinFormat)
    {
        try {
            allocateCardChannel();
            
            byte[] body;
            
            if (pinFormat==PIN_FORMAT_PIN2) {
                body=new byte[] {
                    (byte)0x25, (byte)0xff, (byte)0xff, (byte)0xff, 
                    (byte)0xff, (byte)0xff, (byte)0xff, (byte)0xff};
            
                // pin bcd-kodiert in pin-2-block schreiben
                for (int i=0;i<softPin.length;i++) {
                    body[1+(i>>1)]&=(byte)(((0x0F)<<(4*(i&1)))&0xFF);
                    body[1+(i>>1)]|=(byte)(((softPin[i]-(byte)0x30) << (4-(4*(i&1))))&0xFF);
                }
            } else {
                body=new byte[8];
                Arrays.fill(body,(byte)0x20);
                System.arraycopy(softPin,0,body,0,softPin.length);
            }
            
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_VERIFY,
                (byte)0x00, (byte)(SECCOS_PWD_TYPE_DF|pwdId),
                body);
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90) {
                throw new RuntimeException("verifySoftPin: "+response);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
    }
    
    protected byte[] expand(String st,int len)
    {
        try {
            StringBuffer st_new=new StringBuffer(st);
            for (int i=st.length();i<len;i++) {
                st_new.append(" ");
            }
            return st_new.toString().getBytes("ISO-8859-1");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    protected void writeRecordBySFI(int sfi, int idx, byte[] data)
    {
        try {
            allocateCardChannel();
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_WRITE_RECORD,
                (byte)(idx+1), (byte)((sfi<<3)|0x04),
                data);
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90) {
                throw new RuntimeException("writeRecordBySFI("+sfi+","+idx+"): "+response);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
    }
    
    protected void writeRecord(int idx, byte[] data)
    {
        writeRecordBySFI(0,idx,data);
    }
    
    protected void updateRecordBySFI(int sfi, int idx, byte[] data)
    {
        try {
            allocateCardChannel();
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_UPDATE_RECORD,
                (byte)(idx+1), (byte)((sfi<<3)|0x04),
                data);
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90) {
                throw new RuntimeException("updateRecordBySFI("+sfi+","+idx+"): "+response);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
    }
    
    protected void updateRecord(int idx, byte[] data)
    {
        updateRecordBySFI(0,idx,data);
    }
    
    protected byte[] readBinary()
    {
        byte[] ret=null;
        
        try {
            allocateCardChannel();
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_READ_BINARY,
                (byte)0x00, (byte)0x00,
                0);
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90 && response.sw1()!=(byte)0x61) {
            	throw new RuntimeException("readBinary: "+response);
            }
            ret=response.data();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
        
        return ret;
    }
    
    protected byte[] readRecordBySFI(int sfi, int idx)
    {
        byte[] ret=null;
        
        try {
            allocateCardChannel();
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_READ_RECORD,
                (byte)(idx+1), (byte)((sfi<<3)|0x04),
                0);
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90 && response.sw1()!=(byte)0x61) {
            	throw new RuntimeException("readRecordBySFI("+sfi+","+idx+"): "+response);
            }
            ret=response.data();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
        
        return ret;
    }
    
    protected byte[] readRecord(int idx)
    {
        return readRecordBySFI(0x00, idx);
    }
    
    protected void selectRoot()
    {
        try {
            allocateCardChannel();
            
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_SELECT_FILE,
                (byte)0x00, SECCOS_SELECT_RET_NOTHING,
                new byte[] {(byte)0x3f, (byte)0x00});
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90) {
                throw new RuntimeException("selectRoot: "+response);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
    }
    
    protected void selectSubFile(int id)
    {
        try {
            allocateCardChannel();
            
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_SELECT_FILE,
                (byte)0x02, SECCOS_SELECT_RET_NOTHING,
                new byte[] {(byte)((id>>8)&0xFF), (byte)(id&0xFF)});
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90) {
                throw new RuntimeException("selectSubFile("+id+"): "+response);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
    }
    
    protected void selectFileByAID(byte[] aid)
    {
        try {
            allocateCardChannel();
            
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_SELECT_FILE,
                (byte)0x04, SECCOS_SELECT_RET_NOTHING,
                aid);
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90) {
                throw new RuntimeException("selectFileByAID: "+response);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
    }
    
    protected byte[] getKeyInfo(int idx)
    {
        byte[] ret=null;
        
        try {
            allocateCardChannel();
            
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_EXT, SECCOS_INS_GET_KEYINFO,
                SECCOS_KEY_TYPE_DF, (byte)(idx+1),
                0);
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90 && response.sw1()!=(byte)0x61) {
            	throw new RuntimeException("getKeyInfo("+idx+"): "+response);
            }
            ret=response.data();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
        
        return ret;
    }
    
    protected void putData(int tag,byte[] data)
    {
        try {
            allocateCardChannel();
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_PUT_DATA,
                (byte)((tag>>8)&0xFF), (byte)(tag&0xFF),
                data);
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90) {
                throw new RuntimeException("putData: "+response);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
    }
    
    protected byte[] getChallenge()
    {
        byte[] ret=null;
        
        try {
            allocateCardChannel();
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_GET_CHALLENGE,
                (byte)0x00, (byte)0x00,
                8);
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90 && response.sw1()!=(byte)0x61) {
            	throw new RuntimeException("getChallenge: "+response);
            }
            ret=response.data();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
        
        return ret;
    }
    
    protected byte[] internalAuthenticate(int keynum, byte[] challenge)
    {
        byte[] ret=null;
        
        try {
            allocateCardChannel();
            ISOCommandAPDU command=new ISOCommandAPDU(
                SECCOS_CLA_STD, SECCOS_INS_INT_AUTH,
                (byte)0x00, (byte)(SECCOS_KEY_TYPE_DF|keynum),
                challenge,
                8);
            
            ResponseAPDU response=getCardChannel().sendCommandAPDU(command);
            if (response.sw1()!=(byte)0x90 && response.sw1()!=(byte)0x61) {
            	throw new RuntimeException("internalAuthenticate: "+response);
            }
            ret=response.data();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
        
        return ret;
    }
}
