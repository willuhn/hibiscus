
/*  $Id: CTServiceFactory.java,v 1.3 2007/08/29 12:53:30 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.ocf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;


import opencard.core.service.CardChannel;
import opencard.core.service.CardServiceFactory;
import opencard.core.service.CardServiceScheduler;
import opencard.core.service.CardType;
import opencard.core.terminal.CardID;
import opencard.core.terminal.CardTerminalException;
import opencard.core.terminal.ResponseAPDU;
import opencard.opt.terminal.ISOCommandAPDU;

/** CardServiceFactory-Klasse f�r DDVOCF-Passport. Diese Klasse wird nur intern
 * von {@link org.kapott.hbci.passport.HBCIPassportDDVOCF} verwendet. */
public class CTServiceFactory
    extends CardServiceFactory
{

    /* Gibt entweder CardType(0) f�r DDV-Typ-0-, CardType(1) f�r DDV-Typ-1-Karten
     * oder CardType.UNSUPPORTED f�r nicht unterst�tzte Chipkarten zur�ck. */
    protected CardType getCardType(CardID cardId,CardServiceScheduler scheduler)
        throws CardTerminalException
    {
        CardType    ret=CardType.UNSUPPORTED;
        CardChannel channel=scheduler.allocateCardChannel(this,true);
        
        // select AID f�r DDV-Typ-1
        ISOCommandAPDU command=new ISOCommandAPDU(
            (byte)0x00, (byte)0xa4, 
            (byte)0x04, (byte)0x0c, 
            new byte[] {(byte)0xd2, (byte)0x76, (byte)0x00, (byte)0x00, (byte)0x25, (byte)0x48, (byte)0x42, (byte)0x02, (byte)0x00});
        ResponseAPDU response=channel.sendCommandAPDU(command);
        if (response.sw1()==(byte)0x90 || response.sw1()==0x61) {
            // select hat funktioniert - DDV-Typ-1 gefunden
            ret=new CardType(1);
        } else {
            // select AID f�r DDV-Typ-0 
            command=new ISOCommandAPDU(
                (byte)0x00, (byte)0xa4, 
                (byte)0x04, (byte)0x0c, 
                new byte[] {(byte)0xd2, (byte)0x76, (byte)0x00, (byte)0x00, (byte)0x25, (byte)0x48, (byte)0x42, (byte)0x01, (byte)0x00});
            response=channel.sendCommandAPDU(command);
            if (response.sw1()==(byte)0x90 || response.sw1()==0x61) {
                // select hat geklappt, DDV Typ 0 gefunden
                ret=new CardType(0);
            } else {
                // select AID f�r RSA-Chipkarten 
                command=new ISOCommandAPDU(
                    (byte)0x00, (byte)0xa4, 
                    (byte)0x04, (byte)0x0c, 
                    new byte[] {(byte)0xd2, (byte)0x76, (byte)0x00, (byte)0x00, (byte)0x74, (byte)0x48, (byte)0x42, (byte)0x01, (byte)0x10});
                response=channel.sendCommandAPDU(command);
                if (response.sw1()==(byte)0x90 || response.sw1()==0x61) {
                    // select hat geklappt, RSA gefunden
                    ret=new CardType(16);
                }
            }
        }
        
        scheduler.releaseCardChannel(channel);
        return ret;
    }

    protected Enumeration getClasses(CardType cardType)
    {
        ArrayList classes=new ArrayList();
        
        // je nach kartentyp entweder die Typ-0- oder die Typ-1-Implementation
        // des DDV-CardService zur�ckgeben
        switch (cardType.getType()) {
            case 0:
                classes.add(DDVCardService0.class);
                break;
            case 1:
                classes.add(DDVCardService1.class);
                break;
            case 16:
                classes.add(RSACardService.class);
                break;
            default:
                return null;
        }
        
        return Collections.enumeration(classes);
    }

}
