
/*
 * Created on 20.10.2005
 */
package org.kapott.hbci.GV;

import java.util.Properties;

import org.kapott.hbci.GV_Result.GVRSaldoReq;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.passport.HBCIPassportInternal;

/**
 * @author stefan.palme
 */
public class GVTAN2Step 
    extends HBCIJobImpl
{
    private GVTAN2Step  otherTAN2StepTask;
    private HBCIJobImpl origTask;
    
    public static String getLowlevelName()
    {
        return "TAN2Step";
    }
    
    public GVTAN2Step(HBCIPassportInternal passport)
    {
        super(getLowlevelName(),passport,new GVRSaldoReq());

        addConstraint("process","process",null);
        addConstraint("orderhash","orderhash","");
        addConstraint("orderref","orderref","");
        addConstraint("listidx","listidx","");
        addConstraint("notlasttan","notlasttan","N");
        addConstraint("info","info","");
    }
    
    public void setParam(String paramName, String value)
    {
        if (paramName.equals("orderhash")) {
            value="B"+value;
        }
        super.setParam(paramName,value);
    }

    public void storeOtherTAN2StepTask(GVTAN2Step other)
    {
        this.otherTAN2StepTask=other;
    }
    
    public void storeOriginalTask(HBCIJobImpl task)
    {
        this.origTask=task;
    }
    
    protected void extractResults(Properties result,String header,int idx)
    {
        String segcode=result.getProperty(header+".SegHead.code");
        HBCIUtils.log("*** found HKTAN response with segcode "+segcode,HBCIUtils.LOG_DEBUG);
        
        if (origTask!=null && new StringBuffer(origTask.getHBCICode()).replace(1,2,"I").toString().equals(segcode)) {
            // das ist f�r PV#2, wenn nach dem nachtr�glichen versenden der TAN das
            // antwortsegment des jobs aus der vorherigen Nachricht zur�ckommt
            HBCIUtils.log("*** this is a response segment for the original task - storing results in the original job",HBCIUtils.LOG_DEBUG);
            origTask.extractResults(result,header,idx);
        } else {
            HBCIUtils.log("*** this is a \"real\" HKTAN response - analyzing HITAN data",HBCIUtils.LOG_DEBUG);
            
            String challenge=result.getProperty(header+".challenge");
            if (challenge!=null) {
                HBCIUtils.log("*** found challenge '"+challenge+"' in HITAN - saving it temporarily in passport",HBCIUtils.LOG_DEBUG);
                // das ist f�r PV#1 (die antwort auf das einreichen des auftrags-hashs) oder 
                // f�r PV#2 (die antwort auf das einreichen des auftrages)
                // in jedem fall muss mit der n�chsten nachricht die TAN �bertragen werden
                getMainPassport().setPersistentData("pintan_challenge",challenge);
                
                // TODO: f�r prozessvariante 1 muss hier evtl. noch �berpr�ft werden, ob
                // TODO: der zur�ckgegebene auftragshashwert mit dem urspr�nglich versandten
                // TODO: �bereinstimmt
            }
            
            String orderref=result.getProperty(header+".orderref");
            if (orderref!=null) {
                // orderref ist nur f�r PV#2 relevant
                HBCIUtils.log("*** found orderref '"+orderref+"' in HITAN",HBCIUtils.LOG_DEBUG);
                if (otherTAN2StepTask!=null) {
                    // hier sind wir ganz sicher in PV#2. das hier ist die antwort auf das
                    // erste HKTAN (welches mit dem eigentlichen auftrag verschickt wird)
                    // die orderref muss im zweiten HKTAN-job gespeichert werden, weil in
                    // dieser zweiten nachricht dann die TAN mit �bertragen werden muss
                    HBCIUtils.log("*** storing it in following HKTAN task",HBCIUtils.LOG_DEBUG);
                    otherTAN2StepTask.setParam("orderref",orderref);
                } else {
                    HBCIUtils.log("*** no other HKTAN task known - ignoring orderref",HBCIUtils.LOG_DEBUG);
                }
            }
            
        }
    }
}
