
/*  $Id: HBCIPassportRDH2File.java,v 1.14 2007/12/23 17:55:09 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.passport;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.kapott.hbci.callback.HBCICallback;
import org.kapott.hbci.exceptions.HBCI_Exception;
import org.kapott.hbci.manager.HBCIKey;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.manager.HBCIUtilsInternal;
import org.kapott.hbci.manager.LogFilter;
import org.kapott.hbci.passport.rdh2file.HBCIAccount;
import org.kapott.hbci.passport.rdh2file.RDH2File;
import org.kapott.hbci.passport.rdh2file.TLV;

/**<p>
 * Passport-Klasse f�r die Verwendung von RDH-2-Schl�sseldateien mit
 * <em>HBCI4Java</em>. RDH-2-Schl�sseldateien sind Schl�sseldateien f�r
 * RDH-Zug�nge, die von anderer HBCI-Software erzeugt und verwendet werden (z.B.
 * von <em>VR-NetWorld</em>). Soll eine solche Schl�sseldatei sowohl mit der
 * anderen Software als auch mit <em>HBCI4Java</em> verwendet werden, so kann
 * das mit dieser Passport-Variante geschehen.</p> */    
// TODO: Das Konvertieren eines anderen RDH-Passports in ein RDH-2-File wird u.U.
// schwierig. Grund: In RDH-2-Files MUSS die Schl�sselnummer laut Spez. immer 2
// sein. Wenn der Key in dem anderen Passport eine andere Schl�sselnummer hat,
// wird es u.U. sehr schwierig, diesen Key zu migrieren.
public class HBCIPassportRDH2File
    extends AbstractRDHSWFileBasedPassport
{
    private byte[]   passphrase;
    private RDH2File filecontent;
    private int      entryIdx;
    
    public HBCIPassportRDH2File(Object init,int dummy)
    {
        super(init);
    }

    public HBCIPassportRDH2File(Object initObject)
    {
        this(initObject,0);
        setParamHeader("client.passport.RDH2File");

        String fname=HBCIUtils.getParam(getParamHeader()+".filename");
        HBCIUtils.log(HBCIUtilsInternal.getLocMsg("INFO_PASS_LOADFILE",fname),HBCIUtils.LOG_DEBUG);
        setFilename(fname);

        boolean init=HBCIUtils.getParam(getParamHeader()+".init").equals("1");
        if (init) {
            HBCIUtils.log(HBCIUtilsInternal.getLocMsg("DBG_PASS_LOADDATE",getFilename()),HBCIUtils.LOG_DEBUG);

            setFilterType("None");
            setPort(new Integer(3000));

            if (!new File(getFilename()).canRead()) {
                HBCIUtils.log(HBCIUtilsInternal.getLocMsg("WRN_PASS_NEWFILE"),HBCIUtils.LOG_WARN);
                askForMissingData(true,true,true,false,false,true,true);
                saveChanges();
            }
            
            try {
                if (this.passphrase==null) {
                    StringBuffer retData=new StringBuffer();
                    HBCIUtilsInternal.getCallback().callback(this,
                            HBCICallback.NEED_PASSPHRASE_LOAD,
                            HBCIUtilsInternal.getLocMsg("CALLB_NEED_PASS"),
                            HBCICallback.TYPE_SECRET,
                            retData);
                    // TODO: passwort-bedingungen nach spez. pr�fen
                    LogFilter.getInstance().addSecretData(retData.toString(),"X",LogFilter.FILTER_SECRETS);
                    setPassphrase(retData.toString().getBytes());
                }
            	
            	// daten einlesen
                FileInputStream fin=new FileInputStream(fname);
                StringBuffer    sb=new StringBuffer();
                byte[]          buffer=new byte[1024];
                int             size;
                
                while ((size=fin.read(buffer))>0) {
                    sb.append(new String(buffer,0,size,"ISO-8859-1"));
                }
                
                fin.close();
                byte[] data=sb.toString().getBytes("ISO-8859-1");
                // System.out.println("read "+data.length+" bytes from "+getFileName());
                
                // filecontent-content
                this.filecontent=new RDH2File(data, passphrase);
                this.entryIdx=0;
                
                TLV[] hbciAccounts=filecontent.getFields(HBCIAccount.class);
                if (hbciAccounts.length>1) {
                    // wenn mehrere bankverbindungen existieren, callback f�r auswahl der "richtigen"
                    StringBuffer possibilities=new StringBuffer();
                    for (int i=0;i<hbciAccounts.length;i++) {
                        HBCIAccount hbciAccount=(HBCIAccount)hbciAccounts[i];
                        if (i!=0) {
                            possibilities.append("|");
                        }
                        possibilities.append(i);
                        possibilities.append(";"+hbciAccount.getBLZ());
                        possibilities.append(";"+hbciAccount.getUserId());
                    }
                    
                    HBCIUtilsInternal.getCallback().callback(
                        this,
                        HBCICallback.NEED_SIZENTRY_SELECT,
                        "*** select one of the following entries",
                        HBCICallback.TYPE_TEXT,
                        possibilities);
                     
                    this.entryIdx=Integer.parseInt(possibilities.toString());
                }
                
                TLV[] accountFields=filecontent.getFields(HBCIAccount.class);
                if (accountFields.length!=0) {
                    // set all passport values
                    HBCIAccount hbciAccount=(HBCIAccount)(accountFields[entryIdx]);

                    setCountry(hbciAccount.getCountry());
                    setBLZ(hbciAccount.getBLZ());
                    setHost(hbciAccount.getHost());
                    setUserId(hbciAccount.getUserId());
                    setCustomerId(hbciAccount.getCustomerId());
                    setSysId(hbciAccount.getSysId());
                    setSigId(new Long(hbciAccount.getSigId()));

                    // setInstKeys()
                    setInstSigKey(filecontent.getBankSigKey(hbciAccount));
                    setInstEncKey(filecontent.getBankEncKey(hbciAccount));

                    // setUserSigKeys()
                    HBCIKey[] userkeys=hbciAccount.getUserSigKeys();
                    if (userkeys!=null) {
                        setMyPublicSigKey(userkeys[0]);
                        setMyPrivateSigKey(userkeys[1]);
                    }

                    // setUserEncKeys()
                    userkeys=hbciAccount.getUserEncKeys();
                    if (userkeys!=null) {
                        setMyPublicEncKey(userkeys[0]);
                        setMyPrivateEncKey(userkeys[1]);
                    }
                }
                                
                if (askForMissingData(true,true,true,false,false,true,true))
                    saveChanges();
            } catch (Exception e) {
                throw new HBCI_Exception("*** error while reading passport file",e);
            }
        }
    }
    
    public void saveChanges()
    {
        try {
            if (this.passphrase == null) {
                StringBuffer retData = new StringBuffer();
                HBCIUtilsInternal.getCallback().callback(this,
                        HBCICallback.NEED_PASSPHRASE_SAVE,
                        HBCIUtilsInternal.getLocMsg("CALLB_NEED_PASS"),
                        HBCICallback.TYPE_SECRET, retData);
                // TODO: passwort-bedingungen nach spez. pr�fen
                LogFilter.getInstance().addSecretData(retData.toString(),"X",LogFilter.FILTER_SECRETS);
                setPassphrase(retData.toString().getBytes());
            }

            // create temp file
            File passportfile = new File(getFilename());
            File directory = passportfile.getAbsoluteFile().getParentFile();
            String prefix = passportfile.getName() + "_";
            File tempfile = File.createTempFile(prefix, "", directory);
            
            if (filecontent==null) {
                filecontent=new RDH2File(passphrase);
            }

            TLV[]       accountFields=filecontent.getFields(HBCIAccount.class);
            HBCIAccount hbciAccount;
            if (accountFields.length==0) {
                hbciAccount = new HBCIAccount();
                filecontent.addField(hbciAccount);
                
                hbciAccount.setCountry(getCountry());
            } else {
                hbciAccount = (HBCIAccount)(accountFields[entryIdx]); 
            }
            
            // save changed values in filecontent object
            hbciAccount.setCountry(getCountry());
            hbciAccount.setBLZ(getBLZ());
            hbciAccount.setHost(getHost());
            hbciAccount.setUserId(getUserId());
            hbciAccount.setCustomerId(getCustomerId());
            hbciAccount.setSysId(getSysId());
            hbciAccount.setSigId(getSigId().longValue());

            filecontent.setBankSigKey(hbciAccount, getInstSigKey());
            filecontent.setBankEncKey(hbciAccount, getInstEncKey());

            hbciAccount.setUserSigKeys(new HBCIKey[] { getMyPublicSigKey(),
                    getMyPrivateSigKey() });
            hbciAccount.setUserEncKeys(new HBCIKey[] { getMyPublicEncKey(),
                    getMyPrivateEncKey() });

            byte[] data = filecontent.getFileData();
            FileOutputStream fo = new FileOutputStream(tempfile);
            fo.write(data);
            fo.close();

            passportfile.delete();
            tempfile.renameTo(passportfile);
        } catch (Exception e) {
            throw new HBCI_Exception("*** saving of passport file failed", e);
        }
    }
    
    public String getProfileVersion()
    {
        // TODO: m�glicherweise auch RDH-10 - Unterscheidung zwischen RDH-2 und
        // -10 jedoch nicht klar
        return "2";
    }

    public void resetPassphrase() 
    {
        this.passphrase=null;
    }
    
    public void setPassphrase(byte[] passphrase) 
    {
        this.passphrase=passphrase;
        if (this.filecontent!=null) {
            this.filecontent.setPassphrase(passphrase);
        }
    }

    public HBCIKey[][] generateNewUserKeys() 
    {
        // f�r RDH-2-Passports gilt: schl�ssel haben immer die 
        // schl�ssel-nummer 2, und es wird die schl�ssel-version zum "z�hlen"
        // der schl�ssel-varianten verwendet
        
        HBCIKey[][] ret=null;
        
        // merken der aktuallen schl�ssel-nummern und -versionen
        String oldSigNum=getMySigKeyNum();
        String oldSigVer=getMySigKeyVersion();
        String oldEncNum=getMyEncKeyNum();
        String oldEncVer=getMyEncKeyVersion();
        
        // generieren der neuen keys
        ret=super.generateNewUserKeys();
        
        // hier habe ich jetzt mit sicherheit neue keys mit "falschen" nummern/versionen
        
        // aktualisieren des sig-keys
        if (oldSigNum==null) {
            // neue schl�ssel erzeugt --> public und private auf 2/1 setzen
            ret[0][0].num="2";
            ret[0][0].version="1";
            ret[0][1].num="2";
            ret[0][1].version="1";
        } else {
            // es gab schon schl�ssel (theoretisch mit 2/X)
            if (!oldSigNum.equals("2")) {
                HBCIUtils.log("old sig key number was "+oldSigNum
                        +", but should have been 2! Setting it to 2",
                        HBCIUtils.LOG_ERR);
                // public und private num auf 2 setzen
                ret[0][0].num="2";
                ret[0][1].num="2";
            }
            // public und private version um eins erh�hen
            String newVersion=Integer.toString(Integer.parseInt(oldSigVer)+1);
            ret[0][0].version=newVersion;
            ret[0][1].version=newVersion;
            HBCIUtils.log("Updating new sig key's version to "+newVersion,HBCIUtils.LOG_DEBUG);
        }

        // aktualisieren des enc-keys
        // TODO: gleicher code wie f�r sig-key -> auslagern
        if (oldEncNum==null) {
            // neue schl�ssel erzeugt --> public und private auf 2/1 setzen
            ret[1][0].num="2";
            ret[1][0].version="1";
            ret[1][1].num="2";
            ret[1][1].version="1";
        } else {
            // es gab schon schl�ssel (theoretisch mit 2/X)
            if (!oldEncNum.equals("2")) {
                HBCIUtils.log("old enc key number was "+oldEncNum
                        +", but should have been 2! Setting it to 2",
                        HBCIUtils.LOG_ERR);
                // public und private num auf 2 setzen
                ret[1][0].num="2";
                ret[1][1].num="2";
            }
            // public und private version um eins erh�hen
            String newVersion=Integer.toString(Integer.parseInt(oldEncVer)+1);
            ret[1][0].version=newVersion;
            ret[1][1].version=newVersion;
            HBCIUtils.log("Updating new enc key's version to "+newVersion,HBCIUtils.LOG_DEBUG);
        }
        
        return ret;
    }
}
