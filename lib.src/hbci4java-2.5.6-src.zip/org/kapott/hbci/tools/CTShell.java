
/*  $Id: CTShell.java,v 1.4 2007/08/29 12:53:30 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.tools;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Enumeration;

import opencard.core.service.CardRequest;
import opencard.core.service.SmartCard;
import opencard.core.terminal.CardTerminal;
import opencard.core.terminal.CardTerminalRegistry;
import opencard.core.terminal.CommandAPDU;
import opencard.core.terminal.ResponseAPDU;
import opencard.opt.util.PassThruCardService;

public class CTShell
{
    public static void main(String[] args)
        throws Exception
    {
        String         linesep=System.getProperty("line.separator");
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
        
        SmartCard.start();
        
        CardTerminalRegistry terminalRegistry=CardTerminalRegistry.getRegistry();
        for (Enumeration e=terminalRegistry.getCardTerminals();e.hasMoreElements();) {
            CardTerminal terminal=(CardTerminal)e.nextElement();
            System.out.println(terminal.getName()+": "+terminal.toString()+linesep);
        }
        String terminalName=input.readLine();
        CardTerminal terminal=terminalRegistry.cardTerminalForName(terminalName);
        
        System.out.println("features:");
        System.out.println(terminal.features()+linesep);
        
        // CardTerminal terminal=null;
        
        CardRequest cardRequest=new CardRequest(CardRequest.ANYCARD, terminal, null);
        cardRequest.setTimeout(60);
        SmartCard   smartCard=SmartCard.waitForCard(cardRequest);
        System.out.println("card inserted: "+smartCard.getCardID());
        
        byte[] historicals=smartCard.getCardID().getHistoricals();
        System.out.print("historical bytes: ");
        for (int i=0;i<historicals.length;i++) {
            String st=Integer.toHexString(historicals[i]);
            if (st.length()>2) {
                st=st.substring(st.length()-2);
            } else if (st.length()<2) {
                st="0"+st;
            }
            System.out.print(st+" ");
        }
        System.out.println();
        
        PassThruCardService cardService=(PassThruCardService)smartCard.getCardService(PassThruCardService.class, true);
        System.out.println("got card service: "+cardService);
        
        while (true) {
            // input loop
            
            System.out.println();
            System.out.print("> ");
            System.out.flush();
            String line=input.readLine();
            
            boolean loopMode=false;
            boolean loopMode2=false;
            
            if (line.equals("quit") || line.equals("exit")) {
                break;
            } else if (line.startsWith("loop ")) {
                loopMode=true;
                line=line.substring(5);
            } else if (line.startsWith("loop2 ")) {
                loopMode2=true;
                line=line.substring(6);
            }
            
            // split input into separate tokens
            String[] tokens=line.split("\\s");
            if (tokens.length<4) {
                System.out.println("invalid command - format: [\"loop[2]\"] CLA INS P1 P2 [data] Le");
                continue;
            }
            
            int loopCounter=0;
            int loopCounter2=0;
            while (true) {
                // for loop mode
                
                byte[] data=new byte[tokens.length];
                for (int i=0;i<data.length;i++) {
                    String current=tokens[i];
                    if ((loopMode || loopMode2) 
                            && current.toLowerCase().equals("xx")) 
                    {
                        // replace XX with loopCounter when in any loop mode
                        data[i]=(byte)loopCounter;
                    } else if (loopMode2 && current.toLowerCase().equals("yy")) {
                        // replace yy with loopCounter2 when in loop2 mode
                        data[i]=(byte)loopCounter2;
                    } else {
                        data[i]=(byte)Integer.parseInt(current, 16);
                    }
                }
                
                CommandAPDU  command=new CommandAPDU(data);
                ResponseAPDU response=cardService.sendCommandAPDU(command);
                
                if ((loopMode || loopMode2) && 
                        (response.sw1()==(byte)0x90 || response.sw1()==(byte)0x61)) 
                {
                    // when in any loop mode, print the command that executed successfully
                    System.out.println();
                    System.out.print("command: ");
                    for (int i=0;i<data.length;i++) {
                        String st=Integer.toHexString(data[i]);
                        if (st.length()>2) {
                            st=st.substring(st.length()-2);
                        } else if (st.length()<2) {
                            st="0"+st;
                        }
                        System.out.print(st+" ");
                    }
                    System.out.println();
                }
                
                if ((!loopMode && !loopMode2) || 
                        (response.sw1()==(byte)0x90 || response.sw1()==(byte)0x61))
                {
                    // print result, when we are in non-loop mode (single shot)
                    // or when in loop mode and the command executed successfully
                    
                    System.out.println("status: "+Integer.toHexString(response.sw()));
                    data=response.data();
                    if (data!=null) {
                        System.out.print("data: ");
                        for (int i=0;i<data.length;i++) {
                            String st=Integer.toHexString(data[i]);
                            if (st.length()>2) {
                                st=st.substring(st.length()-2);
                            } else if (st.length()<2) {
                                st="0"+st;
                            }
                            System.out.print(st+" ");
                        }
                        System.out.println();
                    }
                }
                
                if (loopMode || loopMode2) {
                    // in loop mode increment loop counter(s)
                    loopCounter++;
                    if (loopCounter>255) {
                        // when first loop counter reaches its end
                        if (loopMode2) {
                            // when in loop2 mode, first check the loopcounter2
                            loopCounter=0;
                            loopCounter2++;
                            if (loopCounter2>255) {
                                // if loopcounter2 reached its end too, break
                                break;
                            }
                        } else {
                            // when in loop1 mode, break immediately
                            break;
                        }
                    }
                } else {
                    // no loop mode? break immediately
                    break;
                }
            } // for loop mode
        } // input loop
        
        smartCard.close();
    }
}
