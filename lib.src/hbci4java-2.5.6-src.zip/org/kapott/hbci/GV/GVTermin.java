
/*  $Id: GVTermin.java,v 1.10 2008/01/26 11:36:54 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.GV;

import org.kapott.hbci.GV_Result.HBCIJobResultImpl;
import org.kapott.hbci.manager.HBCIHandler;
import org.kapott.hbci.manager.LogFilter;

public final class GVTermin
    extends HBCIJobImpl
{
    public static String getLowlevelName()
    {
        // TODO: Diesen Lowlevel-GV gibts nicht mehr
        return "DateAgrReq";
    }
    
    public GVTermin(HBCIHandler handler)
    {
        super(handler,getLowlevelName(),new HBCIJobResultImpl());

        addConstraint("date","date","", LogFilter.FILTER_NONE);
        addConstraint("time","time","", LogFilter.FILTER_NONE);
        addConstraint("filiale","filiale","", LogFilter.FILTER_NONE);
        addConstraint("person","person","", LogFilter.FILTER_IDS);
        addConstraint("tel","tel","", LogFilter.FILTER_IDS);
        addConstraint("infocode","infocode","", LogFilter.FILTER_NONE);
        addConstraint("topic","topic","", LogFilter.FILTER_NONE);
    }
}
