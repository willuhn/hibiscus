
/*  $Id: IHandlerData.java,v 1.3 2007/12/25 18:29:45 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.manager;

import org.kapott.hbci.passport.HBCIPassport;

// Dieses Interface wird von einigen Klassen implementiert (HBCIHandler,
// HBCIInstitute, HBCIUser). Es dient dazu, ein "allgemeines" Interface
// f�r alle Klassen zu haben, die sowohl ein Passport als auch einen
// Message-Generator zur�ckgeben k�nnen, also alles, was man zum Ausf�hren
// von HBCI-Dialogen braucht.
//
// Im Moment ist bei allen Implementierungen dieses Interfaces getMsgGen()
// implementiert, indem this.kernel.getMsgGen() zur�ckgegeben wird - aber
// das muss nicht so sein!
// 
// TODO: das sieht aus wie ein typisches DesignPattern - das evtl. mal
// irgendwie verallgemeinern (double-linked-parent-child-connection) und �berall
// wo n�tig einsetzen (evtl. inklusive asserts oder automatischer Setter)

public interface IHandlerData 
{
    public HBCIPassport getPassport();
    public MsgGen       getMsgGen();
}
