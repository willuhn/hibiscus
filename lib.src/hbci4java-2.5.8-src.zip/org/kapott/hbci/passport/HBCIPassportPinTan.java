
/*  $Id: HBCIPassportPinTan.java,v 1.39 2008/05/30 06:24:08 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.passport;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.security.Security;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.spec.PBEParameterSpec;

import org.kapott.hbci.callback.HBCICallback;
import org.kapott.hbci.comm.Comm;
import org.kapott.hbci.exceptions.HBCI_Exception;
import org.kapott.hbci.exceptions.InvalidPassphraseException;
import org.kapott.hbci.exceptions.InvalidUserDataException;
import org.kapott.hbci.manager.HBCIKey;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.manager.HBCIUtilsInternal;
import org.kapott.hbci.manager.LogFilter;
import org.kapott.hbci.security.Crypt;
import org.kapott.hbci.security.HBCIProvider;
import org.kapott.hbci.security.Sig;
import org.kapott.hbci.status.HBCIMsgStatus;
import org.kapott.hbci.status.HBCIRetVal;

/** <p>Passport-Klasse f�r HBCI mit PIN/TAN. Dieses Sicherheitsverfahren wird erst
    in FinTS 3.0 spezifiziert, von einigen Banken aber schon mit fr�heren HBCI-Versionen
    angeboten.</p><p>
    Bei diesem Verfahren werden die Nachrichten auf HBCI-Ebene nicht mit kryptografischen
    Verfahren signiert oder verschl�sselt. Als "Signatur" werden statt dessen TANs 
    zusammen mit einer PIN verwendet. Die PIN wird dabei in <em>jeder</em> HBCI-Nachricht als
    Teil der "Signatur" eingef�gt, doch nicht alle Nachrichten ben�tigen eine TAN.
    Eine TAN wird nur bei der �bermittlung bestimmter Gesch�ftsvorf�lle ben�tigt. Welche
    GV das konkret sind, ermittelt <em>HBCI4Java</em> automatisch aus den BPD. F�r jeden GV, der
    eine TAN ben�tigt, wird diese via Callback abgefragt und in die Nachricht eingef�gt.</p><p>
    Die Verschl�sselung der Nachrichten bei der �bertragung erfolgt auf einer h�heren
    Transportschicht. Die Nachrichten werden n�mlich nicht direkt via TCP/IP �bertragen,
    sondern in das HTTP-Protokoll eingebettet. Die Verschl�sselung der �bertragenen Daten
    erfolgt dabei auf HTTP-Ebene (via SSL = HTTPS).</p><p>
    Wie auch bei {@link org.kapott.hbci.passport.HBCIPassportRDH} wird eine "Schl�sseldatei"
    verwendet. In dieser werden allerdings keine kryptografischen Schl�ssel abgelegt, sondern
    lediglich die Zugangsdaten f�r den HBCI-Server (Hostadresse, Nutzerkennung, usw.) sowie
    einige zus�tzliche Daten (BPD, UPD, zuletzt benutzte HBCI-Version). Diese Datei wird
    vor dem Abspeichern verschl�sselt. Vor dem Erzeugen bzw. erstmaligen Einlesen wird via
    Callback nach einem Passwort gefragt, aus welchem der Schl�ssel f�r die Verschl�sselung
    der Datei berechnet wird</p>*/
public class HBCIPassportPinTan
    extends AbstractHBCIPassport
{
    private String    filename;
    private SecretKey passportKey;
    private String    pin;
    private String    certfile;
    private boolean   checkCert;
    private String    proxy;
    private String    proxyuser;
    private String    proxypass;
    private boolean   verifyTANMode;
    
    private Hashtable twostepMechanisms;
    private List      allowedTwostepMechanisms;
    
    private String    currentTANMethod;
    private boolean   currentTANMethodWasAutoSelected;
    
    private final static byte[] CIPHER_SALT={(byte)0x26,(byte)0x19,(byte)0x38,(byte)0xa7,
                                             (byte)0x99,(byte)0xbc,(byte)0xf1,(byte)0x55};
    private final static int CIPHER_ITERATIONS=987;

    public HBCIPassportPinTan(Object init,int dummy)
    {
        super(init);
        this.twostepMechanisms=new Hashtable();
        this.allowedTwostepMechanisms=new ArrayList();
        
        if (Security.getProvider("HBCIProvider") == null)
            Security.addProvider(new HBCIProvider());
    }

    public HBCIPassportPinTan(Object initObject)
    {
        this(initObject,0);

        String  header="client.passport.PinTan.";
        String  fname=HBCIUtils.getParam(header+"filename");
        boolean init=HBCIUtils.getParam(header+"init").equals("1");
        
        HBCIUtils.log(HBCIUtilsInternal.getLocMsg("INFO_PASS_LOADFILE",fname),HBCIUtils.LOG_DEBUG);
        setFileName(fname);
        setPort(new Integer(443));
        setCertFile(HBCIUtils.getParam(header+"certfile"));
        setCheckCert(HBCIUtils.getParam(header+"checkcert","1").equals("1"));
        
        setProxy(HBCIUtils.getParam(header+"proxy",""));
        setProxyUser(HBCIUtils.getParam(header+"proxyuser",""));
        setProxyPass(HBCIUtils.getParam(header+"proxypass",""));

        if (init) {
            HBCIUtils.log(HBCIUtilsInternal.getLocMsg("DBG_PASS_LOADDATE",fname),HBCIUtils.LOG_DEBUG);
            
            if (!new File(fname).canRead()) {
                HBCIUtils.log(HBCIUtilsInternal.getLocMsg("WRN_PASS_NEWFILE"),HBCIUtils.LOG_WARN);
                askForMissingData(true,true,true,true,true,true,true);
                saveChanges();
            }

            ObjectInputStream o=null;
            try {
                int retries=Integer.parseInt(HBCIUtils.getParam("client.retries.passphrase","3"));
                
                while (true) {
                    if (passportKey==null)
                        passportKey=calculatePassportKey(FOR_LOAD);

                    PBEParameterSpec paramspec=new PBEParameterSpec(CIPHER_SALT,CIPHER_ITERATIONS);
                    Cipher cipher=Cipher.getInstance("PBEWithMD5AndDES");
                    cipher.init(Cipher.DECRYPT_MODE,passportKey,paramspec);
                    
                    o=null;
                    try {
                        o=new ObjectInputStream(new CipherInputStream(new FileInputStream(fname),cipher));
                    } catch (StreamCorruptedException e) {
                        passportKey=null;
                        
                        retries--;
                        if (retries<=0)
                            throw new InvalidPassphraseException(e);
                    }
                    
                    if (o!=null)
                        break;
                }

                setCountry((String)(o.readObject()));
                setBLZ((String)(o.readObject()));
                setHost((String)(o.readObject()));
                setPort((Integer)(o.readObject()));
                setUserId((String)(o.readObject()));
                setSysId((String)(o.readObject()));
                setBPD((Properties)(o.readObject()));
                setUPD((Properties)(o.readObject()));

                setHBCIVersion((String)o.readObject());
                setCustomerId((String)o.readObject());
                setFilterType((String)o.readObject());
                
                // TODO: hier auch gew�hltes pintan/verfahren lesen
            } catch (Exception e) {
                throw new HBCI_Exception("*** loading of passport file failed",e);
            }

            try {
                o.close();
            } catch (Exception e) {
                HBCIUtils.log(e);
            }
            
            if (askForMissingData(true,true,true,true,true,true,true))
                saveChanges();
        }
    }
    
    public void setBPD(Properties p)
    {
        super.setBPD(p);
        
        if (p!=null && p.size()!=0) {
            // hier die liste der verf�gbaren sicherheitsverfahren aus den
            // bpd (HITANS) extrahieren
            
            twostepMechanisms.clear();
            
            for (Enumeration e=p.propertyNames();e.hasMoreElements();) {
                String key=(String)e.nextElement();
                
                // p.getProperty("Params_x.TAN2StepParY.ParTAN2StepZ.TAN2StepParamsX_z.*")
                if (key.startsWith("Params")) {
                    String subkey=key.substring(key.indexOf('.')+1);
                    if (subkey.startsWith("TAN2StepPar")) {
                        subkey=subkey.substring(subkey.indexOf('.')+1);
                        if (subkey.startsWith("ParTAN2Step") &&
                                subkey.endsWith(".secfunc"))
                        {
                            String     secfunc=p.getProperty(key);
                            Properties entry=new Properties();
                            String     paramHeader=key.substring(0,key.lastIndexOf('.'));
                              // Params_x.TAN2StepParY.ParTAN2StepZ.TAN2StepParamsX_z
                            
                            // alle properties durchlaufen und alle suchen, die mit dem
                            // paramheader beginnen, und die entsprechenden werte im
                            // entry abspeichern
                            for (Enumeration e2=p.propertyNames();e2.hasMoreElements();) {
                                String key2=(String)e2.nextElement();
                                
                                if (key2.startsWith(paramHeader+".")) {
                                    int dotPos=key2.lastIndexOf('.');
                                    
                                    entry.setProperty(
                                        key2.substring(dotPos+1),
                                        p.getProperty(key2));
                                }
                            }
                            
                            // diesen mechanismus abspeichern
                            twostepMechanisms.put(secfunc,entry);
                        }
                    }
                }
            }
        }
    }
    
    private void searchFor3920s(HBCIRetVal[] rets)
    {
        int l=rets.length;
        for (int i=0; i<l; i++) {
            HBCIRetVal ret=rets[i];
            if (ret.code.equals("3920")) {
                this.allowedTwostepMechanisms.clear();
                
                int l2=ret.params.length;
                for (int j=0; j<l2; j++) {
                    this.allowedTwostepMechanisms.add(ret.params[j]);
                }
                
                HBCIUtils.log("autosecfunc: found 3920 in response - updated list of allowed twostepmechs with "+allowedTwostepMechanisms.size()+" entries", HBCIUtils.LOG_DEBUG);
            }
        }
    }
    
    public boolean postInitResponseHook(HBCIMsgStatus msgStatus, boolean anonDialog)
    {
        boolean restart_needed=super.postInitResponseHook(msgStatus, anonDialog);
        
        HBCIUtils.log("autosecfunc: search for 3920s in response to detect allowed twostep secmechs", HBCIUtils.LOG_DEBUG);
        
        searchFor3920s(msgStatus.globStatus.getWarnings());
        searchFor3920s(msgStatus.segStatus.getWarnings());
        
        if (!anonDialog) {
            setPersistentData("_authed_dialog_executed", Boolean.TRUE);

            // aktuelle secmech merken und neue ausw�hlen (basierend auf evtl. gerade
            // neu empfangenen informationen (3920s))
            String oldTANMethod=currentTANMethod;
            String updatedTANMethod=getCurrentTANMethod(true);
            
            if (!oldTANMethod.equals(updatedTANMethod)) {
                // wenn sich das ausgew�hlte secmech ge�ndert hat, m�ssen wir
                // einen dialog-restart fordern, weil w�hrend eines dialoges
                // das secmech nicht gewechselt werden darf
                restart_needed=true;
                HBCIUtils.log("autosecfunc: after this dialog-init we had to change selected pintan method, so a restart of this dialog is needed", HBCIUtils.LOG_INFO);
            }
        }
        
        return restart_needed;
    }

    /** Gibt den Dateinamen der Schl�sseldatei zur�ck.
        @return Dateiname der Schl�sseldatei */
    public String getFileName() 
    {
        return filename;
    }

    public void setFileName(String filename) 
    { 
        this.filename=filename;
    }
    
    public Comm getCommInstance()
    {
        return Comm.getInstance("PinTan",this);
    }
    
    public boolean isSupported()
    {
        boolean ret=false;
        Properties bpd=getBPD();
        
        if (bpd!=null && bpd.size()!=0) {
            // loop through bpd and search for PinTanPar segment
            for (Enumeration e=bpd.propertyNames();e.hasMoreElements();) {
                String key=(String)e.nextElement();
                
                if (key.startsWith("Params")) {
                    int posi=key.indexOf(".");
                    if (key.substring(posi+1).startsWith("PinTanPar")) {
                        ret=true;
                        break;
                    }
                }
            }
            
            if (ret) {
                // pr�fen, ob gew�hltes sicherheitsverfahren unterst�tzt wird
                // autosecmech: hier wird ein flag uebergeben, das anzeigt, dass getCurrentTANMethod()
                // hier evtl. automatisch ermittelte secmechs neu verifzieren soll
                String current=getCurrentTANMethod(true);
                
                if (current.equals(Sig.SECFUNC_SIG_PT_1STEP)) {
                    // einschrittverfahren gew�hlt
                    if (!isOneStepAllowed()) {
                        HBCIUtils.log("*** not supported: onestep method not allowed by BPD",HBCIUtils.LOG_ERR);
                        ret=false;
                    } else {
                        HBCIUtils.log("*** supported: pintan-onestep",HBCIUtils.LOG_DEBUG);
                    }
                } else {
                    // irgendein zweischritt-verfahren gew�hlt
                    Properties entry=(Properties)twostepMechanisms.get(current);
                    if (entry==null) {
                        // es gibt keinen info-eintrag f�r das gew�hlte verfahren
                        HBCIUtils.log("*** not supported: twostep-method "+current+" selected, but this is not supported",HBCIUtils.LOG_ERR);
                        ret=false;
                    } else {
                        HBCIUtils.log("*** selected twostep-method "+current+" ("+entry.getProperty("name")+") is supported",HBCIUtils.LOG_DEBUG);
                    }
                }
            }
        } else {
            ret=true;
        }
        
        return ret;
    }
    
    private boolean isOneStepAllowed()
    {
        // default ist true, weil entweder *nur* das einschritt-verfahren unter-
        // st�tzt wird oder keine BPD vorhanden sind, um das zu entscheiden
        boolean    ret=true;
        
        Properties bpd=getBPD();
        if (bpd!=null) {
            for (Enumeration e=bpd.propertyNames();e.hasMoreElements();) {
                String key=(String)e.nextElement();
                
                // p.getProperty("Params_x.TAN2StepParY.ParTAN2StepZ.can1step")
                if (key.startsWith("Params")) {
                    String subkey=key.substring(key.indexOf('.')+1);
                    if (subkey.startsWith("TAN2StepPar") && 
                            subkey.endsWith(".can1step")) 
                    {
                        String value=bpd.getProperty(key);
                        ret=value.equals("J");
                        break;
                    }
                }
            }
        }
        
        return ret;
    }
    
    public void setCurrentTANMethod(String method)
    {
        this.currentTANMethod=method;
    }
    
    public String getCurrentTANMethod(boolean recheckSupportedSecMechs)
    {
        // autosecmech: hier auch dann checken, wenn recheckSupportedSecMechs==true
        // UND die vorherige auswahl AUTOMATISCH getroffen wurde (manuelle auswahl
        // also in jedem fall weiter verwenden) (das AUTOMATISCH erkennt man daran,
        // dass recheckCurrentTANMethodNeeded==true ist)
        if (currentTANMethod==null || recheckSupportedSecMechs) {
            HBCIUtils.log("autosecfunc: (re)checking selected pintan secmech", HBCIUtils.LOG_DEBUG);
            
            // es ist noch kein zweischrittverfahren ausgewaehlt, oder die 
            // aktuelle auswahl soll gegen die liste der tatsaechlich unterstuetzten
            // verfahren validiert werden
            
            List options=new ArrayList(); // String[]: [secfunc, name]
            
            if (isOneStepAllowed()) {
                // wenn einschrittverfahren unterst�tzt, dass zur liste hinzuf�gen
                if (allowedTwostepMechanisms.size()==0 || allowedTwostepMechanisms.contains(Sig.SECFUNC_SIG_PT_1STEP)) {
                    options.add(new String[] {Sig.SECFUNC_SIG_PT_1STEP,"Einschritt-Verfahren"});
                }
            }
            
            // alle zweischritt-verfahren zur auswahlliste hinzuf�gen
            String[] secfuncs=(String[])twostepMechanisms.keySet().toArray(new String[twostepMechanisms.size()]);
            Arrays.sort(secfuncs);
            int len=secfuncs.length;
            for (int i=0;i<len;i++) {
                String secfunc=secfuncs[i];
                if (allowedTwostepMechanisms.size()==0 || allowedTwostepMechanisms.contains(secfunc)) {
                    Properties entry=(Properties)twostepMechanisms.get(secfunc);
                    options.add(new String[] {secfunc,entry.getProperty("name")});
                }
            }
            
            if (options.size()==1) {
                // wenn nur ein verfahren unterst�tzt wird, das automatisch ausw�hlen
                String autoSelection=((String[])options.get(0))[0];
                
                HBCIUtils.log("autosecfunc: there is only one pintan method ("+autoSelection+") supported - choosing this automatically",HBCIUtils.LOG_DEBUG);
                if (currentTANMethod!=null && autoSelection!=currentTANMethod) {
                    HBCIUtils.log("autosecfunc: currently selected method ("+currentTANMethod+") differs from auto-selected method ("+autoSelection+")", HBCIUtils.LOG_DEBUG);
                }
                
                setCurrentTANMethod(autoSelection);
                
                // autosecmech: hier merken, dass dieses verfahren AUTOMATISCH
                // ausgewaehlt wurde, so dass wir spaeter immer mal wieder pruefen
                // muessen, ob inzwischen nicht mehr/andere unterstuetzte secmechs bekannt sind
                // (passiert z.b. wenn das anonyme abholen der bpd fehlschlaegt)
                this.currentTANMethodWasAutoSelected=true;
                
            } else if (options.size()>1) {
                // es werden mehrere verfahren unterst�tzt
                
                if (currentTANMethod!=null) {
                    // es ist schon ein verfahren ausgewaehlt. falls dieses verfahren
                    // nicht in der liste der unterstuetzten verfahren enthalten ist,
                    // setzen wir das auf "null" zurueck, damit das zu verwendende
                    // verfahren neu ermittelt wird
                    
                    boolean ok=false;
                    for (Iterator i=options.iterator();i.hasNext();) {
                        if (currentTANMethod.equals(((String[])i.next())[0])) {
                            ok=true;
                            break;
                        }
                    }
                    
                    if (!ok) {
                        HBCIUtils.log("autosecfunc: currently selected pintan method ("+currentTANMethod+") not in list of supported methods - resetting current selection", HBCIUtils.LOG_DEBUG);
                        currentTANMethod=null;
                    }
                }
                
                if (currentTANMethod==null || this.currentTANMethodWasAutoSelected) {
                    // wenn noch kein verfahren ausgewaehlt ist, oder das bisherige
                    // verfahren automatisch ausgewaehlt wurde, muessen wir uns
                    // neu fuer eine method aus der liste entscheiden
                    
                    // TODO: damit das sinnvoll funktioniert, sollte die liste der
                    // allowedTwostepMechs mit im passport gespeichert werden.
                    if (allowedTwostepMechanisms.size()==0 &&
                            getPersistentData("_authed_dialog_executed")==null) 
                    {
                        // wir w�hlen einen secmech automatisch aus, wenn wir
                        // die liste der erlaubten secmechs nicht haben
                        // (entweder weil wir sie noch nie abgefragt haben oder weil
                        // diese daten einfach nicht geliefert werden). im fall
                        // "schon abgefragt, aber nicht geliefert" d�rfen wir aber 
                        // wiederum NICHT automatisch ausw�hlen, so dass wir zus�tzlich 
                        // fragen, ob schon mal ein dialog gelaufen ist, bei dem 
                        // diese daten h�tten geliefert werden K�NNEN (_authed_dialog_executed). 
                        // nur wenn wir die liste der g�ltigen secmechs noch gar 
                        // nicht haben K�NNEN, w�hlen wir einen automatisch aus.
                        
                        String autoSelection=((String[])options.get(0))[0];
                        HBCIUtils.log("autosecfunc: there are "+options.size()+" pintan methods supported, but we don't know which of them are allowed for the current user, so we automatically choose "+autoSelection,HBCIUtils.LOG_DEBUG);
                        setCurrentTANMethod(autoSelection);
                        
                        // autosecmech: hier merken, dass dieses verfahren AUTOMATISCH
                        // ausgewaehlt wurde, so dass wir spaeter immer mal wieder pruefen
                        // muessen, ob inzwischen nicht mehr/andere unterstuetzte secmechs bekannt sind
                        // (passiert z.b. wenn das anonyme abholen der bpd fehlschlaegt)
                        this.currentTANMethodWasAutoSelected=true;
                        
                    } else {
                        // wir wissen schon, welche secmechs erlaubt sind (entweder
                        // durch einen vorhergehenden dialog oder aus den persistenten
                        // passport-daten), oder wir wissen es nicht (size==0), haben aber schonmal
                        // danach gefragt (ein authed_dialog ist schon gelaufen, bei dem
                        // diese daten aber nicht geliefert wurden). 
                        // in jedem fall steht in "options" die liste der prinzipiell
                        // verf�gbaren secmechs drin, u.U. gek�rzt auf die tats�chlich
                        // erlaubten secmechs.
                        // wir fragen also via callback nach, welcher dieser secmechs
                        // denn nun verwendet werden soll
                        
                        HBCIUtils.log("autosecfunc: we have to callback to ask for pintan method to be used", HBCIUtils.LOG_DEBUG);
                        
                        // auswahlliste als string zusammensetzen
                        StringBuffer retData=new StringBuffer();
                        for (Iterator i=options.iterator();i.hasNext();) {
                            if (retData.length()!=0) {
                                retData.append("|");
                            }
                            String[] entry=(String[])i.next();
                            retData.append(entry[0]).append(":").append(entry[1]);
                        }
                        
                        // callback erzeugen
                        HBCIUtilsInternal.getCallback().callback(this,
                            HBCICallback.NEED_PT_SECMECH,
                            "*** Select a pintan method from the list",
                            HBCICallback.TYPE_TEXT,
                            retData);
                        
                        // �berpr�fen, ob das gew�hlte verfahren einem aus der liste entspricht
                        String  selected=retData.toString();
                        boolean ok=false;
                        for (Iterator i=options.iterator();i.hasNext();) {
                            if (selected.equals(((String[])i.next())[0])) {
                                ok=true;
                                break;
                            }
                        }
                        
                        if (!ok) {
                            throw new InvalidUserDataException("selected pintan method not supported!");
                        }
                        
                        setCurrentTANMethod(selected);
                        this.currentTANMethodWasAutoSelected=false;
                        
                        HBCIUtils.log("autosecfunc: manually selected pintan method "+currentTANMethod, HBCIUtils.LOG_DEBUG);
                    }
                }
                
            } else {
                // es wird scheinbar GAR KEIN verfahren unterstuetzt. also nehmen
                // wir automatisch 999
                HBCIUtils.log("autosecfunc: absolutely no information about allowed pintan methods available - automatically falling back to 999", HBCIUtils.LOG_DEBUG);
                setCurrentTANMethod("999");
                this.currentTANMethodWasAutoSelected=true;
            }
        }
            
        return currentTANMethod;
    }
    
    public Properties getCurrentSecMechInfo()
    {
        return (Properties)twostepMechanisms.get(getCurrentTANMethod(false));
    }

    public String getProfileMethod()
    {
        return "PIN";
    }
    
    public String getProfileVersion()
    {
        return getCurrentTANMethod(false).equals(Sig.SECFUNC_SIG_PT_1STEP)?"1":"2";
    }

    public boolean needUserKeys()
    {
        return false;
    }
    
    public boolean needInstKeys()
    {
        // TODO: das abh�ngig vom thema "bankensignatur f�r HKTAN" machen
        return false;
    }
    
    public boolean needDigKey()
    {
        return false;
    }
    
    public boolean needUserSig()
    {
        return true;
    }
    
    public String getSysStatus()
    {
        return "1";
    }

    public boolean hasInstSigKey()
    {
        // TODO: hier m�sste es eigentlich zwei antworten geben: eine f�r
        // das PIN/TAN-verfahren an sich (immer true) und eine f�r
        // evtl. bankensignatur-schl�ssel f�r HITAN
        return true;
    }
    
    public boolean hasInstEncKey()
    {
        return true;
    }
    
    public boolean hasInstDigKey()
    {
        return false;
    }
    
    public boolean hasMySigKey()
    {
        return true;
    }
    
    public boolean hasMyEncKey()
    {
        return true;
    }
    
    public HBCIKey getInstSigKey()
    {
        // TODO: hier m�sste es eigentlich zwei antworten geben: eine f�r
        // das PIN/TAN-verfahren an sich (immer null) und eine f�r
        // evtl. bankensignatur-schl�ssel f�r HITAN
        return null;
    }
    
    public HBCIKey getInstEncKey()
    {
        return null;
    }
    
    public HBCIKey getInstDigKey()
    {
        return null;
    }
    
    public String getInstSigKeyName()
    {
        // TODO: evtl. zwei antworten: pin/tan und bankensignatur f�r HITAN
        return getUserId();
    }

    public String getInstSigKeyNum()
    {
        // TODO: evtl. zwei antworten: pin/tan und bankensignatur f�r HITAN
        return "0";
    }

    public String getInstSigKeyVersion()
    {
        // TODO: evtl. zwei antworten: pin/tan und bankensignatur f�r HITAN
        return "0";
    }

    public String getInstEncKeyName()
    {
        return getUserId();
    }

    public String getInstEncKeyNum()
    {
        return "0";
    }

    public String getInstEncKeyVersion()
    {
        return "0";
    }

    public String getInstDigKeyName()
    {
        return "";
    }

    public String getInstDigKeyNum()
    {
        return "";
    }

    public String getInstDigKeyVersion()
    {
        return "";
    }

    public String getMySigKeyName()
    {
        return getUserId();
    }

    public String getMySigKeyNum()
    {
        return "0";
    }

    public String getMySigKeyVersion()
    {
        return "0";
    }

    public String getMyEncKeyName()
    {
        return getUserId();
    }

    public String getMyEncKeyNum()
    {
        return "0";
    }

    public String getMyEncKeyVersion()
    {
        return "0";
    }
    
    public HBCIKey getMyPublicDigKey()
    {
        return null;
    }

    public HBCIKey getMyPrivateDigKey()
    {
        return null;
    }

    public HBCIKey getMyPublicSigKey()
    {
        return null;
    }

    public HBCIKey getMyPrivateSigKey()
    {
        return null;
    }

    public HBCIKey getMyPublicEncKey()
    {
        return null;
    }

    public HBCIKey getMyPrivateEncKey()
    {
        return null;
    }

    public String getCryptMode()
    {
        // dummy-wert
        return Crypt.ENCMODE_CBC;
    }

    public String getCryptAlg()
    {
        // dummy-wert
        return Crypt.ENCALG_2K3DES;
    }

    public String getCryptKeyType()
    {
        // dummy-wert
        return Crypt.ENC_KEYTYPE_DDV;
    }

    public String getSigFunction()
    {
        return getCurrentTANMethod(false);
    }

    public String getCryptFunction()
    {
        return Crypt.SECFUNC_ENC_PLAIN;
    }

    public String getSigAlg()
    {
        // dummy-wert
        return Sig.SIGALG_RSA;
    }

    public String getSigMode()
    {
        // dummy-wert
        return Sig.SIGMODE_ISO9796_1;
    }

    public String getHashAlg()
    {
        // dummy-wert
        return Sig.HASHALG_RIPEMD160;
    }
    
    public void setInstDigKey(HBCIKey key)
    {
        // gibt es bei PinTan nicht
    }

    public void setInstSigKey(HBCIKey key)
    {
    }

    public void setInstEncKey(HBCIKey key)
    {
        // TODO: implementieren f�r bankensignatur bei HITAN
    }

    public void setMyPublicDigKey(HBCIKey key)
    {
    }

    public void setMyPrivateDigKey(HBCIKey key)
    {
    }

    public void setMyPublicSigKey(HBCIKey key)
    {
    }

    public void setMyPrivateSigKey(HBCIKey key)
    {
    }

    public void setMyPublicEncKey(HBCIKey key)
    {
    }

    public void setMyPrivateEncKey(HBCIKey key)
    {
    }
    
    public void incSigId()
    {
        // for PinTan we always use the same sigid
    }

    public int getMaxGVperMsg()
    {
        // TODO: damit wird erzwungen, dass immer nur ein tan-pflichtiger auftrag
        // pro nachricht versendet wird
        return 1;
    }

    public void resetPassphrase()
    {
        passportKey=null;
    }

    public void saveChanges()
    {
        try {
            if (passportKey==null) 
                passportKey=calculatePassportKey(FOR_SAVE);
            
            PBEParameterSpec paramspec=new PBEParameterSpec(CIPHER_SALT,CIPHER_ITERATIONS);
            Cipher cipher=Cipher.getInstance("PBEWithMD5AndDES");
            cipher.init(Cipher.ENCRYPT_MODE,passportKey,paramspec);

            File passportfile=new File(getFileName());
            File directory=passportfile.getAbsoluteFile().getParentFile();
            String prefix=passportfile.getName()+"_";
            File tempfile=File.createTempFile(prefix,"",directory);

            ObjectOutputStream o=new ObjectOutputStream(new CipherOutputStream(new FileOutputStream(tempfile),cipher));

            o.writeObject(getCountry());
            o.writeObject(getBLZ());
            o.writeObject(getHost());
            o.writeObject(getPort());
            o.writeObject(getUserId());
            o.writeObject(getSysId());
            o.writeObject(getBPD());
            o.writeObject(getUPD());

            o.writeObject(getHBCIVersion());
            o.writeObject(getCustomerId());
            o.writeObject(getFilterType());
            
            // TODO: hier auch gew�hltes zweischritt-verfahren abspeichern

            o.close();
            passportfile.delete();
            tempfile.renameTo(passportfile);
        } catch (Exception e) {
            throw new HBCI_Exception("*** saving of passport file failed",e);
        }
    }
    
    protected String collectSegCodes(String msg)
    {
    	// TODO: �berpr�fen, ob die Liste der Seg-Codes noch richtig erzeugt
    	// wird; also �berpr�fen, ob die richtigen Segmente TAN-pflichtig
    	// sind
        StringBuffer ret=new StringBuffer();
        int          len=msg.length();
        int          posi=0;
        
        while (true) {
            int endPosi=msg.indexOf(':',posi);
            if (endPosi==-1) {
                break;
            }
            
            String segcode=msg.substring(posi,endPosi);
            if (ret.length()!=0) {
                ret.append("|");
            }
            ret.append(segcode);
            
            while (posi<len && msg.charAt(posi)!='\'') {
            	posi=HBCIUtilsInternal.getPosiOfNextDelimiter(msg,posi+1);
            }
            if (posi>=len) {
                break;
            }
            posi++;
        }
        
        return ret.toString();
    }

    public String getPinTanInfo(String code)
    {
        String     ret="";
        Properties bpd=getBPD();
        
        if (bpd!=null) {
            boolean isGV=false;
            StringBuffer paramCode=new StringBuffer(code).replace(1,2,"I").append("S");

            for (Enumeration e=bpd.propertyNames();e.hasMoreElements();) {
                String key=(String)e.nextElement();

                if (key.startsWith("Params")&&
                        key.substring(key.indexOf(".")+1).startsWith("PinTanPar") &&
                        key.indexOf(".ParPinTan.PinTanGV")!=-1 &&
                        key.endsWith(".segcode")) 
                {
                    String code2=bpd.getProperty(key);
                    if (code.equals(code2)) {
                        key=key.substring(0,key.length()-("segcode").length())+"needtan";
                        ret=bpd.getProperty(key);
                        break;
                    }
                } else if (key.startsWith("Params")&&
                           key.endsWith(".SegHead.code")) {

                    String code2=bpd.getProperty(key);
                    if (paramCode.equals(code2)) {
                        isGV=true;
                    }
                }
            }

            // wenn das kein GV ist, dann ist es ein Admin-Segment
            if (ret.length()==0&&!isGV) {
                if (verifyTANMode && code.equals("HKIDN")) {
                    // im TAN-verify-mode wird bei der dialog-initialisierung
                    // eine TAN mit versandt; die Dialog-Initialisierung erkennt
                    // man am HKIDN-segment
                    ret="J";
                    deactivateTANVerifyMode();
                } else {
                    ret="A";
                }
            }
        }
        
        return ret;
    }

    public byte[] sign(byte[] data)
    {
        try {
            // TODO: wenn die eingegebene PIN falsch war, muss die irgendwie
            // resettet werden, damit wieder danach gefragt wird
            if (pin==null) {
                StringBuffer s=new StringBuffer();

                HBCIUtilsInternal.getCallback().callback(this,
                                                 HBCICallback.NEED_PT_PIN,
                                                 HBCIUtilsInternal.getLocMsg("CALLB_NEED_PTPIN"),
                                                 HBCICallback.TYPE_SECRET,
                                                 s);
                if (s.length()==0) {
                    throw new HBCI_Exception(HBCIUtilsInternal.getLocMsg("EXCMSG_PINZERO"));
                }
                pin=s.toString();
                LogFilter.getInstance().addSecretData(pin,"X",LogFilter.FILTER_SECRETS);
            }
            
            String tan="";
            
            // tan darf nur beim einschrittverfahren oder bei 
            // PV=1 und passport.contains(challenge)           und tan-pflichtiger auftrag oder bei
            // PV=2 und passport.contains(challenge+reference) und HKTAN
            // ermittelt werden
            
            String pintanMethod=getCurrentTANMethod(false);

            if (pintanMethod.equals(Sig.SECFUNC_SIG_PT_1STEP)) {
                // nur beim normalen einschritt-verfahren muss anhand der segment-
                // codes ermittelt werden, ob eine tan ben�tigt wird
                HBCIUtils.log("*** onestep method - checking GVs to decide whether or not we need a TAN",HBCIUtils.LOG_DEBUG);
                
                // segment-codes durchlaufen
                String codes=collectSegCodes(new String(data,"ISO-8859-1"));
                StringTokenizer tok=new StringTokenizer(codes,"|");
                
                while (tok.hasMoreTokens()) {
                    String code=tok.nextToken();
                    String info=getPinTanInfo(code);
                    
                    if (info.equals("J")) {
                        // f�r dieses segment wird eine tan ben�tigt
                        HBCIUtils.log(HBCIUtilsInternal.getLocMsg("INFO_PT_NEEDTAN",code),HBCIUtils.LOG_DEBUG);
                        
                        if (tan.length()==0) {
                            // noch keine tan bekannt --> callback
                            
                            StringBuffer s=new StringBuffer();
                            HBCIUtilsInternal.getCallback().callback(this,
                                HBCICallback.NEED_PT_TAN,
                                HBCIUtilsInternal.getLocMsg("CALLB_NEED_PTTAN"),
                                HBCICallback.TYPE_TEXT,
                                s);
                            if (s.length()==0) {
                                throw new HBCI_Exception(HBCIUtilsInternal.getLocMsg("EXCMSG_TANZERO"));
                            }
                            tan=s.toString();
                        } else {
                            HBCIUtils.log(HBCIUtilsInternal.getLocMsg("WRN_PT_TOOMUCHGV",code),HBCIUtils.LOG_WARN);
                        }
                    } else if (info.equals("N")) {
                        HBCIUtils.log(HBCIUtilsInternal.getLocMsg("INFO_PT_NOTNEEDED",code),HBCIUtils.LOG_DEBUG);
                    } else if (info.length()==0) {
                        HBCIUtils.log(HBCIUtilsInternal.getLocMsg("WRN_PT_CODENOTFOUND",code),HBCIUtils.LOG_WARN);
                    }
                }
            } else {
                HBCIUtils.log("*** twoset method - checking passport(challgen) to decide whether or not we need a TAN",HBCIUtils.LOG_DEBUG);
                Properties secmechInfo=getCurrentSecMechInfo();
                
                // gespeicherte challenge aus passport holen
                String challenge=(String)getPersistentData("pintan_challenge");
                setPersistentData("pintan_challenge",null);
                
                if (challenge==null) {
                    // es gibt noch keine challenge
                    HBCIUtils.log("*** will not sign with a TAN, because there is no challenge",HBCIUtils.LOG_DEBUG);
                } else {
                    HBCIUtils.log("*** found challenge in passport, so we ask for a TAN",HBCIUtils.LOG_DEBUG);
                    // es gibt eine challenge, also damit tan ermitteln
                    
                    StringBuffer s=new StringBuffer();
                    HBCIUtilsInternal.getCallback().callback(this,
                        HBCICallback.NEED_PT_TAN,
                        secmechInfo.getProperty("name")+" "+secmechInfo.getProperty("inputinfo")+": "+challenge,
                        HBCICallback.TYPE_TEXT,
                        s);
                    if (s.length()==0) {
                        throw new HBCI_Exception(HBCIUtilsInternal.getLocMsg("EXCMSG_TANZERO"));
                    }
                    tan=s.toString();
                }
            }
            if (tan.length()!=0) {
            	LogFilter.getInstance().addSecretData(tan,"X",LogFilter.FILTER_SECRETS);
            }

            return (pin+"|"+tan).getBytes("ISO-8859-1");
        } catch (Exception ex) {
            throw new HBCI_Exception("*** signing failed",ex);
        }
    }

    public boolean verify(byte[] data,byte[] sig)
    {
        // TODO: fuer bankensignaturen fuer HITAN muss dass hier ge�ndert werden
        return true;
    }

    public byte[][] encrypt(byte[] plainMsg)
    {
        try {
            int padLength=plainMsg[plainMsg.length-1];
            byte[] encrypted=new String(plainMsg,0,plainMsg.length-padLength,"ISO-8859-1").getBytes("ISO-8859-1");
            return new byte[][] {new byte[8],encrypted};
        } catch (Exception ex) {
            throw new HBCI_Exception("*** encrypting message failed",ex);
        }
    }

    public byte[] decrypt(byte[] cryptedKey,byte[] cryptedMsg)
    {
        try {
            return new String(new String(cryptedMsg,"ISO-8859-1")+'\001').getBytes("ISO-8859-1");
        } catch (Exception ex) {
            throw new HBCI_Exception("*** decrypting of message failed",ex);
        }
    }
    
    public void close()
    {
        super.close();
        passportKey=null;
    }
    
    private void setCertFile(String filename)
    {
        this.certfile=filename;
    }
    
    public String getCertFile()
    {
        return certfile;
    }
    
    protected void setCheckCert(boolean skip)
    {
        this.checkCert=skip;
    }
    
    public boolean getCheckCert()
    {
        return checkCert;
    }
    
    public void deactivateTANVerifyMode()
    {
        this.verifyTANMode=false;
    }

    public void activateTANVerifyMode()
    {
        this.verifyTANMode=true;
    }

    public String getProxy() 
    {
        return proxy;
    }

    public void setProxy(String proxy) 
    {
        this.proxy = proxy;
    }

    public String getProxyPass() 
    {
        return proxypass;
    }

    public String getProxyUser() 
    {
        return proxyuser;
    }

    public void setProxyPass(String proxypass) 
    {
        this.proxypass = proxypass;
    }

    public void setProxyUser(String proxyuser) 
    {
        this.proxyuser = proxyuser;
    }
}
