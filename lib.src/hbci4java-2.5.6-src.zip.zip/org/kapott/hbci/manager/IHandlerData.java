
/*  $Id: IHandlerData.java,v 1.2 2007/12/18 20:36:55 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.manager;

import org.kapott.hbci.passport.HBCIPassport;

// Dieses Interface wird von einigen Klassen implementiert (HBCIHandler,
// HBCIInstitute, HBCIUser). Es dient dazu, ein "allgemeines" Interface
// f�r alle Klassen zu haben, die sowohl ein Passport als auch einen
// verwendeten Kernel zur�ckgeben k�nnen, also alles, was man zum Ausf�hren
// von HBCI-Dialogen braucht
//
// Wichtig ist: Klassen, die dieses Interface implementieren, m�ssen daf�r
// sorgen, dass bei dem HBCIPassport-Objekt, welches hier evtl. zur�ckgegeben 
// wird, der entsprechende "parentHandler" gesetzt ist (analoges gilt auch
// f�r das HCBIKernel-Objekt):
//   public MyIHandlerData(passport,kernel) {
//     this.passport=passport; this.kernel=kernel;
//     this.passport.setParentHandler(this);
//     this.kernel.setParentHandler(this);
//   }
// 
// Damit soll sichergestellt sein, dass auch folgendes funktioniert:
//   passport = AbstractHBCIPassport.getInstance();
//   kernel = HBCIKernelFactory.getKernel(null, "220");
//   inst = HBCIInstitute(kernel,passport);
//
// An dieser Stelle kennt "inst" nun sowohl passport als auch kernel und k�nnte
// diese Objekte via getPassport() bzw. getKernel() zur�ckgeben. Wenn nun eine
// Methode aus einem der "Kind-Objekte" aufgerufen wird, die �ber das parent-
// Objekt auf das andere Kind-Objekt zugreifen will:
//   ...
//   inst.getKernel().doSomething();
//
//   public void HBCIKernel.doSomething() {
//     HBCIPassport passport=this.getParentHandler().getPassport();
//     ...
//   }
//   
// kernel.getParentHandler() liefert aber nur dann nicht-null, wenn irgendjemand
// auch tats�chlich dem HBCIKernel-Objekt mal gesagt hat, wer sein parent-Handler
// ist. Und genau das sollte ein IHandlerData-Objekt f�r seine "Kinder"
// passport und kernel erledigen.

// TODO: das sieht aus wie ein typisches DesignPattern - das evtl. mal
// irgendwie verallgemeinern (double-linked-parent-child-connection) und �berall
// wo n�tig einsetzen (evtl. inklusive asserts oder automatischer Setter)

public interface IHandlerData 
{
    public HBCIPassport getPassport();
    public HBCIKernel getKernel();
}
