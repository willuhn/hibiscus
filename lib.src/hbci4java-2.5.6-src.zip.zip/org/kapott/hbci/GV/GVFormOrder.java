
/*  $Id: GVFormOrder.java,v 1.9 2007/12/21 16:49:26 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.GV;

import org.kapott.hbci.GV_Result.HBCIJobResultImpl;
import org.kapott.hbci.manager.HBCIHandler;
import org.kapott.hbci.manager.LogFilter;
import org.kapott.hbci.passport.HBCIPassport;

public final class GVFormOrder
    extends HBCIJobImpl
{
    public static String getLowlevelName()
    {
        return "FormOrder";
    }
    
    public GVFormOrder(HBCIHandler handler)
    {
        super(handler,getLowlevelName(),new HBCIJobResultImpl());

        addConstraint("delivery","delivery",null, LogFilter.FILTER_NONE);
        addConstraint("formcode","code",null, LogFilter.FILTER_NONE);

        HBCIPassport passport=handler.getPassport();
        addConstraint("my.country","KTV.KIK.country",passport.getUPD().getProperty("KInfo.KTV.KIK.country"), LogFilter.FILTER_NONE);
        addConstraint("my.blz","KTV.KIK.blz",passport.getUPD().getProperty("KInfo.KTV.KIK.blz"), LogFilter.FILTER_MOST);
        addConstraint("my.number","KTV.number",passport.getUPD().getProperty("KInfo.KTV.number"), LogFilter.FILTER_IDS);
        addConstraint("my.subnumber","KTV.subnumber",passport.getUPD().getProperty("KInfo.KTV.subnumber",""), LogFilter.FILTER_MOST);
        addConstraint("count","count","", LogFilter.FILTER_NONE);
        addConstraint("printaddr","printaddr","N", LogFilter.FILTER_NONE);
        addConstraint("name","Address.name1","", LogFilter.FILTER_IDS);
        addConstraint("name2","Address.name2","", LogFilter.FILTER_IDS);
        addConstraint("street","Address.street_pf","", LogFilter.FILTER_MOST);
        addConstraint("ort","Address.plz_ort","", LogFilter.FILTER_MOST);
        addConstraint("tel","Address.tel","", LogFilter.FILTER_MOST);
    }
    
    public void verifyConstraints()
    {
        super.verifyConstraints();
        checkAccountCRC("my");
    }
}
