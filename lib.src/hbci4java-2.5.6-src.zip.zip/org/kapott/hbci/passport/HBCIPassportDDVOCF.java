
/*  $Id: HBCIPassportDDVOCF.java,v 1.3 2007/08/29 12:53:29 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.passport;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.StreamCorruptedException;
import java.util.Enumeration;
import java.util.Properties;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.spec.PBEParameterSpec;

import opencard.core.service.CardRequest;
import opencard.core.service.SmartCard;
import opencard.core.terminal.CardTerminalFactory;
import opencard.core.terminal.CardTerminalRegistry;

import org.kapott.hbci.callback.HBCICallback;
import org.kapott.hbci.datatypes.SyntaxCtr;
import org.kapott.hbci.exceptions.HBCI_Exception;
import org.kapott.hbci.exceptions.InvalidPassphraseException;
import org.kapott.hbci.manager.HBCIKey;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.manager.HBCIUtilsInternal;
import org.kapott.hbci.ocf.DDVBankData;
import org.kapott.hbci.ocf.DDVCardService;
import org.kapott.hbci.ocf.DDVKeyData;
import org.kapott.hbci.ocf.HBCICardService;

public class HBCIPassportDDVOCF 
    extends HBCIPassportDDV
{
    private SmartCard     smartCard;
    private DDVCardService cardService;
    
    public HBCIPassportDDVOCF(Object init, int dummy)
    {
        super(init,dummy);
        setParamHeader("client.passport.DDVOCF");
    }

    public HBCIPassportDDVOCF(Object init)
    {
        this(init,0);

        // get ddv-parameters
        String path=HBCIUtils.getParam(getParamHeader()+".path","./");
        
        // set parameters for initializing card
        setUseBio(Integer.parseInt(HBCIUtils.getParam(getParamHeader()+".usebio","-1")));
        setUseSoftPin(Integer.parseInt(HBCIUtils.getParam(getParamHeader()+".softpin","-1")));
        setSoftPin(new byte[0]);
        setPINEntered(false);
        setEntryIdx(Integer.parseInt(HBCIUtils.getParam(getParamHeader()+".entryidx","1")));

        // init card
        HBCIUtils.log("initializing OCF",HBCIUtils.LOG_DEBUG);
        try {
            HBCIUtilsInternal.getCallback().callback(this,
                                             HBCICallback.NEED_CHIPCARD,
                                             HBCIUtilsInternal.getLocMsg("CALLB_NEED_CHIPCARD"),
                                             HBCICallback.TYPE_NONE,
                                             null);
            initCT();
        } catch (Exception e) {
            try {
                closeCT();
            } catch (Exception e2) {
                HBCIUtils.log(e2);
            }

            throw new HBCI_Exception(HBCIUtilsInternal.getLocMsg("EXCMSG_CTERR"),e);
        } finally {
            HBCIUtilsInternal.getCallback().callback(this,
                                             HBCICallback.HAVE_CHIPCARD,
                                             "",
                                             HBCICallback.TYPE_NONE,
                                             null);
        }
        
        // init basic bank data
        try {
            setPort(new Integer(3000));
            setFilterType("None");
            ctReadBankData();
            
            if (askForMissingData(true,true,true,false,false,true,false))
                saveBankData();
                
            ctReadKeyData();
        } catch (Exception e) {
            try {
                closeCT();
            } catch (Exception e2) {
                HBCIUtils.log(e2);
            }

            throw new HBCI_Exception(HBCIUtilsInternal.getLocMsg("EXCMSG_PASSPORT_INSTDATAERR"),e);
        }

        setFileName(HBCIUtilsInternal.withCounter(path+getCardId(),getEntryIdx()-1));
        HBCIUtils.log(HBCIUtilsInternal.getLocMsg("INFO_PASS_LOADFILE",getFileName()),HBCIUtils.LOG_DEBUG);

        FileInputStream f=null;
        try {
            f=new FileInputStream(getFileName());
        } catch (Exception e) {
            HBCIUtils.log(HBCIUtilsInternal.getLocMsg("EXCMSG_PASSPORT_READERR"),HBCIUtils.LOG_WARN);
        }

        if (f!=null) {
            ObjectInputStream o=null;
            try {
                f.close();
                int retries=Integer.parseInt(HBCIUtils.getParam("client.retries.passphrase","3"));

                while (true) {                        // loop for entering the correct passphrase
                    if (getPassportKey()==null)
                        setPassportKey(calculatePassportKey(FOR_LOAD));

                    PBEParameterSpec paramspec=new PBEParameterSpec(CIPHER_SALT,CIPHER_ITERATIONS);
                    Cipher cipher=Cipher.getInstance("PBEWithMD5AndDES");
                    cipher.init(Cipher.DECRYPT_MODE,getPassportKey(),paramspec);
                    
                    o=null;
                    try {
                        o=new ObjectInputStream(new CipherInputStream(new FileInputStream(getFileName()),cipher));
                    } catch (StreamCorruptedException e) {
                        setPassportKey(null);
                        
                        retries--;
                        if (retries<=0)
                            throw new InvalidPassphraseException(e);
                    }
                    
                    if (o!=null)
                        break;
                }

                setBPD((Properties)(o.readObject()));
                setUPD((Properties)(o.readObject()));
                setHBCIVersion((String)o.readObject());
            } catch (Exception e) {
                try {
                    closeCT();
                } catch (Exception e2) {
                    HBCIUtils.log(e2);
                }

                throw new HBCI_Exception(HBCIUtilsInternal.getLocMsg("EXCMSG_PASSPORT_READERR"),e);
            } finally {
                try {
                    if (o!=null)
                        o.close();
                } catch (Exception e) {
                    HBCIUtils.log(e);
                }
            }
        }
    }

    protected void initCT()
    {
        try {
            if (!SmartCard.isStarted()) {
                System.setProperty("OpenCard.loaderClassName", "org.kapott.hbci.ocf.CTPropertiesLoader");
                SmartCard.start();
            }
            
            CardTerminalRegistry terminalRegistry=CardTerminalRegistry.getRegistry();
            for (Enumeration e=terminalRegistry.getCardTerminals();e.hasMoreElements();) {
                HBCIUtils.log("active card terminal factory: "+e.nextElement().toString(),HBCIUtils.LOG_DEBUG);
            }
            
            // wait for card
            CardRequest request=new CardRequest(CardRequest.ANYCARD, null, null);
            request.setTimeout(60);
            this.smartCard=SmartCard.waitForCard(request);
            
            // get card service
            this.cardService=(DDVCardService)smartCard.getCardService(DDVCardService.class,true);
            
            // getCID
            byte[] cid=this.cardService.getCID();
            this.setCID(new String(cid,"ISO-8859-1"));
            
            // extract card id
            StringBuffer cardId=new StringBuffer();
            for (int i=0;i<8;i++) {
                cardId.append((char)(((cid[i+1]>>4)&0x0F) + 0x30));
                cardId.append((char)((cid[i+1]&0x0F) + 0x30));
            }
            this.setCardId(cardId.toString());
        } catch (Exception e) {
            throw new HBCI_Exception(e);
        }
    }
    
    protected void ctReadBankData()
    {
        int         idx=this.getEntryIdx()-1;
        DDVBankData bankData=this.cardService.readBankData(idx);
        
        this.setCountry(SyntaxCtr.getName(bankData.country));
        this.setBLZ(bankData.blz);
        this.setHost(bankData.commaddr);
        this.setUserId(bankData.userid);
    }
    
    protected void ctReadKeyData()
    {
        this.setSigId(new Long(cardService.readSigId()));
        
        // readKeyData
        DDVKeyData[] keyData=cardService.readKeyData();
        
        this.setInstSigKey(new HBCIKey(
            getCountry(), getBLZ(), getUserId(), 
            Integer.toString(keyData[0].num), Integer.toString(keyData[0].version), 
            null));
        
        this.setInstEncKey(new HBCIKey(
            getCountry(), getBLZ(), getUserId(), 
            Integer.toString(keyData[1].num), Integer.toString(keyData[1].version),
            null));
    }
    
    protected void ctEnterPIN()
    {
        // TODO: auto-detect useSoftPin
        // TODO: auto-detect useBio
        
        if (getUseSoftPin()==1) {
            this.cardService.verifySoftPIN(1, this.getSoftPin(), HBCICardService.PIN_FORMAT_PIN2);
        } else {
            this.cardService.verifyHardPIN(getUseBio()==1, 1, HBCICardService.PIN_FORMAT_PIN2);
        }
    }
    
    protected void ctSaveBankData()
    {
        int        idx=this.getEntryIdx()-1;
        DDVBankData bankData;
        
        bankData=cardService.readBankData(idx);
        bankData.country=SyntaxCtr.getCode(this.getCountry());
        bankData.blz=this.getBLZ();
        bankData.commaddr=this.getHost();
        bankData.userid=this.getUserId();
        cardService.writeBankData(idx,bankData);
    }
    
    protected void ctSaveSigId()
    {
        cardService.writeSigId(getSigId().intValue());
    }
    
    protected byte[] ctSign(byte[] data)
    {
        return cardService.sign(data);
    }

    protected byte[][] ctEncrypt()
    {
        return cardService.getEncryptionKeys(Integer.parseInt(getInstEncKeyNum()));
    }
    
    protected byte[] ctDecrypt(byte[] cryptedKey)
    {
        return cardService.decrypt(Integer.parseInt(getInstEncKeyNum()),cryptedKey);
    }
    
    protected void closeCT()
    {
        try {
            if (smartCard!=null) {
                smartCard.close();
            }
            // TODO: disabled because it throws an exception 
            // SmartCard.shutdown();
        } catch (Exception e) {
            throw new HBCI_Exception(e);
        }
    }
}
