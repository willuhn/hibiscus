
/*  $Id: HBCIPassportRDH2File.java,v 1.12 2007/12/21 15:38:43 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2007  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.passport;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.kapott.hbci.callback.HBCICallback;
import org.kapott.hbci.exceptions.HBCI_Exception;
import org.kapott.hbci.manager.HBCIKey;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.manager.HBCIUtilsInternal;
import org.kapott.hbci.manager.LogFilter;
import org.kapott.hbci.passport.rdh2file.HBCIAccount;
import org.kapott.hbci.passport.rdh2file.RDH2File;
import org.kapott.hbci.passport.rdh2file.TLV;

/**<p>
 * Passport-Klasse f�r die Verwendung von RDH-2-Schl�sseldateien mit
 * <em>HBCI4Java</em>. RDH-2-Schl�sseldateien sind Schl�sseldateien f�r
 * RDH-Zug�nge, die von anderer HBCI-Software erzeugt und verwendet werden (z.B.
 * von <em>VR-NetWorld</em>). Soll eine solche Schl�sseldatei sowohl mit der
 * anderen Software als auch mit <em>HBCI4Java</em> verwendet werden, so kann
 * das mit dieser Passport-Variante geschehen.</p> */    
public class HBCIPassportRDH2File
    extends AbstractRDHSWFileBasedPassport
{
    private RDH2File filecontent;
    private int      entryIdx;
    
    public HBCIPassportRDH2File(Object init,int dummy)
    {
        super(init);
    }

    public HBCIPassportRDH2File(Object initObject)
    {
        this(initObject,0);
        setParamHeader("client.passport.RDH2File");

        String fname=HBCIUtils.getParam(getParamHeader()+".filename");
        HBCIUtils.log(HBCIUtilsInternal.getLocMsg("INFO_PASS_LOADFILE",fname),HBCIUtils.LOG_DEBUG);
        setFilename(fname);

        boolean init=HBCIUtils.getParam(getParamHeader()+".init").equals("1");
        if (init) {
            HBCIUtils.log(HBCIUtilsInternal.getLocMsg("DBG_PASS_LOADDATE",getFilename()),HBCIUtils.LOG_DEBUG);

            setCountry("DE");
            setFilterType("None");
            setPort(new Integer(3000));

            if (!new File(getFilename()).canRead()) {
                HBCIUtils.log(HBCIUtilsInternal.getLocMsg("WRN_PASS_NEWFILE"),HBCIUtils.LOG_WARN);
                askForMissingData(false,true,true,false,false,true,true);
                saveChanges();
            }
            
            try {
            	StringBuffer retData=new StringBuffer();
            	HBCIUtilsInternal.getCallback().callback(this,
            			HBCICallback.NEED_PASSPHRASE_LOAD,
            			HBCIUtilsInternal.getLocMsg("CALLB_NEED_PASS"),
            			HBCICallback.TYPE_SECRET,
            			retData);
            	LogFilter.getInstance().addSecretData(retData.toString(),"X",LogFilter.FILTER_SECRETS);
            	byte[] passphrase=retData.toString().getBytes("ISO-8859-1");
            	
            	// daten einlesen
                FileInputStream fin=new FileInputStream(fname);
                StringBuffer    sb=new StringBuffer();
                byte[]          buffer=new byte[1024];
                int             size;
                
                while ((size=fin.read(buffer))>0) {
                    sb.append(new String(buffer,0,size,"ISO-8859-1"));
                }
                
                fin.close();
                byte[] data=sb.toString().getBytes("ISO-8859-1");
                // System.out.println("read "+data.length+" bytes from "+getFileName());
                
                // filecontent-content
                this.filecontent=new RDH2File(data, passphrase);
                this.entryIdx=0;
                
                TLV[] hbciAccounts=filecontent.getFields(HBCIAccount.class);
                if (hbciAccounts.length>1) {
                    // wenn mehrere bankverbindungen existieren, callback f�r auswahl der "richtigen"
                    StringBuffer possibilities=new StringBuffer();
                    for (int i=0;i<hbciAccounts.length;i++) {
                        HBCIAccount hbciAccount=(HBCIAccount)hbciAccounts[i];
                        if (i!=0) {
                            possibilities.append("|");
                        }
                        possibilities.append(i);
                        possibilities.append(";"+hbciAccount.getBLZ());
                        possibilities.append(";"+hbciAccount.getUserId());
                    }
                    
                    HBCIUtilsInternal.getCallback().callback(
                        this,
                        HBCICallback.NEED_SIZENTRY_SELECT,
                        "*** select one of the following entries",
                        HBCICallback.TYPE_TEXT,
                        possibilities);
                     
                    this.entryIdx=Integer.parseInt(possibilities.toString());
                }
                
                // set all passport values
                HBCIAccount hbciAccount=(HBCIAccount)(filecontent.getFields(HBCIAccount.class)[entryIdx]);
                
                setBLZ(hbciAccount.getBLZ());
                setHost(hbciAccount.getHost());
                setUserId(hbciAccount.getUserId());
                setCustomerId(hbciAccount.getCustomerId());
                setSysId(hbciAccount.getSysId());
                setSigId(new Long(hbciAccount.getSigId()));
                
                // setInstKeys()
                setInstSigKey(filecontent.getBankSigKey(hbciAccount));
                setInstEncKey(filecontent.getBankEncKey(hbciAccount));
                
                // setUserKeys()
                HBCIKey[] userkeys=hbciAccount.getUserSigKeys();
                setMyPublicSigKey(userkeys[0]);
                setMyPrivateSigKey(userkeys[1]);
                
                userkeys=hbciAccount.getUserEncKeys();
                setMyPublicEncKey(userkeys[0]);
                setMyPrivateEncKey(userkeys[1]);
                                
                if (askForMissingData(false,true,true,false,false,true,true))
                    saveChanges();
            } catch (Exception e) {
                throw new HBCI_Exception("*** error while reading passport file",e);
            }
        }
    }
    
    public void saveChanges()
    {
        try {
        	// TODO: da wir im Moment nur schon existierende Keyfiles
        	// bearbeiten k�nnen, gibt es mit Sicherheit schon
        	// ein gef�lltes filecontent, und wir brauchen die
        	// passphrase nicht abfragen
        	
        	/*
            if (passphrase==null) {
                StringBuffer retData=new StringBuffer();
                HBCIUtilsInternal.getCallback().callback(this,
                                                 HBCICallback.NEED_PASSPHRASE_SAVE,
                                                 HBCIUtilsInternal.getLocMsg("CALLB_NEED_PASS"),
                                                 HBCICallback.TYPE_SECRET,
                                                 retData);
                setPassphrase(retData.toString());
            }
            */
            
        	// create temp file
            File   passportfile=new File(getFilename());
            File   directory=passportfile.getAbsoluteFile().getParentFile();
            String prefix=passportfile.getName()+"_";
            File   tempfile=File.createTempFile(prefix,"",directory);
            
            // save changed values in filecontent object
            HBCIAccount hbciAccount=(HBCIAccount)(filecontent.getFields(HBCIAccount.class)[entryIdx]);
            
            hbciAccount.setBLZ(getBLZ());
            hbciAccount.setHost(getHost());
            hbciAccount.setUserId(getUserId());
            hbciAccount.setCustomerId(getCustomerId());
            hbciAccount.setSysId(getSysId());
            hbciAccount.setSigId(getSigId().longValue());
            
            filecontent.setBankSigKey(hbciAccount,getInstSigKey());
            filecontent.setBankEncKey(hbciAccount,getInstEncKey());
            
            hbciAccount.setUserSigKeys(new HBCIKey[] {getMyPublicSigKey(), getMyPrivateSigKey()});
            hbciAccount.setUserEncKeys(new HBCIKey[] {getMyPublicEncKey(), getMyPrivateEncKey()});
            
            byte[]           data=filecontent.getFileData();
            FileOutputStream fo=new FileOutputStream(tempfile);
            fo.write(data);
            fo.close();
            
            passportfile.delete();
            tempfile.renameTo(passportfile);
        } catch (Exception e) {
            throw new HBCI_Exception("*** saving of passport file failed",e);
        }
    }
    
    public String getProfileVersion()
    {
        // TODO: m�glicherweise auch RDH-10 - Unterscheidung zwischen RDH-2 und -10 jedoch nicht klar
        return "2";
    }
    
}
