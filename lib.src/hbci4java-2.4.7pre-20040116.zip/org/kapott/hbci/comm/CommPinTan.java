
/*  $Id: CommPinTan.java,v 1.7 2004/01/06 08:19:17 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2003  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.comm;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.kapott.hbci.MsgGen;
import org.kapott.hbci.exceptions.HBCI_Exception;
import org.kapott.hbci.exceptions.InvalidUserDataException;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.passport.HBCIPassportInternal;
import org.kapott.hbci.protocol.MSG;

public final class CommPinTan
    extends Comm
{
    private URL               url;
    private HttpURLConnection conn;

    public CommPinTan(HBCIPassportInternal passport)
    {
        super(passport);
        
        String trustStore=HBCIUtils.getParam("client.passport.PinTan.certfile");
        if (trustStore==null)
            throw new InvalidUserDataException(HBCIUtils.getLocMsg("EXCMSG_CERTMISSING"));
        if (trustStore.length()!=0)
            System.setProperty("javax.net.ssl.trustStore",trustStore);
        
        try {
            String destination="https://"+passport.getHost();
            HBCIUtils.log(HBCIUtils.getLocMsg("INFO_PT_COMMNEW",destination),HBCIUtils.LOG_INFO);
            url=new URL(destination);

            /* *** how to implement this ?
                     int localPort=Integer.parseInt(HBCIUtils.getParam("client.connection.localPort","0"));
                     if (localPort!=0) {
                s.setReuseAddress(true);
                s.bind(new InetSocketAddress(localPort));
                     }
             */
        } catch (Exception e) {
            throw new HBCI_Exception(HBCIUtils.getLocMsg("EXCMSG_CONNERR"),e);
        }
    }

    protected void ping(MSG msg)
    {
        try {
            byte[] b=filter.encode(msg.toString(0));

            HBCIUtils.log(HBCIUtils.getLocMsg("INFO_PT_COMMCONN"),HBCIUtils.LOG_DEBUG);
            conn=(HttpURLConnection)url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.connect();
            conn.getOutputStream().write(b);
        } catch (Exception e) {
            throw new HBCI_Exception(HBCIUtils.getLocMsg("EXCMSG_SENDERR"),e);
        }
    }

    protected StringBuffer pong(MsgGen gen)
    {
        try {
            byte[] b=new byte[1024];
            StringBuffer ret=new StringBuffer();

            HBCIUtils.log(HBCIUtils.getLocMsg("INFO_COMM_WAIT"),HBCIUtils.LOG_INFO);

            int msgsize=conn.getContentLength();
            int num;

            HBCIUtils.log(HBCIUtils.getLocMsg("DBG_COMM_FOUND",Integer.toString(msgsize)),HBCIUtils.LOG_DEBUG);
            InputStream i=conn.getInputStream();

            while (msgsize>0&&(num=i.read(b))>0) {
                HBCIUtils.log(HBCIUtils.getLocMsg("DBG_COMM_RECV",Integer.toString(num)),HBCIUtils.LOG_DEBUG);
                ret.append(new String(b,0,num,"ISO-8859-1"));
                msgsize-=num;
                HBCIUtils.log(HBCIUtils.getLocMsg("DBG_COMM_CURRENT",Integer.toString(msgsize)),HBCIUtils.LOG_DEBUG);
            }

            HBCIUtils.log(HBCIUtils.getLocMsg("INFO_COMM_CLOSE"),HBCIUtils.LOG_DEBUG);
            conn.disconnect();
            return new StringBuffer(filter.decode(ret.toString()));
        } catch (Exception e) {
            throw new HBCI_Exception(HBCIUtils.getLocMsg("EXCMSG_RECVERR"),e);
        }
    }

    protected void closeConnection()
    {
    }
}
