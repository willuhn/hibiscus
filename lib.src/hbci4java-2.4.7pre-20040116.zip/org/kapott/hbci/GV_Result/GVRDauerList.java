
/*  $Id: GVRDauerList.java,v 1.3 2004/01/16 08:04:26 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2003  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.GV_Result;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.structures.Konto;
import org.kapott.hbci.structures.Value;

/** Ergebnisse der Abfrage von bestehenden Dauerauftr�gen. In diesem Objekt
    wird eine Liste von Dauerauftragsdaten gespeichert. Jedes dieser Dauerauftragsdaten-Objekte
    beschreibt dabei einen bestehenden Dauerauftrag. */ 
public final class GVRDauerList
    extends HBCIJobResult
{
    /** Informationen zu einem einzelnen Dauerauftrag. */
    public static final class Dauer
    {
        /** Belastungskonto (Kundenkonto) */
        public Konto    my;
        /** Empf�ngerkonto */
        public Konto    other;
        /** Zu �berweisender Betrag */
        public Value    value;
        /** Transaktionsschl�ssel (bankintern) */
        public String   key;
        /** Zus�tzlicher Transaktionsschl�ssel (bankintern, optional) */
        public String   addkey;
        /** Verwendungszweckzeilen. Dieses Array ist niemals <code>null</code>,
            kann aber die L�nge <code>0</code> haben. */
        public String[] usage;
        /** Datum der n�chsten Ausf�hrung */
        public Date     nextdate;
        /** Eindeutige Auftragsnummer, um diesen Dauerauftrag zu identifizieren (optional) */
        public String   orderid;

        /** Datum der ersten Ausf�hrung */
        public Date     firstdate;
        /** Zeiteinheit der Wiederholung.
            <ul>
              <li>M - monatlich</li>
              <li>W - w�chentlich</li>
            </ul> */
        public String   timeunit;
        /** Wiederholen aller wieviel Zeiteinheiten */
        public int      turnus;
        /** Tag der Ausf�hrun innerhalb der Zeineinheit
            <ul>
              <li>bei Zeiteinheit=W: 1-7 f�r Wochentag</li>
              <li>bei Zeiteinheit=M: 1-31 f�r Tag des Monats</li>
            </ul> */
        public int      execday;
        /** Datum, wann der Dauerauftrag zum letzten Mal ausgef�hrt werden soll (optional) */
        public Date     lastdate;

        /** Sind Daten zu einer geplanten Aussetzung vorhanden? */
        public boolean aus_available;
        /** Aussetzung j�hrlich wiederholen? (Nur g�ltig, wenn <code>aus_available</code> <code>true</code> ist) */
        public boolean  aus_annual;
        /** Tag der ersten Aussetzung (Nur g�ltig, wenn <code>aus_available</code> <code>true</code> ist) (optional) */
        public Date     aus_start;
        /** Tag der letzten Aussetzung (Nur g�ltig, wenn <code>aus_available</code> <code>true</code> ist) (optional) */
        public Date     aus_end;
        /** Anzahl der Aussetzungen (Nur g�ltig, wenn <code>aus_available</code> <code>true</code> ist) (optional) */
        public String   aus_breakcount;
        /** Ge�nderter Betrag w�hrend Aussetzung (Nur g�ltig, wenn <code>aus_available</code> <code>true</code> ist) (optional) */
        public String   aus_newvalue;
        /** Ge�nderte W�hrung w�hrend Aussetzung (Nur g�ltig, wenn <code>aus_available</code> <code>true</code> ist) (optional) */
        public String   aus_newcurr;

        public Dauer()
        {
            usage=new String[0];
        }

        public void addUsage(String line)
        {
            ArrayList a=new ArrayList(Arrays.asList(usage));
            a.add(line);
            usage=(String[])(a.toArray(usage));
        }

        public String toString()
        {
            StringBuffer ret=new StringBuffer();
            String linesep=System.getProperty("line.separator");
            
            ret.append("  "+HBCIUtils.getLocMsg("SRCACCOUNT")+": "+my.toString()+linesep);
            ret.append("  "+HBCIUtils.getLocMsg("DSTACCOUNT")+": "+other.toString()+linesep);
            ret.append("  "+HBCIUtils.getLocMsg("VALUE")+": "+value.toString()+linesep);
            ret.append("  "+HBCIUtils.getLocMsg("KEY")+": "+key+"/"+addkey+linesep);
            ret.append("  "+HBCIUtils.getLocMsg("USAGE")+":"+linesep);
            for (int i=0;i<usage.length;i++) {
                ret.append("    "+usage[i]+linesep);
            }
            if (nextdate!=null)
                ret.append("  "+HBCIUtils.getLocMsg("NEXTEXECDATE")+": "+HBCIUtils.date2String(nextdate)+linesep);
            ret.append("  "+HBCIUtils.getLocMsg("ORDERID")+": "+orderid+linesep);

            ret.append("  "+HBCIUtils.getLocMsg("FIRSTLASTEXEC")+": "+HBCIUtils.date2String(firstdate)+" / "+
                    (lastdate!=null?HBCIUtils.date2String(lastdate):"N/A")+linesep);
                    ret.append("  "+HBCIUtils.getLocMsg("EXECDAY")+": "+execday+linesep);
            ret.append("  "+HBCIUtils.getLocMsg("UNITTURNUS")+": "+timeunit+" / "+turnus+linesep);

            ret.append("  (Aussetzung not yet implemented)");

            return ret.toString().trim();
        }
    }

    private Dauer[] entries;

    public GVRDauerList()
    {
        entries=new Dauer[0];
    }

    public void addEntry(Dauer entry)
    {
        ArrayList a=new ArrayList(Arrays.asList(entries));
        a.add(entry);
        entries=(Dauer[])(a.toArray(entries));
    }
    
    /** Gibt ein Array mit Daten zu allen gefundenen Dauerauftragsdaten zur�ck
        @return Array mit Dauerauftrags-Informationen */
    public Dauer[] getEntries()
    {
        return entries;
    }
    
    public String toString()
    {
        StringBuffer ret=new StringBuffer();

        for (int i=0;i<entries.length;i++) {
            ret.append(HBCIUtils.getLocMsg("STANDINGORDER")+" #"+i+System.getProperty("line.separator"));
            ret.append(entries[i].toString()+System.getProperty("line.separator"));
        }
        
        return ret.toString().trim();
    }
}
