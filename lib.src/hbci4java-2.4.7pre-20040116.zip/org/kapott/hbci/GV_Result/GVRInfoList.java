
/*  $Id: GVRInfoList.java,v 1.3 2004/01/16 08:04:26 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2003  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.GV_Result;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.kapott.hbci.manager.HBCIUtils;

/** R�ckgabedaten f�r die Abfrage verf�gbarer Kreditinstitutsinformationen. Es
    wird eine Liste mit allen verf�gbaren Informationen gespeichert, wobei jeder
    Eintrag Daten �ber genau eine KI-Info enth�lt. */
public final class GVRInfoList
    extends HBCIJobResult
{
    /** Daten �ber eine einzelne verf�gbare Information */ 
    public static final class Info
    {
        /** Identifikationscode, mit der diese Information referenziert werden kann */
        public String code;
        /** Beschreibung des Inhalts dieser Information */
        public String description;
        /** Art der Information.
            <ul>
              <li>F f�r Freitextmeldung (siehe {@link org.kapott.hbci.GV_Result.GVRInfoOrder GVRInfoOrder})</li>
              <li>S es handelt sich um ein Schriftdokument, welches bestellt werden kann</li>
              <li>T f�r Themen�berschrift</li>
            </ul> */
        public String type; // *** das als int-konstante machen
        
        public String format;
        /** Version dieser Information (optional) */
        public Date   date;
        /** Kommentare zu dieser Information. Dieses Array ist niemals <code>null</code>,
            kann aber die L�nge <code>0</code> haben. */
        public String[] comment;

        public Info()
        {
            comment=new String[0];
        }
        
        public void addComment(String st)
        {
            ArrayList a=new ArrayList(Arrays.asList(comment));
            a.add(st);
            comment=(String[])a.toArray(comment);
        }

        public String toString()
        {
            StringBuffer ret=new StringBuffer();
            String       linesep=System.getProperty("line.separator");
            
            if (type.equals("F"))
                ret.append("Freitextmeldung");
            else if (type.equals("D"))
                ret.append("Datei");
            else if (type.equals("S"))
                ret.append("Schriftdokument");
            else if (type.equals("T"))
                ret.append("Themenueberschrift");
            
            if (format!=null)
                ret.append("("+format+")");
            
            ret.append(" "+code+" "+description);
            if (date!=null) 
                ret.append(" "+HBCIUtils.date2String(date));
            ret.append(linesep);
            
            for (int i=0;i<comment.length;i++) {
                ret.append(comment[i]+linesep);
            }
            
            return ret.toString().trim();
        }
    }

    private List entries;

    public GVRInfoList()
    {
        entries=new ArrayList();
    }

    public void addEntry(Info entry)
    {
        entries.add(entry);
    }
    
    /** Gibt Daten �ber alle abfragbaren Kreditinstitutsinformationen zur�ck
        @return Array, wobei jeder Eintrag eine solche Information beschreibt */
    public Info[] getEntries()
    {
        return (Info[])entries.toArray(new Info[0]);
    }

    public String toString()
    {
        StringBuffer ret=new StringBuffer();
        String       linesep=System.getProperty("line.separator");

        for (int i=0;i<entries.size();i++) {
            Info entry=(Info)entries.get(i);
            
            ret.append("Info #"+(i+1)+linesep);
            ret.append(entry.toString());
            ret.append(linesep+linesep);
        }
        
        return ret.toString().trim();
    }
}
