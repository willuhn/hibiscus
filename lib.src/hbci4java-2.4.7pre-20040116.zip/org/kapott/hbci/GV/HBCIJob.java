
/*  $Id: HBCIJob.java,v 1.15 2004/01/14 12:07:24 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2003  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.GV;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;

import org.kapott.hbci.MsgGen;
import org.kapott.hbci.GV_Result.HBCIJobResult;
import org.kapott.hbci.callback.HBCICallback;
import org.kapott.hbci.exceptions.HBCI_Exception;
import org.kapott.hbci.exceptions.InvalidUserDataException;
import org.kapott.hbci.exceptions.JobNotSupportedException;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.passport.HBCIPassportInternal;
import org.kapott.hbci.protocol.SEG;
import org.kapott.hbci.protocol.SyntaxElement;
import org.kapott.hbci.protocol.factory.SEGFactory;
import org.kapott.hbci.status.HBCIMsgStatus;
import org.kapott.hbci.status.HBCIRetVal;
import org.kapott.hbci.structures.Konto;
import org.kapott.hbci.structures.Value;

/** <p>Schnittstelle f�r alle Auftr�ge, die via HBCI ausgef�hrt werden sollen. Ein
    HBCIJob-Objekt wird nur innerhalb von <em>HBCI4Java</em> verwaltet. Durch Aufruf einer der Methoden
    {@link org.kapott.hbci.manager.HBCIHandler#newJob(String) HBCIHandler.newJob()} oder
    {@link org.kapott.hbci.manager.HBCIHandler#newLowlevelJob(String) HBCIHandler.newLowlevelJob()} wird
    eine neue Instanz eines HBCIJobs erzeugt. Die konkrete Klasse dieser Instanz ist
    f�r den Anwendungsentwickler nicht von Bedeutung.</p>
    <p>Die Anwendung muss nur die f�r diesen Job ben�tigten Parameter setzen (mit 
    {@link #setParam(String,String) setParam()}) und kann den fertig spezifizierten Job anschlie�end
    zum aktuellen HBCI-Dialog hinzuf�gen 
    ({@link org.kapott.hbci.manager.HBCIHandler#addJob(org.kapott.hbci.GV.HBCIJob) HBCIHandler.addJob()}).</p>
    <p>Nach Ausf�hrung des HBCI-Dialoges k�nnen die R�ckgabedaten und Statusinformationen f�r diesen
    Job ermittelt werden. Dazu wird die Methoode {@link #getJobResult() getJobResult()} ben�tigt, welche
    eine Instanz einer {@link org.kapott.hbci.GV_Result.HBCIJobResult HBCIJobResult}-Klasse zur�ckgibt.
    Die konkrete Klasse, um die es sich bei diesem Result-Objekt handelt, ist vom Typ des ausgef�hrten
    Jobs abh�ngig (z.B. gibt es eine Klasse, die Ergebnisdaten f�r Kontoausz�ge enth�lt, eine
    Klasse f�r Saldenabfragen usw.). Eine Beschreibung der einzelnen Klassen f�r Result-Objekte findet
    sich im Package {@link org.kapott.hbci.GV_Result}. Eine Beschreibung, welcher Job welche Klasse
    zur�ckgibt, befindet sich in der Package-Dokumentation zu diesem Package ({@link org.kapott.hbci.GV}).</p> */
public abstract class HBCIJob
{
    private String name;              /* @brief name of the corresponding GV-segment */
    private Properties params;       /* Eingabeparameter f�r diesen GV (Saldo.KTV.number) */
    private MsgGen gen;         /* msg-generator, um zu �berpr�fen, ob jobsegment erzeugt werden kann */
    private HBCIPassportInternal passport;
    protected HBCIJobResult jobResult;         /* Objekt mit R�ckgabedaten f�r diesen GV */
    private int idx;                  /* idx gibt an, der wievielte task innerhalb der aktuellen message
                                         dieser GV ist */
    private boolean executed;
    private int contentCounter;       /* Z�hler, wie viele R�ckgabedaten bereits in outStore eingetragen wurden 
                                           (entspricht der anzahl der antwort-segmente!)*/
    private Hashtable constraints;    /* Festlegungen, welche Parameter eine Anwendung setzen muss, wie diese im
                                         HBCI-Kernel umgesetzt werden und welche default-Werte vorgesehen sind; 
                                         die Hashtable hat als Schl�ssel einen String, der angibt, wie ein Wert aus einer
                                         Anwendung heraus zu setzen ist. Der dazugeh�rige Value ist ein Array. Jedes Element
                                         dieses Arrays ist ein String[2], wobei das erste Element angibt, wie der Pfadname heisst,
                                         unter dem der anwendungs-definierte Wert abzulegen ist, das zweite Element gibt den
                                         default-Wert an, falls f�r diesen Namen *kein* Wert angebeben wurde. Ist der default-
                                         Wert="", so kann das Syntaxelement weggelassen werden. Ist der default-Wert=null,
                                         so *muss* die Anwendung einen Wert spezifizieren */
    
    public HBCIJob(String jobnameLL,HBCIPassportInternal passport,HBCIJobResult jobResult)
    {
        this.name=findSpecNameForGV(jobnameLL,passport);
        this.params=new Properties();
        this.passport=passport;
        this.jobResult=jobResult;
        this.contentCounter=0;
        this.constraints=new Hashtable();
        this.executed=false;

        /* offensichtlich soll ein GV mit dem Namen name in die nachricht
           aufgenommen werden. da GV durch segmente definiert sind, und einige
           dieser segmente ein request-tag benoetigen (siehe klasse
           SyntaxElement), wird hier auf jeden fall das request-tag gesetzt.
           wenn es *nicht* benoetigt wird, schadet es auch nichts. und es ist
           auf keinen fall "zu viel" gesetzt, da dieser code nur ausgefuehrt wird,
           wenn das jeweilige segment tatsaechlich erzeugt werden soll */
        params.setProperty(this.name,"requested");
    }
    
    public String getHBCICode()
    {
        StringBuffer ret=null;
        
        StringBuffer searchString=new StringBuffer(name);
        for (int i=searchString.length()-1;i>=0;i--) {
            if (!(searchString.charAt(i)>='0' && searchString.charAt(i)<='9')) {
                searchString.insert(i+1,"Par");
                searchString.append(".SegHead.code");
                break;
            }
        }
        
        for (Enumeration i=passport.getBPD().propertyNames();i.hasMoreElements();) {
            String key=(String)i.nextElement();
            
            if (key.indexOf("Params")==0) {
                StringBuffer tempkey=new StringBuffer(key);
                tempkey.delete(0,tempkey.indexOf(".")+1);
                
                if (tempkey.toString().equals(searchString.toString())) {
                    ret=new StringBuffer(passport.getBPD().getProperty(key));
                    ret.replace(1,2,"K");
                    ret.deleteCharAt(ret.length()-1);
                    break;
                }
            }
        }
        
        return ret.toString();
    }
    
    private static String findSpecNameForGV(String jobnameLL,HBCIPassportInternal passport)
    {
        int maxVersion=0;
        
        for (Enumeration i=passport.getBPD().propertyNames();i.hasMoreElements();) {
            StringBuffer key=new StringBuffer((String)i.nextElement());
            
            if (key.indexOf("Params")==0) {
                key.delete(0,key.indexOf(".")+1);
                if (key.indexOf(jobnameLL)==0 &&
                    key.toString().endsWith(".SegHead.code")) {
                        
                    key.delete(0,jobnameLL.length()+("Par").length());
                    
                    String st=key.substring(0,key.indexOf("."));
                    int    version=0;
                    
                    try {
                        version=Integer.parseInt(st);
                    } catch (Exception e) {
                    }
                    
                    if (version!=0) {
                        HBCIUtils.log(HBCIUtils.getLocMsg("DBG_GV_FOUNDGV",new Object[] {jobnameLL,st}),HBCIUtils.LOG_DEBUG);
                        if (version>maxVersion) {
                            maxVersion=version;
                        }
                    }
                }
            }
        }
        
        if (maxVersion==0) {
            throw new JobNotSupportedException(jobnameLL);
        }
        
        return jobnameLL+Integer.toString(maxVersion);
    }
    
    public int getMaxNumberPerMsg()
    {
        int ret=1;
        
        StringBuffer searchString=new StringBuffer(name);
        for (int i=searchString.length()-1;i>=0;i--) {
            if (!(searchString.charAt(i)>='0' && searchString.charAt(i)<='9')) {
                searchString.insert(i+1,"Par");
                searchString.append(".maxnum");
                break;
            }
        }
        
        for (Enumeration i=passport.getBPD().propertyNames();i.hasMoreElements();) {
            String key=(String)i.nextElement();
            
            if (key.indexOf("Params")==0) {
                StringBuffer tempkey=new StringBuffer(key);
                tempkey.delete(0,tempkey.indexOf(".")+1);
                
                if (tempkey.toString().equals(searchString.toString())) {
                    ret=Integer.parseInt(passport.getBPD().getProperty(key));
                    break;
                }
            }
        }
        
        return ret;
    }

    protected void addConstraint(String frontendName,String destinationName,String defValue)
    {
        String[] value=new String[2];
        value[0]=getName()+"."+destinationName;
        value[1]=defValue;

        String[][] values=(String[][])(constraints.get(frontendName));

        if (values==null) {
            values=new String[1][];
            values[0]=value;
        } else {
            ArrayList a=new ArrayList(Arrays.asList(values));
            a.add(value);
            values=(String[][])(a.toArray(values));
        }

        constraints.put(frontendName,values);
    }
    
    public void verifyConstraints()
    {
        for (Iterator i=constraints.keySet().iterator();i.hasNext();) {
            String     frontendName=(String)(i.next());
            String[][] values=(String[][])(constraints.get(frontendName));

            for (int j=0;j<values.length;j++) {
                String[] value=values[j];
                String   destination=value[0];
                String   defValue=value[1];

                String   givenContent=params.getProperty(destination);
                String   content=null;

                content=defValue;
                if (givenContent!=null && givenContent.length()!=0)
                    content=givenContent;

                if (content==null) {
                    String msg=HBCIUtils.getLocMsg("EXC_MISSING_HL_PROPERTY",frontendName);
                    if (!HBCIUtils.ignoreError(passport,"client.errors.ignoreWrongJobDataErrors",msg))
                        throw new InvalidUserDataException(msg);
                    content="";
                }

                if (content.length()!=0 && givenContent==null)
                    setParam(frontendName,content);
            }
        }
        
        // verify if segment can be created
        SEG seg=null;
        try {
            seg=SEGFactory.getInstance().createSEG(getName(),getName(),null,0,gen.getSyntax());
            for (Enumeration e=getParams().propertyNames();e.hasMoreElements();) {
                String key=(String)e.nextElement();
                String value=getParams().getProperty(key);
                seg.propagateValue(key,value,
                                   SyntaxElement.TRY_TO_CREATE,
                                   SyntaxElement.DONT_ALLOW_OVERWRITE);
            }
            seg.enumerateSegs(0,false);
            seg.validate();
        } catch (Exception ex) {
            throw new HBCI_Exception("*** the job segment for this task can not be created",ex);
        } finally {
            SEGFactory.getInstance().unuseObject(seg);
        }
    }
    
    /** <p>Gibt f�r einen Job alle bekannten Einschr�nkungen zur�ck, die bei
        der Ausf�hrung des jeweiligen Jobs zu beachten sind. Diese Daten werden aus den
        Bankparameterdaten des aktuellen Passports extrahiert. Sie k�nnen von einer HBCI-Anwendung
        benutzt werden, um gleich entsprechende Restriktionen bei der Eingabe von
        Gesch�ftsvorfalldaten zu erzwingen (z.B. die maximale Anzahl von Verwendungszweckzeilen,
        ob das �ndern von terminierten �berweisungen erlaubt ist usw.).</p>
        <p>Die einzelnen Eintr�ge des zur�ckgegebenen Properties-Objektes enthalten als Key die
        Bezeichnung einer Restriktion (z.B. "<code>maxusage</code>"), als Value wird der
        entsprechende Wert eingestellt. Die Bedeutung der einzelnen Restriktionen ist zur Zeit
        nur der HBCI-Spezifikation zu entnehmen. In sp�teren Programmversionen werden entsprechende
        Dokumentationen zur internen HBCI-Beschreibung hinzugef�gt, so dass daf�r eine Abfrageschnittstelle
        implementiert werden kann.</p>
        @return Properties-Objekt mit den einzelnen Restriktionen */
    public Properties getJobRestrictions()
    {
        StringBuffer temp=new StringBuffer(getName());
        
        while (temp.length()>0 && temp.charAt(temp.length()-1)<='9')
            temp.deleteCharAt(temp.length()-1);
            
        return passport.getLowlevelGVRestrictions(temp.toString());
    }
    
    /** Setzen eines komplexen Job-Parameters (Kontodaten). Einige Jobs ben�tigten Kontodaten
        als Parameter. Diese m�ssten auf "normalem" Wege durch drei Aufrufe von 
        {@link #setParam(String,String) setParam(String,String)} erzeugt werden (je einer f�r
        die L�nderkennung, die Bankleitzahl und die Kontonummer). Durch Verwendung dieser
        Methode wird dieser Weg abgek�rzt. Es wird ein Kontoobjekt �bergeben, f�r welches
        die entsprechenden drei <code>setParam(String,String)</code>-Aufrufe automatisch
        erzeugt werden.
        @param paramname die Basis der Parameter f�r die Kontodaten (f�r "<code>my.country</code>",
        "<code>my.blz</code>", "<code>my.number</code>" w�re das also "<code>my</code>")
        @param acc ein Konto-Objekt, aus welchem die zu setzenden Parameterdaten entnommen werden */
    public void setParam(String paramname,Konto acc)
    {
        if (acc.country!=null && acc.country.length()!=0)
            setParam(paramname+".country",acc.country);
        if (acc.blz!=null && acc.blz.length()!=0)
            setParam(paramname+".blz",acc.blz);
        if (acc.number!=null && acc.number.length()!=0)
            setParam(paramname+".number",acc.number);
    }

    /** Setzen eines komplexen Job-Parameters (Geldbetrag). Einige Jobs ben�tigten Geldbetr�ge
        als Parameter. Diese m�ssten auf "normalem" Wege durch zwei Aufrufe von 
        {@link #setParam(String,String) setParam(String,String)} erzeugt werden (je einer f�r
        den Wert und die W�hrung). Durch Verwendung dieser
        Methode wird dieser Weg abgek�rzt. Es wird ein Value-Objekt �bergeben, f�r welches
        die entsprechenden zwei <code>setParam(String,String)</code>-Aufrufe automatisch
        erzeugt werden.
        @param paramname die Basis der Parameter f�r die Geldbetragsdaten (f�r "<code>btg.value</code>" und
        "<code>btg.curr</code>" w�re das also "<code>btg</code>")
        @param v ein Value-Objekt, aus welchem die zu setzenden Parameterdaten entnommen werden */
    public void setParam(String paramname,Value v)
    {
        setParam(paramname+".value",HBCIUtils.value2String(v.value));
        if (v.curr!=null && v.curr.length()!=0)
            setParam(paramname+".curr",v.curr);
    }
    
    /** Setzen eines Job-Parameters, bei dem ein Datums als Wert erwartet wird. Diese Methode
        dient als Wrapper f�r {@link #setParam(String,String)}, um das Datum in einen korrekt
        formatierten String umzuwandeln. Das "richtige" Datumsformat ist dabei abh�ngig vom
        aktuellen Locale.
        @param paramName Name des zu setzenden Job-Parameters
        @param date Datum, welches als Wert f�r den Job-Parameter benutzt werden soll */     
    public void setParam(String paramName,Date date)
    {
        setParam(paramName,HBCIUtils.date2String(date));
    }

    /** Setzen eines Job-Parameters, bei dem ein Integer-Wert Da als Wert erwartet wird. Diese Methode
        dient nur als Wrapper f�r {@link #setParam(String,String)}.
        @param paramName Name des zu setzenden Job-Parameters
        @param i Integer-Wert, der als Wert gesetzt werden soll */     
    public void setParam(String paramName,int i)
    {
        setParam(paramName,Integer.toString(i));
    }

    /** <p>Setzen eines Job-Parameters. F�r alle Highlevel-Jobs ist in der Package-Beschreibung zum
        Package {@link org.kapott.hbci.GV} eine Auflistung aller Jobs und deren Parameter zu finden.
        F�r alle Lowlevel-Jobs kann eine Liste aller Parameter entweder mit dem Tool
        {@link org.kapott.hbci.tools.ShowLowlevelGVs ShowLowlevelGVs} oder zur Laufzeit durch Aufruf
        der Methode {@link org.kapott.hbci.manager.HBCIHandler#getLowlevelGVParameters(String)
        HBCIHandler.getLowlevelGVParameters()} ermittelt werden.</p>
        <p>Bei Verwendung dieser oder einer der anderen <code>setParam()</code>-Methoden werden zus�tzlich
        einige der Job-Restriktionen (siehe {@link #getJobRestrictions()}) analysiert. Beim Verletzen einer
        der �berpr�ften Einschr�nkungen wird eine Exception mit einer entsprechenden Meldung erzeugt.
        Diese �berpr�fung findet allerdings nur bei Highlevel-Jobs statt.</p>
        @param paramName der Name des zu setzenden Parameters.
        @param value Wert, auf den der Parameter gesetzt werden soll */
    public void setParam(String paramName,String value)
    {
        String[][] destinations=(String[][])constraints.get(paramName);
        
        if (destinations==null) {
            String msg=HBCIUtils.getLocMsg("EXCMSG_PARAM_NOTNEEDED",new String[] {paramName,getName()});
            if (!HBCIUtils.ignoreError(passport,"client.errors.ignoreWrongJobDataErrors",msg))
                throw new InvalidUserDataException(msg);
            destinations=new String[0][];
        }
        
        if (value==null || value.length()==0) {
            String msg=HBCIUtils.getLocMsg("EXCMSG_PARAM_EMPTY",new String[] {paramName,getName()});
            if (!HBCIUtils.ignoreError(passport,"client.errors.ignoreWrongJobDataErrors",msg))
                throw new InvalidUserDataException(msg);
            value="";
        }
        
        for (int i=0;i<destinations.length;i++) {
            String[] valuePair=destinations[i];
            String   lowlevelname=valuePair[0];
            setLowlevelParam(lowlevelname,value);
        }
    }
    
    public void setContinueOffset(int loop)
    {
        String offset=getContinueOffset(loop);
        setLowlevelParam(getName()+".offset",(offset!=null)?offset:"");
    }
    
    protected void setLowlevelParam(String key,String value)
    {
        HBCIUtils.log(HBCIUtils.getLocMsg("DBG_SET_LLPARAM",new String[] {key,value}),HBCIUtils.LOG_DEBUG);
        params.setProperty(key,value);
    }

    /** Gibt alle f�r diesen Job gesetzten Parameter zur�ck. In dem
        zur�ckgegebenen <code>Properties</code>-Objekt sind werden die
        Parameter als <em>Lowlevel</em>-Parameter abgelegt. Au�erdem hat
        jeder Lowlevel-Parametername zus�tzlich ein Prefix, welches den
        Lowlevel-Job angibt, f�r den der Parameter gilt (also z.B.
        <code>Ueb3.BTG.value</code>
        @return aktuelle gesetzte Lowlevel-Parameter f�r diesen Job */
    public Properties getParams()
    {
        return params;
    }

    public void setIdx(int idx)
    {
        this.idx=idx;
    }

    public String getName()
    {
        return name;
    }

    /* stellt fest, ob f�r diesen Task ein neues Auftragssegment generiert werden muss.
       Das ist in zwei F�llen der Fall: der Task wurde noch nie ausgef�hrt; oder der Task
       wurde bereits ausgef�hrt, hat aber eine "offset"-Meldung zur�ckgegeben */
    public boolean needsContinue(int loop)
    {
        boolean needs=false;

        if (executed) {
            HBCIRetVal retval=null;
            int        num=jobResult.getRetNumber();

            for (int i=0;i<num;i++) {
                retval=jobResult.getRetVal(i);
                
                if (retval.code.equals("3040") && retval.params.length!=0 && (--loop)==0) {
                    needs=true;
                    break;
                }
            }
        }
        else needs=true;
            
        return needs;
    }

    /* gibt (sofern vorhanden) den offset-Wert des letzten HBCI-R�ckgabecodes
       zur�ck */
    private String getContinueOffset(int loop)
    {
        String ret=null;
        int    num=jobResult.getRetNumber();
        
        for (int i=0;i<num;i++) {
            HBCIRetVal retval=jobResult.getRetVal(i);

            if (retval.code.equals("3040") && retval.params.length!=0 && (--loop)==0) {
                ret=retval.params[0];
                break;
            }
        }

        return ret;
    }

    /* f�llt das Objekt mit den R�ckgabedaten. Dazu wird zuerst eine Liste aller
       Segmente erstellt, die R�ckgabedaten f�r diesen Task enthalten. Anschlie�end
       werden die HBCI-R�ckgabewerte (RetSegs) im outStore gespeichert. Danach werden
       die GV-spezifischen Daten im outStore abgelegt */
    public void fillJobResult(HBCIMsgStatus status,int offset)
    {
        try {
            executed=true;
            Properties result=status.getData();

            // nachsehen, welche antwortsegmente ueberhaupt
            // zu diesem task gehoeren
            ArrayList keyHeaders=new ArrayList();
            for (Enumeration i=result.keys();i.hasMoreElements();) {
                String key=(String)(i.nextElement());
                if (key.startsWith("GVRes")&&
                    key.endsWith(".SegHead.ref")) {

                    String segref=result.getProperty(key);
                    if ((Integer.parseInt(segref))-offset==idx) {
                        keyHeaders.add(key.substring(0,key.length()-(".SegHead.ref").length()));
                    }
                }
            }

            saveBasicValues(result,idx+offset);
            saveReturnValues(status,idx+offset);

            // der contentCounter wird fuer jedes antwortsegment um 1 erhoeht
            for (int i=0;i<keyHeaders.size();i++) {
                String header=(String)keyHeaders.get(i);
                
                extractPlaintextResults(result,header,contentCounter);
                extractResults(result,header,contentCounter++);
            }
        } catch (Exception e) {
            String msg=HBCIUtils.getLocMsg("EXCMSG_CANTSTORERES",getName());
            if (!HBCIUtils.ignoreError(passport,
                                       "client.errors.ignoreJobResultStoreErrors",
                                       msg+": "+HBCIUtils.exception2String(e))) {
                throw new HBCI_Exception(msg,e);
            }
        }
    }
    
    /* wenn wenigstens ein HBCI-R�ckgabewert f�r den aktuellen GV gefunden wurde,
       so werden im outStore zus�tzlich die entsprechenden Dialog-Parameter
       gespeichert (Property @c basic.*) */
    private void saveBasicValues(Properties result,int ref)
    {
        // wenn noch keine basic-daten gespeichert sind
        if (jobResult.getDialogId()==null) {
            // Pfad des originalen MsgHead-Segmentes holen und um "orig_" ergaenzen,
            // um den Key fuer die entsprechenden Daten in das result-Property zu erhalten
            String msgheadName="orig_"+result.getProperty("1");
            
            jobResult.storeResult("basic.dialogid",result.getProperty(msgheadName+".dialogid"));
            jobResult.storeResult("basic.msgnum",result.getProperty(msgheadName+".msgnum"));
            jobResult.storeResult("basic.segnum",Integer.toString(ref));

            HBCIUtils.log(HBCIUtils.getLocMsg("INFO_BASIC_FOR_GV_SET_TO",
                                              new Object[] {getName(),
                                                            jobResult.getDialogId()+"/"+
                                                            jobResult.getMsgNum()+"/"+
                                                            jobResult.getSegNum()}),
                          HBCIUtils.LOG_DEBUG);
        }
    }

    /* speichert die HBCI-R�ckgabewerte f�r diesen GV im outStore ab. Dazu werden
       alle RetSegs durchgesehen; diejenigen, die den aktuellen GV betreffen, werden
       im @c data Property unter dem namen @c ret_i.* gespeichert. @i entspricht
       dabei dem @c retValCounter. */
    private void saveReturnValues(HBCIMsgStatus status,int sref)
    {
        HBCIRetVal[] retVals=status.segStatus.getRetVals();
        String       segref=Integer.toString(sref);
        
        for (int i=0;i<retVals.length;i++) {
            HBCIRetVal rv=retVals[i];
            
            if (rv.segref!=null && rv.segref.equals(segref)) {
                jobResult.jobStatus.addRetVal(rv);
            }
        }
        
        jobResult.globStatus=status.globStatus;
    }

    /* diese Methode wird i.d.R. durch abgeleitete GV-Klassen �berschrieben, um die
       R�ckgabedaten in einem passenden Format abzuspeichern. Diese default-Implementation
       tut nichts */
    protected void extractResults(Properties result,String header,int idx)
    {
    }

    private void extractPlaintextResults(Properties result,String header,int idx)
    {
        for (Enumeration e=result.keys();e.hasMoreElements();) {
            String key=(String)(e.nextElement());
            if (key.startsWith(header+".")) {
                jobResult.storeResult(HBCIUtils.withCounter("content",idx)+
                                      "."+
                                      key.substring(header.length()+1),result.getProperty(key));
            }
        }
    }

    /** Gibt ein Objekt mit den R�ckgabedaten f�r diesen Job zur�ck. Das zur�ckgegebene Objekt enth�lt
        erst <em>nach</em> der Ausf�hrung des Jobs g�ltige Daten.
        @return ein Objekt mit den R�ckgabedaten und Statusinformationen zu diesem Job */
    public HBCIJobResult getJobResult()
    {
        return jobResult;
    }
    
    protected HBCIPassportInternal getPassport()
    {
        return passport;
    }
    
    protected void checkAccountCRC(String frontendname)
    {
        String[][] data=(String[][])constraints.get(frontendname+".blz");
        String     lowlevelHeader=null;
        
        for (int i=0;i<data.length;i++) {
            String[] values=data[i];
            String   paramname=values[0];
            
            lowlevelHeader=paramname.substring(0,paramname.lastIndexOf(".KIK.blz"));

            String country=params.getProperty(lowlevelHeader+".KIK.country");
            String blz=params.getProperty(lowlevelHeader+".KIK.blz");
            String number=params.getProperty(lowlevelHeader+".number");
            
            String orig_blz=blz;
            String orig_number=number;

            while (true) {
                boolean crcok=new Konto(blz,number).checkCRC();

                String old_blz=blz;
                String old_number=number;

                if (!crcok) {
                    StringBuffer sb=new StringBuffer(blz+"|"+number);
                    HBCIUtils.getCallback().callback(passport,
                                                     HBCICallback.HAVE_CRC_ERROR,
                                                     HBCIUtils.getLocMsg("CALLB_HAVE_CRC_ERROR"),
                                                     HBCICallback.TYPE_TEXT,
                                                     sb);

                    int idx=sb.indexOf("|");
                    blz=sb.substring(0,idx);
                    number=sb.substring(idx+1);
                }
                
                if (blz.equals(old_blz) && number.equals(old_number))
                    break;
            }
                
            if (!blz.equals(orig_blz) || !number.equals(orig_number))
                setParam(frontendname,new Konto(country,blz,number));
        }
    }
    
    public void setMsgGen(MsgGen gen)
    {
        this.gen=gen;
    }
}
