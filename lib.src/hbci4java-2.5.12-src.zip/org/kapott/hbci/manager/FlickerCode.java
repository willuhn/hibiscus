/**********************************************************************
 * $Source$
 * $Revision$
 * $Date$
 * $Author$
 *
 * Copyright (c) by willuhn - software & services
 * All rights reserved
 *
 **********************************************************************/

package org.kapott.hbci.manager;

import org.kapott.hbci.exceptions.HBCI_Exception;
import org.kapott.hbci.exceptions.InvalidArgumentException;
import org.kapott.hbci.exceptions.InvalidUserDataException;

/**
 * Implementierung des Flicker-Codes fuer optisches ChipTAN.
 * Dies ist eine 1:1 Portierung der Javascript-Implementierung von
 * http://6xq.net/media/00/20/flickercode.html
 *
 * Erweitert um den Support fuer "Challenge HHD_UC" und das HHD1.3-Format.
 */
public class FlickerCode
{
  /**
   * Liefert den Code im Format "HHDuc-Protokoll", sodass er von einem TAN-Generator angezeigt werden kann.
   * Siehe "Belegungsrichtlinien TANve1.4  mit Erratum 1-3 final version vom 2010-11-12.pdf", Kapitel II.2
   * 
   * Die Funktion erkennt selbstaendig, in welchem Format der Code vorliegt. Unterstuetzt werden hierbei
   * folgende Formate:
   * 
   * - "HHDuc-Protokoll"         : Der Code wird unveraendert zurueckgegeben
   * - "Challenge HHD_UC"        : Der Code wird nach "HHDuc-Protokoll" konvertiert und zurueckgegeben
   * - HHD1.3-Format im Challenge: Das ist quasi eine Eigenerfindung der Sparkassen. Die haben
   *                               Flickercodes bereits vor Einfuehrung von HKTAN4 verwendet. Da
   *                               zu dem Zeitpunkt noch nicht das dedizierte Element "Challenge HHD_UC"
   *                               existierte, haben sie es direkt im Freitext des DE "5. Challenge" des
   *                               HITAN3-Segments untergebracht. Der darin enthaltene Code ist erkennbar
   *                               an den beiden Tokens "CHLGUC" und "CHLGTEXT". Der Code steht direkt
   *                               dazwischen und besitzt das "Challenge HHD_UC"-Format.
   *                               Dieser Funktion hier kann also einfach das komplette Challenge
   *                               uebergeben werden, sie erkennt den Flicker-Code darin selbst.
   * @param code der zu parsende Code.
   * @return der Code im "HHDuc-Protokoll"-Format oder NULL, wenn der Code nicht geparst werden konnte.
   */
  public static String parse(String code)
  {
    // Kein Code angegeben
    if (code == null || code.length() == 0)
      return null;

    // 1. Checken, ob er vielleicht schon im "HHDuc-Protokoll"-Format vorliegt
    try
    {
      checkHHDuc(code);
      // Keine Exception. Dann ist es bereits ein gueltiger Code.
      return code;
    }
    catch (Exception e)
    {
      // ignore
    }
    
    // 2. Checken, ob er im HHD1.3-Format im Challenge liegt
    return null;
  }
  
  /**
   * Versucht, den angegebenen Code als Flicker-Code im HHD1.3-Challenge-Format
   * zu interpretieren und extrahiert den Code, insofern er gefunden wurde.
   * @param code der zu pruefende Code.
   * @return der gefundene Code oder NULL, wenn keiner enthalten war.
   */
  public static String extractFromChallenge(String code)
  {
    if (code == null || code.length() == 0)
      return null;

    int tokenStart = code.indexOf("CHLGUC");
    int tokenEnd   = code.indexOf("CHLGTEXT");
    
    // Entweder kein Start-Token oder kein End-Token oder ungueltige Positionen
    if (tokenStart == -1 || tokenEnd == -1 || tokenStart >= tokenEnd)
      return null;
    
    // Sieht aus wie ein passender Code. Wir extrahieren den eigentlichen Code.
    // code = code.substring();
    return null;
  }

  /**
   * Prueft, ob es ein gueltiger "HHDuc-Protokoll"-Code ist.
   * @param code der zu testende Flicker-Code.
   * @throws InvalidUserDataException wenn der Code nicht im "HHDuc-Protokoll"-Format vorlag.
   */
  public static void checkHHDuc(String code) throws InvalidUserDataException
  {
    try
    {
      String test = code;
      
      /* length check: first byte */
      int len = test.length() / 2 - 1;
      test = toHex(len,2) + test.substring(2);
      
      /* luhn checksum */
      String luhndata = getPayload(code);
      int luhnsum = 0;
      for (int i=0; i<luhndata.length(); i+=2)
      {
        luhnsum += (1*Integer.parseInt(Character.toString(luhndata.charAt(i)),16)) + quersumme(2*Integer.parseInt(Character.toString(luhndata.charAt(i+1)),16));
      }
      luhnsum = (10 - (luhnsum % 10)) % 10;
      test = test.substring(0,test.length()-2) + toHex(luhnsum,1) + test.substring(test.length()-1);
      
      /* xor checksum */
      int xorsum = 0;
      for (int i=0; i< test.length()-2; i++)
      {
        xorsum ^= Integer.parseInt(Character.toString(test.charAt(i)),16);
      }
      test = test.substring(0,test.length()-1) + toHex(xorsum,1);
      if (!test.equals(code))
        throw new InvalidUserDataException("flicker code contains wrong checksums");
    }
    catch (InvalidUserDataException iae)
    {
      throw iae;
    }
    catch (Exception e)
    {
      throw new InvalidUserDataException("flicker code invalid",e);
    }
  }

  /**
   * Wandelt die Zahl in Hex um.
   * @param n die Zahl.
   * @param minLength Die Mindestlaenge. Der Hex-Code wird dann vorn
   * mit Nullen aufgefuellt.
   * @return der Hex-Code.
   */
  private static String toHex(int n,int minLength)
  {
    String s = Integer.toString(n,16).toUpperCase();
    while (s.length() < minLength)
      s = "0" + s;
    return s;
  }
  
  /**
   * Berechnet die Quersumme.
   * @param n die Zahl, deren Quersumme errechnet werden soll.
   * @return die Quersumme.
   */
  private static int quersumme(int n)
  {
    int q = 0;
    while (n != 0)
    {
      q += n % 10;
      n = (int) Math.floor(n / 10);
    }
    return q;
  }

  /**
   * Liefert den Payload.
   * @param code der Code, zum dem der Payload ermittelt werden soll.
   * @return der Payload.
   */
  private static String getPayload(String code)
  {
    int i = 0;
    String payload = "";
    int len = Integer.parseInt(code.substring(0,2),16);
    i += 2;
    while (i < code.length()-2)
    {
      /* skip bcd identifier */
      i += 1;
      /* parse length */
      len = Integer.parseInt(code.substring(i,i+1),16);
      i += 1;
      payload += code.substring(i,i+len*2);
      i += len*2;
    }
    return payload;
  }
}



/**********************************************************************
 * $Log$
 **********************************************************************/