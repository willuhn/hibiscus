/**********************************************************************
 * $Source$
 * $Revision$
 * $Date$
 * $Author$
 *
 * Copyright (c) by willuhn - software & services
 * All rights reserved
 *
 **********************************************************************/

package org.kapott.hbci.manager;

import org.kapott.hbci.exceptions.InvalidUserDataException;

/**
 * Implementierung des Flicker-Codes fuer optisches ChipTAN.
 * Dies ist eine 1:1 Portierung der Javascript-Implementierung von
 * http://6xq.net/media/00/20/flickercode.html
 *
 * Erweitert um den Support fuer "Challenge HHD_UC" und das HHD1.3-Format.
 */
public class FlickerCode
{
  /**
   * Der Start-Token, an dem wir erkennen, ob das HHDuc direkt im Freitext-Challenge steht 
   */
  private final static String HHD13_TOKEN_START = "CHLGUC";
  
  /**
   * Der End-Token, an dem wir erkennen, ob das HHDuc direkt im Freitext-Challenge steht
   */
  private final static String HHD13_TOKEN_END = "CHLGTEXT";
  
  /**
   * Liefert den Code im Format "HHDuc-Protokoll", sodass er von einem TAN-Generator angezeigt werden kann.
   * Siehe "Belegungsrichtlinien TANve1.4  mit Erratum 1-3 final version vom 2010-11-12.pdf", Kapitel II.2
   * 
   * Die Funktion erkennt selbstaendig, in welchem Format der Code vorliegt. Unterstuetzt werden hierbei
   * folgende Formate:
   * 
   * - "HHDuc-Protokoll"         : Der Code wird unveraendert zurueckgegeben
   * - "Challenge HHD_UC"        : Der Code wird nach "HHDuc-Protokoll" konvertiert und zurueckgegeben
   * - HHD1.3-Format im Challenge: Das ist quasi eine Eigenerfindung der Sparkassen. Die haben
   *                               Flickercodes bereits vor Einfuehrung von HKTAN4 verwendet. Da
   *                               zu dem Zeitpunkt noch nicht das dedizierte Element "Challenge HHD_UC"
   *                               existierte, haben sie es direkt im Freitext des DE "5. Challenge" des
   *                               HITAN3-Segments untergebracht. Der darin enthaltene Code ist erkennbar
   *                               an den beiden Tokens "CHLGUC" und "CHLGTEXT". Der Code steht direkt
   *                               dazwischen und besitzt das "Challenge HHD_UC"-Format.
   *                               Dieser Funktion hier kann also einfach das komplette Challenge
   *                               uebergeben werden, sie erkennt den Flicker-Code darin selbst.
   * @param code der zu parsende Code.
   * @return der Code im "HHDuc-Protokoll"-Format oder NULL, wenn der Code nicht geparst werden konnte.
   */
  public static String parse(String code)
  {
    // Kein Code angegeben
    if (code == null || code.length() == 0)
      return null;

    // 1. Checken, ob er vielleicht schon im "HHDuc-Protokoll"-Format vorliegt
    try
    {
      HBCIUtils.log("flickercode: trying to parse as HHDuc-Protokoll",HBCIUtils.LOG_DEBUG2);
      checkHHDuc(code);
      // Prima. Das ist bereits ein gueltiger Code.
      HBCIUtils.log("flickercode: ok, is HHDuc-Protokoll",HBCIUtils.LOG_DEBUG2);
      return code;
    }
    catch (InvalidUserDataException e)
    {
      //////////////////////////////////////////////////////////////////////////
      // 2. Checken, ob das vielleicht ein HHD13-Code direkt im Challenge-Text ist
      String s = code;
      try
      {
        HBCIUtils.log("flickercode: trying to parse as hhd13 challenge",HBCIUtils.LOG_DEBUG2);
        s = extractFromHHD13Challenge(s);
        HBCIUtils.log("flickercode: ok, was hhd13 challenge, converted to Challenge HHD_UC",HBCIUtils.LOG_DEBUG2);
      }
      catch (InvalidUserDataException e2)
      {
        // Ne, isser nicht. Nicht weiter schlimm. Vielleicht ist es ja direkt ein Challenge HHD_UC nach hhd1.4
        HBCIUtils.log("flickercode: no hhd13 challenge",HBCIUtils.LOG_DEBUG2);
      }
      //
      //////////////////////////////////////////////////////////////////////////

      //////////////////////////////////////////////////////////////////////////
      // 3. Checken, ob wir ihn als "Challenge HHD_UC" lesen koennen
      try
      {
        HBCIUtils.log("flickercode: trying to parse as Challenge HHD_UC",HBCIUtils.LOG_DEBUG2);
        CodeChallenge cc = parseChallenge(s);
        HBCIUtils.log("flickercode: ok, is Challenge HHD_UC",HBCIUtils.LOG_DEBUG2);
        
        // Sieht gar nicht schlecht aus. Mal schauen, ob die
        // Umwandlung in "HHDuc-Protokoll" auch noch klappt.
        HBCIUtils.log("flickercode: trying to convert to HHDuc-Protokoll",HBCIUtils.LOG_DEBUG2);
        s = toHHDuc(cc);
        
        // Konvertierten Code noch checken
        checkHHDuc(s);
        HBCIUtils.log("flickercode: ok, is HHDuc-Protokoll",HBCIUtils.LOG_DEBUG2);
        
        // Sieht alles gut aus. Der scheint in Ordnung zu sein.
        return s;
      }
      catch (InvalidUserDataException e2)
      {
        HBCIUtils.log("flickercode: unable to parse: " + HBCIUtils.exception2String(e2),HBCIUtils.LOG_DEBUG2);
        return null;
      }
      //
      //////////////////////////////////////////////////////////////////////////
    }
  }    
  
  /**
   * Versucht, den angegebenen Code als Flicker-Code im HHD1.3-Challenge-Format
   * zu interpretieren und extrahiert den Code, insofern er gefunden wurde.
   * @param code der zu pruefende Code.
   * @return der gefundene Code.
   * @throws InvalidUserDataException wenn kein gueltiger Code enthalten war.
   */
  public static String extractFromHHD13Challenge(String code)throws InvalidUserDataException
  {
    if (code == null || code.length() == 0)
      throw new InvalidUserDataException("flicker code empty");

    int tokenStart = code.indexOf(HHD13_TOKEN_START);
    int tokenEnd   = code.indexOf(HHD13_TOKEN_END);
    int offset     = HHD13_TOKEN_START.length(); // Wir wollen ja das ENDE des Tokens
    
    // Entweder kein Start-Token oder kein End-Token oder ungueltige Positionen
    if (tokenStart == -1 || tokenEnd == -1 || tokenStart+offset >= tokenEnd)
      throw new InvalidUserDataException("flicker code contains no valid hhd13 tokens");
    
    // Sieht aus wie ein passender Code. Wir extrahieren den eigentlichen Code.
    code = code.substring(tokenStart+offset,tokenEnd).trim(); // "trim()", weil da manchmal noch Leerzeichen davor und dahinter stehen
    if (code.length() == 0)
      throw new InvalidUserDataException("invalid hhd1.3 flicker code");

    // Scheint korrekt geparst worden zu sein.
    
    // TODO: Ich habe keine Ahnung, ob das dann wirklich ein Code im "Challenge HHD_UC"-Format ist
    return code;
  }
  
  /**
   * Parst den String aus dem "Challenge HHD_UC"-Format.
   * @param code der Code im "Challenge HHD_UC"-Format.
   * @return der geparste Code.
   * @throws InvalidUserDataException wenn der Code nicht lesbar war
   */
  public static CodeChallenge parseChallenge(String code) throws InvalidUserDataException
  {
    if (code == null || code.length() == 0)
      throw new InvalidUserDataException("code cannot be null");
    try
    {
      String backup = code;
      CodeChallenge hh = new CodeChallenge();
      
      // 1. LC ermitteln. Banales ASCII
      {
        // TODO: kann auch 2 Zeichen lang sein, wenn HHD_UD 1.4 verwendet wird aber
        // ein chipTAN-Geraet nach 1.3.2, kann es auch 2 Zeichen lang sein.
        // Siehe "Belegungsrichtlinien TANve1.4  mit Erratum 1-3 final version vom 2010-11-12.pdf", II.2
        // WTF?? Woran soll ich das denn unterscheiden?
        int len = 3;
        String lc = code.substring(0,len);
        hh.lc = Integer.parseInt(lc);
        
        // und abschneiden
        code = code.substring(len);
      }
      
      // 2. LS ermitteln. Binaer-Zahl im Hex-Format. Pervers.
      {
        String lsHex = code.substring(0,2);
        int ls = Integer.parseInt(lsHex,16); // LS ist Hexadezimal angegeben
        
        // und abschneiden
        code = code.substring(2);
        
        String lsBin = toBinary(ls);                    // in Binaer-Schreibweise wandeln
        hh.ls = Integer.parseInt(lsBin.substring(3),2); // Die kleinsten 5 Bits ist die Laenge des Startcodes. Wer kennt einen Weg mit Bit-Schieberei, aber ohne for-Schleife? ;)
        hh.haveControlByte = (ls & (1 << 7)) != 0;      // wenn das groesste Bit gesetzt ist, folgt ein Controlbyte
      }
      
      // 3. Control-Byte ermitteln, ebenfalls binaer im Hex-Format
      if (hh.haveControlByte)
      {
        String controlByteHex = code.substring(0,2);
        hh.controlByte = Integer.parseInt(controlByteHex,16);
        
        // und abschneiden
        code = code.substring(2);

        if ((hh.controlByte & (1 << 7)) != 0)           // das groesste Bit gibt an, ob NOCH ein Controlbyte folgt
        {
          // Ich habe keine Ahnung, was ich damit machen soll. Und vor allem,
          // wieviele solcher Controlbytes noch kommen koennen. Und wo dann
          // die zugehoerigen Nutzdaten stehen. Oder gehts da echt nur um Laender- und Versionskennungen?
          HBCIUtils.log("have more than 1 controlbyte, dont know, how to handle this. code: " + backup,HBCIUtils.LOG_DEBUG);
        }
      }
      
      // 4. Startcode abschneiden
      {
        hh.startCode = code.substring(0,hh.ls);

        // und abschneiden
        code = code.substring(hh.ls);
      }

      // 5. LDE/DE 1-3
      {
        // LDE1/DE1
        hh.lde1 = Integer.parseInt(code.substring(0,2));
        code = code.substring(2); // und abschneiden
        
        hh.de1 = code.substring(0,hh.lde1);
        code = code.substring(hh.lde1);  // und abschneiden

        // LDE2/DE2
        if (code.length() > 0)
        {
          hh.lde2 = Integer.parseInt(code.substring(0,2));
          code = code.substring(2); // und abschneiden
          
          hh.de2 = code.substring(0,hh.lde2);
          code = code.substring(hh.lde2);  // und abschneiden
        }
        
        // LDE3/DE3
        if (code.length() > 0)
        {
          hh.lde3 = Integer.parseInt(code.substring(0,2));
          code = code.substring(2); // und abschneiden
          
          hh.de3 = code.substring(0,hh.lde3);
          code = code.substring(hh.lde3);  // und abschneiden
        }
      }
      
      return hh;
    }
    catch (InvalidUserDataException iae)
    {
      throw iae;
    }
    catch (Exception e)
    {
      throw new InvalidUserDataException("challenge HHDuc invalid",e);
    }
  }

  /**
   * Wandelt den Code in das "HHDuc-Protokoll um.
   * @param code der umzuwandelnde Code.
   * @return der Code im Format "HHDuc-Protokoll".
   * @throws InvalidUserDataException
   */
  public static String toHHDuc(CodeChallenge code) throws InvalidUserDataException
  {
    String s = null;
  
    // TODO hier fehlt noch der Teil dazwischen
    if (true)
      throw new InvalidUserDataException("not implemented");
    
    // LC Laenge des Codes vorn dran schreiben
    int len = s.length() / 2;
    s = toHex(len,2) + s;
    return s;
  }
  

  /**
   * Prueft, ob es ein gueltiger "HHDuc-Protokoll"-Code ist.
   * @param code der zu testende Flicker-Code.
   * @throws InvalidUserDataException wenn der Code nicht im "HHDuc-Protokoll"-Format vorlag.
   */
  public static void checkHHDuc(String code) throws InvalidUserDataException
  {
    try
    {
      String test = code;
      
      /* length check: first byte */
      int len = test.length() / 2 - 1;
      test = toHex(len,2) + test.substring(2);
      
      /* luhn checksum */
      int luhnsum = getLuhnChecksum(code);

      // 1) letzten beiden Zeichen abschneiden
      // 2) einstellige Luhn-Pruefziffer anhaengen
      // 3) XOR-Pruefsumme wieder dranhaengen
      // Hier wird also nur die Luhn-Pruefziffer (das vorletzte Zeichen) gegen die berechnete ersetzt
      //     1)                                  2)                 3)                               
      test = test.substring(0,test.length()-2) + toHex(luhnsum,1) + test.substring(test.length()-1);
      
      /* xor checksum */
      int xorsum = 0;
      for (int i=0; i< test.length()-2; i++)
      {
        xorsum ^= Integer.parseInt(Character.toString(test.charAt(i)),16);
      }
      test = test.substring(0,test.length()-1) + toHex(xorsum,1);
      if (!test.equals(code))
        throw new InvalidUserDataException("flicker code contains wrong checksums");
    }
    catch (InvalidUserDataException iae)
    {
      throw iae;
    }
    catch (Exception e)
    {
      throw new InvalidUserDataException("flicker code invalid",e);
    }
  }

  /**
   * Wandelt die Zahl in Hex um.
   * @param n die Zahl.
   * @param minLength Die Mindestlaenge. Der Hex-Code wird dann vorn
   * mit Nullen aufgefuellt.
   * @return der Hex-Code.
   */
  private static String toHex(int n,int minLength)
  {
    String s = Integer.toString(n,16).toUpperCase();
    while (s.length() < minLength)
      s = "0" + s;
    return s;
  }
  
  /**
   * Berechnet die Quersumme.
   * @param n die Zahl, deren Quersumme errechnet werden soll.
   * @return die Quersumme.
   */
  private static int quersumme(int n)
  {
    int q = 0;
    while (n != 0)
    {
      q += n % 10;
      n = (int) Math.floor(n / 10);
    }
    return q;
  }

  /**
   * Liefert die Luhn-Pruefziffer.
   * @param code der Code, zum dem die Pruefziffer ermittelt werden soll.
   * @return die Pruefziffer.
   */
  public static int getLuhnChecksum(String code)
  {
    // Schritt 1: Payload ermitteln.
    String payload = "";
    int len = Integer.parseInt(code.substring(0,2),16);
    int i = 2;
    while (i < code.length()-2)
    {
      /* skip bcd identifier */
      i += 1;
      /* parse length */
      len = Integer.parseInt(code.substring(i,i+1),16);
      i += 1;
      payload += code.substring(i,i+len*2);
      i += len*2;
    }
    
    int luhnsum = 0;
    i = 0;
    for (i=0; i<payload.length(); i+=2)
    {
      luhnsum += (1*Integer.parseInt(Character.toString(payload.charAt(i)),16)) + quersumme(2*Integer.parseInt(Character.toString(payload.charAt(i+1)),16));
    }
    luhnsum = (10 - (luhnsum % 10)) % 10;
    return luhnsum;
  }

  /**
   * Wandelt die Zahl in Binaer-Darstellung mit fuehrenden Nullen um.
   * @param num die Zahl.
   * @return die Binaer-Darstellung mit fuehrenden Nullen.
   */
  public static String toBinary(int num)
  {
    StringBuffer sb = new StringBuffer();

    for (int i=7;i>=0; --i)
    {
      sb.append(((num >> i) & 1) != 0 ? "1" : 0);
    }    
    return sb.toString();
  }
  
  /**
   * Bean fuer die Eigenschaften des geparsten Challenge HHD_UC.
   */
  public static class CodeChallenge
  {
    /**
     * Laenge des gesamten Codes.
     */
    public int lc           = 0;
    
    /**
     * Laenge des Startcodes.
     */
    public int ls           = 0;

    /**
     * Controlbyte vorhanden?
     */
    public boolean haveControlByte = false;
    
    /**
     * Das Controlbyte
     */
    public int controlByte  = 0;
    
    /**
     * Der Startcode.
     */
    public String startCode = null;
    
    /**
     * Laenge von DE1
     */
    public int lde1         = 0;
    
    /**
     * DE1
     */
    public String de1       = null;
    
    /**
     * Laenge von DE2
     */
    public int lde2         = 0;
    
    /**
     * DE2
     */
    public String de2       = null;
    
    /**
     * Laenge von DE3
     */
    public int lde3         = 0;
    
    /**
     * DE3
     */
    public String de3       = null;
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
      StringBuffer sb = new StringBuffer();
      sb.append("LC: " + this.lc + "\n");
      sb.append("LS: " + this.ls + "\n");
      sb.append("have control byte: " + this.haveControlByte + "\n");
      sb.append("control byte: " + this.controlByte + "\n");
      sb.append("Start-Code: " + this.startCode + "\n");
      sb.append("LDE1: " + this.lde1 + "\n");
      sb.append("DE1 : " + this.de1 + "\n");
      sb.append("LDE2: " + this.lde2 + "\n");
      sb.append("DE2 : " + this.de2 + "\n");
      sb.append("LDE3: " + this.lde3 + "\n");
      sb.append("DE3 : " + this.de3 + "\n");
      return sb.toString();
    }
  }
  
}



/**********************************************************************
 * $Log$
 **********************************************************************/