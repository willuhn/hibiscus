
/*  $Id: DDVCardService0.java,v 1.5 2008/06/05 15:28:33 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2008  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.smartcardio;

import javax.smartcardio.CommandAPDU;
import javax.smartcardio.ResponseAPDU;

/**
 * DDV-Cardservice fuer Karten des Types 0, basierend auf dem OCF-Code aus HBCI4Java 2.5.8.
 */
public class DDVCardService0 extends DDVCardService
{
    /**
     * @see org.kapott.hbci.smartcardio.DDVCardService#readKeyData()
     */
    public DDVKeyData[] readKeyData()
    {
        DDVKeyData[] ret=new DDVKeyData[2];
        
        selectSubFile(0x0013);
        byte[] rawData=readRecord(0);
        ret[0]=new DDVKeyData();
        ret[0].num=rawData[0];
        ret[0].version=rawData[4];
        ret[0].len=rawData[1];
        ret[0].alg=rawData[2];

        selectSubFile(0x0014);
        rawData=readRecord(0);
        ret[1]=new DDVKeyData();
        ret[1].num=rawData[0];
        ret[1].version=rawData[3];
        ret[1].len=rawData[1];
        ret[1].alg=rawData[2];
        
        return ret;
    }
    
    /**
     * @see org.kapott.hbci.smartcardio.DDVCardService#calculateSignature(byte[])
     */
    protected byte[] calculateSignature(byte[] data_l)
    {
        byte[] ret=null;
        
        putData(0x0100,data_l);
        
        try {
            allocateCardChannel();
            CommandAPDU command=new CommandAPDU(
                SECCOS_CLA_SM_PROPR, SECCOS_INS_READ_RECORD,
                (byte)0x01, (byte)((0x1B<<3)|0x04),
                0);
            
            ResponseAPDU response=getCardChannel().transmit(command);
            if (response.getSW()!=(byte)0x90 && response.getSW()!=(byte)0x61) {
            	throw new RuntimeException("calculateSignature: "+response);
            }
            
            ret=new byte[8];
            System.arraycopy(response.getData(),12,ret,0,8);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            releaseCardChannel();
        }
        
        return ret;
    }
}
