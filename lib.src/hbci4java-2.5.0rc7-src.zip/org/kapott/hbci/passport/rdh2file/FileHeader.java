
/* $Id: FileHeader.java,v 1.1.2.1 2006/03/19 21:48:16 kleiner Exp $

   This file is part of org.kapott.hbci.passport
   Copyright (C) 2006  Stefan Palme

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.passport.rdh2file;


public class FileHeader
    extends TLV
{
    private int    version;
    private byte[] salt;
    private long   nof_iterations;
    
    public FileHeader(TLV tlv)
    {
        super(tlv);
        byte[] data=this.getData();
        
        this.version=(data[1]<<8) | (data[0]&0xFF);
        this.nof_iterations=((data[25]&0xFFL)<<24) | ((data[24]&0xFFL)<<16) | 
                             ((data[23]&0xFFL)<<8) | ((data[22]&0xFFL)<<0);
        
        this.salt=new byte[20];
        System.arraycopy(data,2, this.salt,0, 20);
    }
    
    public byte[] getSalt()
    {
        return this.salt;
    }
    
    public long getNofIterations()
    {
        return this.nof_iterations;
    }
    
    public String toString()
    {
        StringBuffer ret=new StringBuffer();
        ret.append("diskhead: version="+this.version);
        ret.append("; nof_iterations="+this.nof_iterations);
        ret.append("; salt=");
        
        for (int i=0;i<this.salt.length;i++) {
            int x=salt[i]&0xFF;
            ret.append(Integer.toString(x,16)+" ");
        }
        
        return ret.toString();
    }
}