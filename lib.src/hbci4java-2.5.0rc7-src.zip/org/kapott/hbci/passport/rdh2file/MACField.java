
/* $Id: MACField.java,v 1.1.2.1 2006/03/19 21:48:16 kleiner Exp $

   This file is part of org.kapott.hbci.passport
   Copyright (C) 2006  Stefan Palme

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.passport.rdh2file;


public class MACField
    extends TLV
{
    private byte[] mac;
    
    public MACField(TLV tlv)
    {
        super(tlv);
        this.mac=this.getData();
    }
    
    public String toString()
    {
        StringBuffer ret=new StringBuffer();
        ret.append("macfield: mac=");
        for (int i=0;i<mac.length;i++) {
            int x=mac[i]&0xFF;
            ret.append(Integer.toString(x,16)+" ");
        }
        
        return ret.toString();
    }
}