
/* $Id: TLV.java,v 1.1.2.1 2006/03/19 21:48:16 kleiner Exp $

   This file is part of org.kapott.hbci.passport
   Copyright (C) 2006  Stefan Palme

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.passport.rdh2file;

public class TLV
{
    private int    tag;
    private int    len;
    private byte[] data;
    private byte[] rawdata;
    
    public TLV(byte[] buffer,int offset)
    {
        this.tag=((buffer[offset+0])<<8) | (buffer[offset+1]&0xFF);
        this.len=((buffer[offset+3])<<8) | (buffer[offset+2]&0xFF);
        
        this.data=new byte[this.len];
        System.arraycopy(buffer,offset+4, this.data,0, this.len);
        
        this.rawdata=new byte[4+this.len];
        System.arraycopy(buffer,offset, this.rawdata,0, 4+this.len);
    }
    
    protected TLV(TLV tlv)
    {
        this.tag=(int)(tlv.getTag()&0xFFFFL);
        this.len=tlv.getLength();
        this.data=tlv.getData();
        this.rawdata=tlv.getRawData();
    }
    
    public long getTag()
    {
        return this.tag&0xFFFFL;
    }
    
    public int getLength()
    {
        return this.len;
    }
    
    public byte[] getData()
    {
        return this.data;
    }
    
    public byte[] getRawData()
    {
        return this.rawdata;
    }
}