
/*  $Id: HBCIExecThreadedStatus.java,v 1.1.2.2 2006/02/22 07:35:21 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2004  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.status;

import java.util.Hashtable;

// TODO: doku fehlt
public class HBCIExecThreadedStatus 
{
    private Hashtable      callbackData;
    private HBCIExecStatus execStatus;
    
    public void setCallbackData(Hashtable callbackData)
    {
        this.callbackData=callbackData;
    }
    
    public Hashtable getCallbackData()
    {
        return this.callbackData;
    }

    public void setExecStatus(HBCIExecStatus status)
    {
        this.execStatus=status;
    }
    
    public HBCIExecStatus getExecStatus()
    {
        return this.execStatus;
    }
    
    public boolean isFinished()
    {
        return execStatus!=null;
    }
    
    public boolean isCallback()
    {
        return callbackData!=null;
    }
    
    public String toString()
    {
        StringBuffer ret=new StringBuffer();
        String       linesep=System.getProperty("line.separator");
        
        ret.append("isCallback: "+isCallback()+linesep);
        if (isCallback()) {
            Hashtable callbackData=getCallbackData();
            ret.append("  method: "+callbackData.get("method")+linesep);
            ret.append("  reason: "+callbackData.get("reason")+linesep);
            ret.append("  msg: "+callbackData.get("msg")+linesep);
        }
        ret.append("isFinished: "+isFinished()+linesep);
        if (isFinished()) {
            ret.append(getExecStatus().toString());
        }
        
        return ret.toString();
    }
}
