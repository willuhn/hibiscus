
/*  $Id: RSACardService.java,v 1.1.2.1 2006/01/05 17:01:10 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2004  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.ocf;


public class RSACardService 
    extends HBCICardService
{
    protected String getAID()
    {
        return "#d27600007448420110";
    }
    
    private void selectApplication()
    {
        selectFileByAID(new byte[] {(byte)0xd2, (byte)0x76, (byte)0x00, (byte)0x00, (byte)0x74, (byte)0x48, (byte)0x42, (byte)0x01, (byte)0x10});
    }
    
    public String getCardId()
    {
        // TODO: die card id aus dem GD0 EF lesen
        StringBuffer ret=new StringBuffer();
        try {
            selectRoot();
            selectSubFile(0x2f02);
            byte[] data=readBinary();
            if (data!=null) {
                for (int i=6;i<11;i++) {
                    ret.append((char)(((data[i]>>4)&0x0F)+0x30));
                    ret.append((char)((data[i]&0x0F)+0x30));
                }
            }
        } finally {
            selectApplication();
        }
        return ret.toString();
    }
    
    public RSABankData readBankData(int idx)
    {
        RSABankData bankData=new RSABankData();
        
        try {
            selectSubFile(HBCI_RSA_EF_BNK);
            byte[] data=readRecord(idx);
            if (data!=null) {
                bankData.country=new String(data,0,3,"ISO-8859-1").trim();
                bankData.blz=new String(data,3,30,"ISO-8859-1").trim();
                bankData.userid=new String(data,33,30,"ISO-8859-1").trim();
                bankData.host=new String(data,64,28,"ISO-8859-1").trim();
                bankData.bankId=new String(data,94,30,"ISO-8859-1").trim();
                bankData.systemId=new String(data,124,30,"ISO-8859-1").trim();
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        
        return bankData;
    }
    
    public void updateBankData(int idx,RSABankData bankData) 
    {
        selectSubFile(HBCI_RSA_EF_BNK);
        byte[] data=new byte[154];
        if (data!=null) {
            System.arraycopy(expand(bankData.country,3),0, data,0, 3);
            System.arraycopy(expand(bankData.blz,30),0, data,3, 30);
            System.arraycopy(expand(bankData.userid,30),0, data,33, 30);
            System.arraycopy(expand(bankData.host,28),0, data,64, 28);
            System.arraycopy(expand(bankData.bankId,30),0, data,94, 30);
            System.arraycopy(expand(bankData.systemId,30),0, data,124, 30);
            
            updateRecord(idx, data);
        }
    }
}
