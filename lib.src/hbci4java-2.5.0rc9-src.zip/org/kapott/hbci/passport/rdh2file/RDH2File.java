
/* $Id: RDH2File.java,v 1.1.2.2 2006/03/27 00:11:05 kleiner Exp $

   This file is part of org.kapott.hbci.passport
   Copyright (C) 2006  Stefan Palme

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.passport.rdh2file;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.kapott.hbci.manager.HBCIKey;

public class RDH2File
{
    private List fields;
    
    public RDH2File()
    {
        this.fields=new ArrayList();
    }
    
    public void addField(TLV field)
    {
        this.fields.add(field);
    }
    
    public TLV getField(Class cl)
    {
        TLV ret=null;
        
        for (Iterator i=fields.iterator();i.hasNext();) {
            TLV tlv=(TLV)i.next();
            if (tlv.getClass().equals(cl)) {
                ret=tlv;
                break;
            }
        }
        
        return ret;
    }

    public TLV[] getFields(Class cl)
    {
        List ret=new ArrayList();
        
        for (Iterator i=fields.iterator();i.hasNext();) {
            TLV tlv=(TLV)i.next();
            if (tlv.getClass().equals(cl)) {
                ret.add(tlv);
            }
        }
        
        return (TLV[])ret.toArray(new TLV[ret.size()]);
    }

    public byte[] getHashData()
    {
        try {
            ByteArrayOutputStream os=new ByteArrayOutputStream();
            
            for (Iterator i=this.fields.iterator();i.hasNext();) {
                TLV tlv=(TLV)i.next();
                if (!tlv.getClass().equals(MACField.class)) {
                    os.write(tlv.getRawData());
                }
            }
            
            byte[] ret=os.toByteArray();
            os.close();
            return ret;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public HBCIKey getBankSigKey(HBCIAccount account)
    {
        return getBankKey(account,"S");
    }
    
    public HBCIKey getBankEncKey(HBCIAccount account)
    {
        return getBankKey(account,"V");
    }
    
    private HBCIKey getBankKey(HBCIAccount account,String keytype)
    {
        HBCIKey ret=null;
        String  blz=account.getBLZ();
        String  country=account.getCountry();
        
        TLV[] keyfields=getFields(BankKeys.class);
        for (int i=0;i<keyfields.length;i++) {
            BankKeys bankkeys=(BankKeys)keyfields[i];
            
            if (bankkeys.getCountry().equals(country) && 
                    bankkeys.getBLZ().equals(blz) &&
                    bankkeys.getKeyType().equals(keytype)) 
            {
                ret=bankkeys.getHBCIKey(blz);
                break;
            }
        }
        
        return ret;
    }
    
}