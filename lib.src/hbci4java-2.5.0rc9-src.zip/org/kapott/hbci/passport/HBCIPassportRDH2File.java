
/* $Id: HBCIPassportRDH2File.java,v 1.1.2.2 2006/03/27 00:11:05 kleiner Exp $

   This file is part of HBCI4Java
   Copyright (C) 2006  Stefan Palme

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.passport;

import java.io.File;
import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;
import java.security.Signature;
import java.util.Iterator;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.kapott.hbci.callback.HBCICallback;
import org.kapott.hbci.exceptions.HBCI_Exception;
import org.kapott.hbci.manager.HBCIKey;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.manager.HBCIUtilsInternal;
import org.kapott.hbci.passport.rdh2file.BankKeys;
import org.kapott.hbci.passport.rdh2file.DateField;
import org.kapott.hbci.passport.rdh2file.FileHeader;
import org.kapott.hbci.passport.rdh2file.HBCIAccount;
import org.kapott.hbci.passport.rdh2file.MACField;
import org.kapott.hbci.passport.rdh2file.RDH2File;
import org.kapott.hbci.passport.rdh2file.TLV;
import org.kapott.hbci.security.PBKDF2;
import org.kapott.hbci.security.Sig;
import org.kapott.hbci.security.SignatureParamSpec;

public class HBCIPassportRDH2File
    extends HBCIPassportRDH
{
    private String   passphrase;
    private RDH2File filecontent;
    private int      entryIdx;
    
    public HBCIPassportRDH2File(Object init,int dummy)
    {
        super(init,dummy);
    }

    public HBCIPassportRDH2File(Object initObject)
    {
        this(initObject,0);
        setParamHeader("client.passport.RDH2File");

        String fname=HBCIUtils.getParam(getParamHeader()+".filename");
        HBCIUtils.log(HBCIUtilsInternal.getLocMsg("INFO_PASS_LOADFILE",fname),HBCIUtils.LOG_DEBUG);
        setFileName(fname);

        boolean init=HBCIUtils.getParam(getParamHeader()+".init").equals("1");
        if (init) {
            HBCIUtils.log(HBCIUtilsInternal.getLocMsg("DBG_PASS_LOADDATE",filename),HBCIUtils.LOG_DEBUG);

            setCountry("DE");
            setFilterType("None");
            setPort(new Integer(3000));

            if (!new File(filename).canRead()) {
                HBCIUtils.log(HBCIUtilsInternal.getLocMsg("WRN_PASS_NEWFILE"),HBCIUtils.LOG_WARN);
                askForMissingData(false,true,true,false,false,true,true);
                saveChanges();
            }
            
            try {
                if (passphrase==null) {
                    StringBuffer retData=new StringBuffer();
                    HBCIUtilsInternal.getCallback().callback(this,
                                                     HBCICallback.NEED_PASSPHRASE_LOAD,
                                                     HBCIUtilsInternal.getLocMsg("CALLB_NEED_PASS"),
                                                     HBCICallback.TYPE_SECRET,
                                                     retData);
                    setPassphrase(retData.toString());
                }

                readDataFromFile(getFileName());
                this.entryIdx=0;
                
                TLV[] hbciAccounts=filecontent.getFields(HBCIAccount.class);
                if (hbciAccounts.length>1) {
                    // wenn mehrere bankverbindungen existieren, callback f�r auswahl der "richtigen"
                    StringBuffer possibilities=new StringBuffer();
                    for (int i=0;i<hbciAccounts.length;i++) {
                        HBCIAccount hbciAccount=(HBCIAccount)hbciAccounts[i];
                        if (i!=0) {
                            possibilities.append("|");
                        }
                        possibilities.append(i);
                        possibilities.append(";"+hbciAccount.getBLZ());
                        possibilities.append(";"+hbciAccount.getUserId());
                    }
                    
                    HBCIUtilsInternal.getCallback().callback(
                        this,
                        HBCICallback.NEED_SIZENTRY_SELECT,
                        "*** select one of the following entries",
                        HBCICallback.TYPE_TEXT,
                        possibilities);
                     
                    this.entryIdx=Integer.parseInt(possibilities.toString());
                }
                
                // set all passport values
                HBCIAccount hbciAccount=(HBCIAccount)(filecontent.getFields(HBCIAccount.class)[entryIdx]);
                
                setBLZ(hbciAccount.getBLZ());
                setHost(hbciAccount.getHost());
                setUserId(hbciAccount.getUserId());
                setCustomerId(hbciAccount.getCustomerId());
                setSysId(hbciAccount.getSysId());
                setSigId(new Long(hbciAccount.getSigId()));
                
                // setInstKeys()
                setInstSigKey(filecontent.getBankSigKey(hbciAccount));
                setInstEncKey(filecontent.getBankEncKey(hbciAccount));
                
                // setUserKeys()
                HBCIKey[] userkeys=hbciAccount.getUserSigKeys();
                setMyPublicSigKey(userkeys[0]);
                setMyPrivateSigKey(userkeys[1]);
                
                userkeys=hbciAccount.getUserEncKeys();
                setMyPublicEncKey(userkeys[0]);
                setMyPrivateEncKey(userkeys[1]);
                                
                if (askForMissingData(false,true,true,false,false,true,true))
                    saveChanges();
            } catch (Exception e) {
                throw new HBCI_Exception("*** error while reading passport file",e);
            }
        }
    }
    
    private void setPassphrase(String st)
    {
        this.passphrase=st;
    }
    
    private byte[] getPassphrase()
    {
        try {
            return this.passphrase.getBytes("ISO-8859-1");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }
    
    private void readDataFromFile(String fname)
    {
        try {
            // keyfile einlesen
            FileInputStream fin=new FileInputStream(fname);
            StringBuffer    sb=new StringBuffer();
            byte[]          buffer=new byte[1024];
            int             size;
            
            while ((size=fin.read(buffer))>0) {
                sb.append(new String(buffer,0,size,"ISO-8859-1"));
            }
            
            fin.close();
            byte[] data=sb.toString().getBytes("ISO-8859-1");
            System.out.println("read "+data.length+" bytes from "+getFileName());
            
            // filecontent-content
            this.filecontent=new RDH2File();
            
            // alle felder extrahieren und zu filecontent-content hinzuf�gen
            int posi=0;
            int len=data.length;
            while (posi<len) {
                TLV  tlv=new TLV(data,posi);
                long tag=tlv.getTag();
                
                if (tag==0x564eL) {
                    //   diskhead (tag=0x564e, len=26) (1..1)
                    HBCIUtils.log("found diskhead field",HBCIUtils.LOG_DEBUG2);
                    tlv=new FileHeader(tlv);
                    
                } else if (tag==0x4b56L) {
                    //   bankdata (tag=0x4b56, len=..) (0..n)
                    HBCIUtils.log("found hbciaccount field",HBCIUtils.LOG_DEBUG2);
                    tlv=new HBCIAccount(tlv);
                    
                } else if (tag==0xd653L) {
                    //   bankkeys (tag=0xd653, len=..) (0..n)
                    HBCIUtils.log("found bankkeys field",HBCIUtils.LOG_DEBUG2);
                    tlv=new BankKeys(tlv);
                    
                } else if (tag==0x5244L) {
                    //   datum (tag=0x5244, len=14) (1..1)
                    HBCIUtils.log("found date field",HBCIUtils.LOG_DEBUG2);
                    tlv=new DateField(tlv);
                    
                } else if (tag==0x444dL) {
                    //   mac (tag=0x444d, len=20) (1..1)
                    HBCIUtils.log("found mac field",HBCIUtils.LOG_DEBUG2);
                    tlv=new MACField(tlv);
                    
                } else {
                    throw new HBCI_Exception("invalid field tag found: 0x"+Long.toString(tlv.getTag(),16));
                }
                
                HBCIUtils.log(tlv.toString(),HBCIUtils.LOG_DEBUG2);
                filecontent.addField(tlv);
                posi+=4+tlv.getLength();
            }
            
            // mac �berpr�fen
            
            // key ableiten
            FileHeader  diskhead=(FileHeader)filecontent.getField(FileHeader.class);
            byte[]    derivedKey=PBKDF2.deriveKey(
                diskhead.getSalt(),
                diskhead.getNofIterations(),
                getPassphrase());
            
            // mac errechnen
            SecretKeySpec keyspec=new SecretKeySpec(derivedKey,0,20,"HmacSHA1");
            Mac mac=Mac.getInstance("HmacSHA1");
            mac.init(keyspec);
            byte[] hashdata=filecontent.getHashData();
            byte[] calculatedMac=mac.doFinal(hashdata);
            
            StringBuffer temp=new StringBuffer();
            temp.append("calculated mac: ");
            for (int i=0;i<calculatedMac.length;i++) {
                int x=calculatedMac[i]&0xFF;
                temp.append(Integer.toString(x,16)+" ");
            }
            HBCIUtils.log(temp.toString(),HBCIUtils.LOG_DEBUG2);
            
            // decrypt private user keys
            
            // calculate decryption key
            SecretKeyFactory keyfac=SecretKeyFactory.getInstance("DESede");
            DESedeKeySpec    desKeyspec=new DESedeKeySpec(derivedKey);
            SecretKey        key=keyfac.generateSecret(desKeyspec);
            
            // loop through all userkeys to decrypt them
            TLV[] accounts=filecontent.getFields(HBCIAccount.class);
            for (int i=0;i<accounts.length;i++) {
                HBCIAccount account=(HBCIAccount)accounts[i];
                List        userkeys=account.getUserKeys();
                
                for (Iterator j=userkeys.iterator();j.hasNext();) {
                    HBCIAccount.UserKeys userkey=(HBCIAccount.UserKeys)j.next();
                    userkey.decrypt(key);
                    HBCIUtils.log(userkey.toString(),HBCIUtils.LOG_DEBUG2);
                }
            }
        } catch (Exception e) {
            throw new HBCI_Exception(e);
        }
    }

    public String getProfileVersion()
    {
        return "2";
    }

    public String getSigMode()
    {
        return Sig.SIGMODE_ISO9796_2;
    }
    
    protected int getCryptDataSize()
    {
        return 256;
    }

    protected Signature getSignatureInstance()
    {
        try {
            Signature sig=Signature.getInstance("ISO9796_2","HBCIProvider");
            sig.setParameter(new SignatureParamSpec("RIPEMD160","HBCIProvider"));
            return sig;
        } catch (Exception ex) {
            throw new HBCI_Exception("*** signing of message failed",ex);
        }
    }
    
    public void saveChanges()
    {
        HBCIUtils.log("saving to rdh2file not yet implemented",HBCIUtils.LOG_ERR);
        
        /*
        try {
            File   passportfile=new File(getFileName());
            File   directory=passportfile.getAbsoluteFile().getParentFile();
            String prefix=passportfile.getName()+"_";
            File   tempfile=File.createTempFile(prefix,"",directory);
            
            saveDataToFile(tempfile.getAbsolutePath());
            
            passportfile.delete();
            tempfile.renameTo(passportfile);
        } catch (Exception e) {
            throw new HBCI_Exception("*** saving of passport file failed",e);
        }
        */
    }
    
    private void saveDataToFile(String filename)
    {
        // TODO
    }
}
