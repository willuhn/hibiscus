
/*  $Id: CheckAccountCRC.java,v 1.3.2.1 2006/06/08 12:24:56 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2004  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.tools;

import org.kapott.hbci.callback.HBCICallbackConsole;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.manager.HBCIUtilsInternal;

/** <p>Tool zum Verifizieren der G�ltigkeit von BLZ/Kontonummer.
    Alle Kontonummern in Deutschland enthalten eine Pr�fziffer, anhand
    welcher �berpr�ft werden kann, ob die Kontonummer an sich g�ltig ist.
    Mit diesem Tool kann f�r eine gegebene Bankleitzahl und Kontonummer
    deren G�ltigkeit �berpr�ft werden.</p>
    <p>In <em>HBCI4Java</em> sind noch nicht alle von den Banken verwendeten
    Pr�fzifferverfahren implementiert. Deshalb k�nnen bis jetzt nur
    die Kontonummern von einigen bestimmten Banken �berpr�ft werden. Anhand
    der Ausgabe des Programmes ist ersichtlich, ob <em>HBCI4Java</em> tats�chlich
    die Kontonummer �berpr�fen konnte und wenn ja, ob die Pr�fung erfolgreich
    verlaufen ist oder nicht.</p>
    <p>Der Aufruf erfolgt mit 
    <code>java&nbsp;-cp&nbsp;...&nbsp;org.kapott.hbci.tools.CheckAccountCRC&nbsp;&lt;blz&gt;&nbsp;&lt;kontonummer&gt;</code> */  
public class CheckAccountCRC
{
    public static void main(String[] args)
    {
        if (args.length!=2) {
            System.out.println("usage: CheckAccountCRC <blz> <accnumber>");
            System.exit(1);
        }
        
        HBCIUtils.init(null,null,new HBCICallbackConsole());
        
        String blz=args[0];
        String number=args[1];
        String data=HBCIUtilsInternal.getBLZData(blz);
        String kiname=data.substring(0,data.indexOf("|"));
        String alg=HBCIUtilsInternal.getAlgForBLZ(blz);
        
        if (kiname.length()!=0) {
            System.out.println("institute name: "+kiname+" algorithmus:"+alg);
            System.out.println("account number: "+number+": "+(HBCIUtils.checkAccountCRC(blz,number)?"OK":"not OK"));
        } else {
            System.out.println("no information about "+blz+" in database");
        }
    }
}