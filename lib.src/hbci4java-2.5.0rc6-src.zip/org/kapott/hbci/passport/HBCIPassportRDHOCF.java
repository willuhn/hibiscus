
/*  $Id: HBCIPassportRDHOCF.java,v 1.1.2.1 2006/01/05 17:01:10 kleiner Exp $

    This file is part of HBCI4Java
    Copyright (C) 2001-2004  Stefan Palme

    HBCI4Java is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    HBCI4Java is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package org.kapott.hbci.passport;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.PBEParameterSpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import opencard.core.service.CardRequest;
import opencard.core.service.SmartCard;

import org.kapott.hbci.callback.HBCICallback;
import org.kapott.hbci.datatypes.SyntaxCtr;
import org.kapott.hbci.exceptions.HBCI_Exception;
import org.kapott.hbci.exceptions.InvalidPassphraseException;
import org.kapott.hbci.manager.HBCIUtils;
import org.kapott.hbci.manager.HBCIUtilsInternal;
import org.kapott.hbci.ocf.HBCICardService;
import org.kapott.hbci.ocf.RSABankData;
import org.kapott.hbci.ocf.RSACardService;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

public class HBCIPassportRDHOCF 
    extends HBCIPassportRDHNew
{
    private int     useBio;
    private int     useSoftPin;
    private byte[]  softPin;
    private boolean pinEntered;
    private int     entryIdx;
    
    private SmartCard      smartCard;
    private RSACardService cardService;
    private String         cardId;
    
    public HBCIPassportRDHOCF(Object init,int dummy)
    {
        super(init,dummy);
        setParamHeader("client.passport.RDHOCF");
    }

    public HBCIPassportRDHOCF(Object initObject)
    {
        this(initObject,0);
        
        // set parameters for initializing card
        setUseBio(Integer.parseInt(HBCIUtils.getParam(getParamHeader()+".usebio","0")));
        setUseSoftPin(Integer.parseInt(HBCIUtils.getParam(getParamHeader()+".softpin","1")));
        setSoftPin(new byte[0]);
        setPINEntered(false);
        setEntryIdx(Integer.parseInt(HBCIUtils.getParam(getParamHeader()+".entryidx","1")));

        // init card
        HBCIUtils.log("initializing OCF",HBCIUtils.LOG_DEBUG);
        try {
            HBCIUtilsInternal.getCallback().callback(this,
                                             HBCICallback.NEED_CHIPCARD,
                                             HBCIUtilsInternal.getLocMsg("CALLB_NEED_CHIPCARD"),
                                             HBCICallback.TYPE_NONE,
                                             null);
            initCT();
        } catch (Exception e) {
            try {
                closeCT();
            } catch (Exception e2) {
                HBCIUtils.log(e2);
            }

            throw new HBCI_Exception(HBCIUtilsInternal.getLocMsg("EXCMSG_CTERR"),e);
        } finally {
            HBCIUtilsInternal.getCallback().callback(this,
                                             HBCICallback.HAVE_CHIPCARD,
                                             "",
                                             HBCICallback.TYPE_NONE,
                                             null);
        }
        
        // init basic bank data
        try {
            setPort(new Integer(3000));
            setFilterType("None");
            
            checkPIN();
            ctReadBankData();
            ctReadKeyData();
        } catch (Exception e) {
            try {
                closeCT();
            } catch (Exception e2) {
                HBCIUtils.log(e2);
            }

            throw new HBCI_Exception(HBCIUtilsInternal.getLocMsg("EXCMSG_PASSPORT_INSTDATAERR"),e);
        }

        String path=HBCIUtils.getParam(getParamHeader()+".path","./");
        setFileName(HBCIUtilsInternal.withCounter(path+getCardId(),getEntryIdx()-1));

        FileInputStream f=null;
        try {
            HBCIUtils.log(HBCIUtilsInternal.getLocMsg("INFO_PASS_LOADFILE",getFileName()),HBCIUtils.LOG_DEBUG);
            f=new FileInputStream(filename);
        } catch (Exception e) {
            HBCIUtils.log(HBCIUtilsInternal.getLocMsg("EXCMSG_PASSPORT_READERR"),HBCIUtils.LOG_WARN);
        }

        if (f!=null) {
            try {
                DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
                dbf.setValidating(false);
                DocumentBuilder db=dbf.newDocumentBuilder();
                Element root=null;
                
                int retries=Integer.parseInt(HBCIUtils.getParam("client.retries.passphrase","3"));
                
                while (true) {          // loop for entering the correct passphrase
                    if (passportKey==null)
                        passportKey=calculatePassportKey(FOR_LOAD);
                    
                    PBEParameterSpec paramspec=new PBEParameterSpec(CIPHER_SALT,CIPHER_ITERATIONS);
                    Cipher cipher=Cipher.getInstance("PBEWithMD5AndDES");
                    cipher.init(Cipher.DECRYPT_MODE,passportKey,paramspec);
                    
                    root=null;
                    CipherInputStream ci=null;
                    
                    try {
                        ci=new CipherInputStream(new FileInputStream(getFileName()),cipher);
                        root=db.parse(ci).getDocumentElement();
                    } catch (SAXException e) {
                        passportKey=null;
                        
                        retries--;
                        if (retries<=0)
                            throw new InvalidPassphraseException(e);
                    } finally {
                        if (ci!=null)
                            ci.close();
                    }
                    
                    if (root!=null)
                        break;
                }
                
                setPort(new Integer(getElementValue(root,"port")));
                setCustomerId(getElementValue(root,"customerid"));
                setHBCIVersion(getElementValue(root,"hbciversion"));
                setBPD(getElementProps(root,"bpd"));
                setUPD(getElementProps(root,"upd"));

                // TODO: das jeweils nur machen, wenn die daten nicht auf der
                // TODO: chipkarte gespeichert werden
                /*
                setCountry(getElementValue(root,"country"));
                setBLZ(getElementValue(root,"blz"));
                setHost(getElementValue(root,"host"));
                setUserId(getElementValue(root,"userid"));
                setSysId(getElementValue(root,"sysid"));
                setSigId(new Long(getElementValue(root,"sigid")));
                
                setInstSigKey(getElementKey(root,"inst","S","public"));
                setInstEncKey(getElementKey(root,"inst","V","public"));
                setMyPublicSigKey(getElementKey(root,"user","S","public"));
                setMyPrivateSigKey(getElementKey(root,"user","S","private"));
                setMyPublicEncKey(getElementKey(root,"user","V","public"));
                setMyPrivateEncKey(getElementKey(root,"user","V","private"));
                */
            } catch (Exception e) {
                throw new HBCI_Exception("*** error while reading passport file",e);
            }
        }
        
        if (askForMissingData(true,true,true,true,false,true,true))
            saveChanges();
    }
    
    public void saveChanges()
    {
        try {
            checkPIN();
            ctSaveChanges();

            if (passportKey==null)
                passportKey=calculatePassportKey(FOR_SAVE);

            PBEParameterSpec paramspec=new PBEParameterSpec(CIPHER_SALT,CIPHER_ITERATIONS);
            Cipher cipher=Cipher.getInstance("PBEWithMD5AndDES");
            cipher.init(Cipher.ENCRYPT_MODE,passportKey,paramspec);

            DocumentBuilderFactory fac=DocumentBuilderFactory.newInstance();
            fac.setValidating(false);
            DocumentBuilder db=fac.newDocumentBuilder();
            
            Document doc=db.newDocument();
            Element root=doc.createElement("HBCIPassportRDHOCF");
            
            createElement(doc,root,"port",getPort().toString());
            createElement(doc,root,"customerid",getCustomerId());
            createElement(doc,root,"hbciversion",getHBCIVersion());
            createPropsElement(doc,root,"bpd",getBPD());
            createPropsElement(doc,root,"upd",getUPD());
            
            // TODO: das nur abspeichern, wenn es nicht mit auf der chipkarte steht
            /*
            createElement(doc,root,"country",getCountry());
            createElement(doc,root,"blz",getBLZ());
            createElement(doc,root,"host",getHost());
            createElement(doc,root,"userid",getUserId());
            createElement(doc,root,"sysid",getSysId());
            createElement(doc,root,"sigid",getSigId().toString());
            
            createKeyElement(doc,root,"inst","S","public",getInstSigKey());
            createKeyElement(doc,root,"inst","V","public",getInstEncKey());
            createKeyElement(doc,root,"user","S","public",getMyPublicSigKey());
            createKeyElement(doc,root,"user","S","private",getMyPrivateSigKey());
            createKeyElement(doc,root,"user","V","public",getMyPublicEncKey());
            createKeyElement(doc,root,"user","V","private",getMyPrivateEncKey());
            */
            
            TransformerFactory tfac=TransformerFactory.newInstance();
            Transformer tform=tfac.newTransformer();
            
            tform.setOutputProperty(OutputKeys.METHOD,"xml");
            tform.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION,"no");
            tform.setOutputProperty(OutputKeys.ENCODING,"ISO-8859-1");
            tform.setOutputProperty(OutputKeys.INDENT,"yes");
            
            File passportfile=new File(getFileName());
            File directory=passportfile.getAbsoluteFile().getParentFile();
            String prefix=passportfile.getName()+"_";
            File tempfile=File.createTempFile(prefix,"",directory);
            
            CipherOutputStream co=new CipherOutputStream(new FileOutputStream(tempfile),cipher);
            tform.transform(new DOMSource(root),new StreamResult(co));
            
            co.close();
            passportfile.delete();
            tempfile.renameTo(passportfile);
        } catch (Exception e) {
            throw new HBCI_Exception("*** saving of passport failed",e);
        }
    }
    
    public byte[] sign(byte[] data)
    {
        // TODO
        throw new RuntimeException("not yet implemented");
    }
    
    public boolean verify(byte[] data,byte[] sig)
    {
        // TODO
        throw new RuntimeException("not yet implemented");
    }

    public byte[][] encrypt(byte[] plainMsg)
    {
        // TODO
        throw new RuntimeException("not yet implemented");
    }
    
    public byte[] decrypt(byte[] cryptedKey,byte[] cryptedMsg)
    {
        // TODO
        throw new RuntimeException("not yet implemented");
    }
    
    public void close()
    {
        super.close();
        closeCT();
    }
    
    public int getEntryIdx()
    {
        return entryIdx;
    }
    
    public void setEntryIdx(int entryIdx)
    {
        this.entryIdx=entryIdx;
    }
    
    public boolean isPINEntered()
    {
        return pinEntered;
    }
    
    public void setPINEntered(boolean pinEntered)
    {
        this.pinEntered=pinEntered;
    }
    
    public byte[] getSoftPin()
    {
        return softPin;
    }
    
    public void setSoftPin(byte[] softPin)
    {
        this.softPin=softPin;
    }
    
    public int getUseBio()
    {
        return useBio;
    }
    
    public void setUseBio(int useBio)
    {
        this.useBio=useBio;
    }
    
    public int getUseSoftPin()
    {
        return useSoftPin;
    }
    
    public void setUseSoftPin(int useSoftPin)
    {
        this.useSoftPin=useSoftPin;
    }
    
    private void checkPIN()
    {
        try {
            if (!pinEntered) {
                if (useSoftPin==1) {
                    String pin=HBCIUtils.getParam(getParamHeader()+".pin");

                    if (pin==null) {
                        StringBuffer temppin=new StringBuffer();
                        HBCIUtilsInternal.getCallback().callback(this,
                                                         HBCICallback.NEED_SOFTPIN,
                                                         HBCIUtilsInternal.getLocMsg("CALLB_NEED_SOFTPIN"),
                                                         HBCICallback.TYPE_SECRET,
                                                         temppin);
                        if (temppin.length()==0)
                            throw new HBCI_Exception(HBCIUtilsInternal.getLocMsg("EXCMSG_PINZERO"));
                        pin=temppin.toString();
                    }

                    setSoftPin(pin.getBytes("ISO-8859-1"));
                } else {
                    HBCIUtilsInternal.getCallback().callback(this,
                                                     HBCICallback.NEED_HARDPIN,
                                                     HBCIUtilsInternal.getLocMsg("CALLB_NEED_HARDPIN"),
                                                     HBCICallback.TYPE_NONE,
                                                     null);
                }

                try {
                    ctEnterPIN();
                    pinEntered=true;
                } catch (Exception e) {
                    HBCIUtils.setParam(getParamHeader()+".pin",null);
                    setSoftPin(new byte[0]);
                } finally {
                    if (useSoftPin!=1) {
                        HBCIUtilsInternal.getCallback().callback(this,
                                                         HBCICallback.HAVE_HARDPIN,
                                                         null,
                                                         HBCICallback.TYPE_NONE,
                                                         null);
                    }
                }
            }
        } catch (Exception e) {
            throw new HBCI_Exception(HBCIUtilsInternal.getLocMsg("EXCMSG_PINERR"),e);
        }
    }
    
    private void initCT()
    {
        try {
            if (!SmartCard.isStarted()) {
                // TODO: im moment wird ~/.opencard.properties verwendet
                // System.setProperty("OpenCard.loaderClassName", "org.kapott.hbci.ocf.CTPropertiesLoader");
                SmartCard.start();
            }
            
            // wait for card
            CardRequest request=new CardRequest(CardRequest.ANYCARD, null, null);
            request.setTimeout(60);
            this.smartCard=SmartCard.waitForCard(request);
            
            // get card service
            this.cardService=(RSACardService)smartCard.getCardService(RSACardService.class,true);
            
            // extract card id
            this.setCardId(cardService.getCardId());
        } catch (Exception e) {
            throw new HBCI_Exception(e);
        }
    }
    
    private void ctEnterPIN()
    {
        // TODO: auto-detect useSoftPin
        // TODO: auto-detect useBio
        
        if (getUseSoftPin()==1) {
            this.cardService.verifySoftPIN(16, this.getSoftPin(), HBCICardService.PIN_FORMAT_ASCII);
        } else {
            this.cardService.verifyHardPIN(getUseBio()==1, 16, HBCICardService.PIN_FORMAT_ASCII);
        }
    }
    
    private void ctReadBankData()
    {
        int         idx=this.getEntryIdx()-1;
        RSABankData bankData=cardService.readBankData(idx);
        System.out.println(bankData);
        
        setBLZ(bankData.blz);
        // TODO setCountry(SyntaxCtr.getName(bankData.country));
        setHost(bankData.host);
        setUserId(bankData.userid);
        
        // TODO more data
        // throw new RuntimeException("not yet implemented");
    }
    
    private void ctReadKeyData()
    {
        // TODO
        // throw new RuntimeException("not yet implemented");
    }
    
    private void ctSaveChanges()
    {
        int         idx=getEntryIdx()-1;
        RSABankData bankData=cardService.readBankData(idx);
        
        bankData.blz=getBLZ();
        // TODO bankData.country=SyntaxCtr.getCode(getCountry());
        bankData.host=getHost();
        bankData.userid=getUserId();
        // TODO more data
        
        ctEnterPIN();
        cardService.updateBankData(idx, bankData);
        
        // TODO more data
        // throw new RuntimeException("not yet implemented");
    }
    
    private void closeCT()
    {
        try {
            if (smartCard!=null) {
                smartCard.close();
            }
            // TODO: disabled because it throws an exception 
            // SmartCard.shutdown();
        } catch (Exception e) {
            throw new HBCI_Exception(e);
        }
    }
    
    public String getCardId()
    {
        return cardId;
    }
    
    public void setCardId(String cardId)
    {
        this.cardId=cardId;
    }
}
